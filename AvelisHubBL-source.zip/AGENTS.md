# Avelis Hub BL

- The deliverable is one managed `.NET 8` library for Android ARM64 under LemonLoader, never a web, desktop, or standalone VR application. `Main.cs` owns MelonLoader lifecycle entry points and Android filtering.
- `AvelisHubBL/Core/` contains lifecycle coordination, preference entries, and cached bindings to verified generated IL2CPP members. Keep optional game API lookups behind capability gates, and avoid runtime reflection scans in gameplay loops.
- `AvelisHubBL/Features/` contains local player/weapon tools, reversible world settings, and the Warehouse/Poolee spawn lifecycle. Scope restoration to values this mod owns; do not destroy pooled instances directly or mutate Fusion sessions.
- `AvelisHubBL/Menu/` contains a shared model for BoneLib and the Unity panel. Add controls to the shared model, keep unavailable actions visibly locked, and avoid rebuilding Unity objects on navigation. Icon alpha masks are 32 by 32 pixels, bottom row first; source SVGs and upstream license are adjacent.
- `GameReferences/` holds compile-only inputs and is never published. The package script generates distribution copies in `dist/` from source instead of reusing the old uploaded DLL. `scripts/download.html` is a static artifact index, not an app.
- Follow the Quest smoke test in `README.md` before claiming runtime support for a game patch. Record known limitations and dependency versions explicitly.
