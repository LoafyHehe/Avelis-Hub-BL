using System.Collections;
using System.Linq.Expressions;
using System.Reflection;
using Il2CppInterop.Runtime;
using UnityEngine;

namespace AvelisHubBL.Core;

internal static class GameApi
{
    private const BindingFlags Instance = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
    private const BindingFlags Static = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static;

    internal static Type? Find(string name) => AppDomain.CurrentDomain.GetAssemblies()
        .Select(assembly => assembly.GetType(name, false)).FirstOrDefault(type => type != null);

    internal static Type? Marrow(string name) => Find("Il2CppSLZ.Marrow." + name);
    internal static MethodInfo? Method(Type? type, string name, params Type[] args) =>
        type?.GetMethod(name, Instance | Static, null, args, null);

    internal static MethodInfo? Unique(Type? type, string name)
    {
        var matches = type?.GetMethods(Instance | Static).Where(method => method.Name == name).Take(2).ToArray();
        return matches?.Length == 1 ? matches[0] : null;
    }

    internal static PropertyInfo? Property(Type? type, string name) => type?.GetProperty(name, Instance | Static);

    internal static Func<object?, TValue>? Read<TValue>(Type? type, string name)
    {
        var member = Property(type, name);
        var field = member == null ? type?.GetField(name, Instance | Static) : null;
        var target = Expression.Parameter(typeof(object));
        Expression? body = member?.GetGetMethod(true) is { } getter
            ? Expression.Call(getter.IsStatic ? null : Expression.Convert(target, getter.DeclaringType!), getter)
            : field == null ? null : Expression.Field(field.IsStatic ? null : Expression.Convert(target, field.DeclaringType!), field);
        if (body == null || !typeof(TValue).IsAssignableFrom(body.Type))
            return null;
        return Expression.Lambda<Func<object?, TValue>>(Expression.Convert(body, typeof(TValue)), target).Compile();
    }

    internal static Action<object, TValue>? Write<TValue>(Type? type, string name)
    {
        var property = Property(type, name);
        var target = Expression.Parameter(typeof(object));
        var value = Expression.Parameter(typeof(TValue));
        if (property?.GetSetMethod(true) is { IsStatic: false } setter && property.PropertyType.IsAssignableFrom(typeof(TValue)))
            return Expression.Lambda<Action<object, TValue>>(Expression.Call(Expression.Convert(target, setter.DeclaringType!),
                setter, Expression.Convert(value, property.PropertyType)), target, value).Compile();

        var field = type?.GetField(name, Instance);
        if (field == null || field.IsInitOnly || !field.FieldType.IsAssignableFrom(typeof(TValue)))
            return null;
        var assign = Expression.Assign(Expression.Field(Expression.Convert(target, field.DeclaringType!), field), Expression.Convert(value, field.FieldType));
        return Expression.Lambda<Action<object, TValue>>(Expression.Block(assign, Expression.Empty()), target, value).Compile();
    }

    internal static Type? MemberType(Type? type, string name) => Property(type, name)?.PropertyType ?? type?.GetField(name, Instance | Static)?.FieldType;

    internal static Action<object, object>? WriteBoxed(Type? type, string name)
    {
        if (Property(type, name)?.GetSetMethod(true) is not { IsStatic: false } setter)
            return null;
        var target = Expression.Parameter(typeof(object));
        var value = Expression.Parameter(typeof(object));
        return Expression.Lambda<Action<object, object>>(Expression.Call(Expression.Convert(target, setter.DeclaringType!),
            setter, Expression.Convert(value, setter.GetParameters()[0].ParameterType)), target, value).Compile();
    }

    internal static Func<object?, TValue>? Call<TValue>(MethodInfo? method)
    {
        if (method == null || method.GetParameters().Length != 0 || !typeof(TValue).IsAssignableFrom(method.ReturnType))
            return null;
        var target = Expression.Parameter(typeof(object));
        var call = Expression.Call(method.IsStatic ? null : Expression.Convert(target, method.DeclaringType!), method);
        return Expression.Lambda<Func<object?, TValue>>(Expression.Convert(call, typeof(TValue)), target).Compile();
    }

    internal static Action<object>? Action(MethodInfo? method)
    {
        if (method == null || method.IsStatic || method.GetParameters().Length != 0)
            return null;
        var target = Expression.Parameter(typeof(object));
        var call = Expression.Call(Expression.Convert(target, method.DeclaringType!), method);
        return Expression.Lambda<Action<object>>(Expression.Block(call, Expression.Empty()), target).Compile();
    }

    internal static Func<GameObject, object?>? ComponentLookup(Type? type, bool parents = false)
    {
        if (type == null || !typeof(Component).IsAssignableFrom(type))
            return null;
        var native = Il2CppType.From(type);
        var ctor = type.GetConstructor(new[] { typeof(IntPtr) });
        if (ctor == null)
            return null;
        var pointer = Expression.Parameter(typeof(IntPtr));
        var wrap = Expression.Lambda<Func<IntPtr, object>>(Expression.Convert(Expression.New(ctor, pointer), typeof(object)), pointer).Compile();
        return target =>
        {
            var component = parents ? target.GetComponentInParent(native, false) : target.GetComponentInChildren(native, false);
            return component == null ? null : wrap(component.Pointer);
        };
    }

    internal static IEnumerable<object> Items(object? collection)
    {
        if (collection is IEnumerable enumerable)
        {
            foreach (var item in enumerable)
                if (item != null)
                    yield return item;
            yield break;
        }

        var iterator = collection == null ? null : Method(collection.GetType(), "GetEnumerator")?.Invoke(collection, null);
        if (iterator == null)
            yield break;
        var read = Read<object>(iterator.GetType(), "Current");
        var next = Call<bool>(Method(iterator.GetType(), "MoveNext"));
        try
        {
            if (read == null || next == null)
                yield break;
            while (next(iterator))
                if (read(iterator) is { } item)
                    yield return item;
        }
        finally
        {
            Action(Method(iterator.GetType(), "Dispose"))?.Invoke(iterator);
        }
    }

    internal static bool Alive(object? value) => value != null && (value is not UnityEngine.Object unity || unity != null);
}
