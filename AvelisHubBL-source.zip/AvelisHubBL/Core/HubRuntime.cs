using System.Reflection;
using AvelisHubBL.Features;
using AvelisHubBL.Menu;
using BoneLib;
using MelonLoader;
using UnityEngine;

namespace AvelisHubBL.Core;

internal sealed class HubRuntime(MelonLogger.Instance log, global::HarmonyLib.Harmony harmony) : IDisposable
{
    private readonly HubSettings settings = new();
    private readonly FusionTools fusion = new();
    private PlayerTools player = null!;
    private WeaponTools weapons = null!;
    private SpawnTools spawn = null!;
    private WorldTools world = null!;
    private HubMenu menu = null!;
    private VrPanel panel = null!;
    private bool ready, allowed, disabled, chordHeld;
    private float sceneReadyAt, nextFusionCheck;
    private string reason = "Waiting for the local player rig.";

    private int fusionRetryAttempts;
    private const int MaxFusionRetries = 10;

    internal void Initialize()
    {
        try
        {
            EnsureMarrow();
            player = new PlayerTools(settings, () => allowed);
            weapons = new WeaponTools(settings, player, () => allowed);
            spawn = new SpawnTools(settings, player, fusion);
            world = new WorldTools(settings);
            Bind("player", () => player.Bind(harmony));
            Bind("weapons", () => weapons.Bind(harmony));
            Bind("spawning", () => spawn.Bind(harmony));
            Bind("Fusion", fusion.Bind);
            menu = new HubMenu(settings, player, weapons, spawn, fusion, CanAct, () => reason, TogglePanel, ResetPlayer, ResetWorld);
            panel = new VrPanel(menu, player, log);
            ready = true;
            log.Msg($"Avelis Hub BL {Main.Version}: jump={player.CanJump}, flight={player.CanFly}, weapon hooks={weapons.CanMagazine}, warehouse={spawn.CanBrowse}, pooled spawn={spawn.CanSpawn}, fusion={fusion.Detected}, fusionSpawn={fusion.CanNetworkSpawn}, XR input={player.CanInput}.");
        }
        catch (Exception exception)
        {
            log.Error("Avelis Hub BL could not initialize: " + exception.GetBaseException().Message);
            disabled = true;
        }
    }

    private static void EnsureMarrow()
    {
        foreach (var reference in typeof(Player).Assembly.GetReferencedAssemblies())
            if (reference.Name == "Il2CppSLZ.Marrow" && GameApi.Marrow("RigManager") == null)
                Assembly.Load(reference);
    }

    private void Bind(string area, Action bind)
    {
        try { bind(); }
        catch (Exception exception) { log.Warning($"Avelis {area} binding: {exception.GetBaseException().Message}"); }
    }

    private bool CanAct() => allowed;

    internal void Update()
    {
        if (!ready || disabled)
            return;
        try
        {
            if ((!fusion.Detected || !fusion.CanNetworkSpawn)
                && Time.unscaledTime >= nextFusionCheck
                && fusionRetryAttempts < MaxFusionRetries)
            {
                nextFusionCheck = Time.unscaledTime + 2f;
                fusionRetryAttempts++;
                Bind("Fusion", fusion.Bind);
            }
            var playable = Time.unscaledTime >= sceneReadyAt && player.Head != null && !Loading();
            if (allowed && !playable)
                Restore();
            allowed = playable;
            var nextReason = !playable
                ? "Waiting for the local player rig."
                : fusion.IsNetworked()
                    ? "Fusion session active · All tools enabled."
                    : "All tools ready.";
            if (reason != nextReason)
            {
                reason = nextReason;
                menu.Invalidate();
            }
            menu.TryAttach();
            fusion.Update();
            if (spawn.Update(allowed)) menu.Invalidate();
            if (allowed)
            {
                world.Update();
                weapons.Update();
            }
            var chord = player.Chord;
            if (chord && !chordHeld)
                TogglePanel();
            chordHeld = chord;
            panel.Update();
            menu.SyncBoneMenu();
        }
        catch (Exception exception) { Fault(exception); }
    }

    internal void FixedUpdate()
    {
        if (!allowed || disabled)
            return;
        try { player.FixedUpdate(panel.Visible); }
        catch (Exception exception) { Fault(exception); }
    }

    private static bool Loading()
    {
        try { return HelperMethods.IsLoading(); }
        catch (NullReferenceException) { return true; }
    }

    private string TogglePanel()
    {
        if (Time.unscaledTime < sceneReadyAt || Loading())
            return "Wait for the scene to finish loading before opening the VR panel.";
        return panel.Toggle();
    }

    private string ResetPlayer()
    {
        settings.Noclip.Reset();
        settings.Flight.Reset();
        settings.Freeze.Reset();
        settings.Speed.Reset();
        settings.Jump.Reset();
        settings.FlySpeed.Reset();
        settings.God.Reset();
        settings.Gravity.Reset();
        player.Restore();
        world.Update();
        return "Player movement, collision and gravity restored.";
    }

    private string ResetWorld()
    {
        settings.Gravity.Reset();
        settings.TimeScale.Reset();
        world.Restore();
        spawn.ResetObjects();
        return "World overrides and tracked object edits restored.";
    }

    private void Restore()
    {
        allowed = false;
        Bind("player restore", () => player?.Restore());
        Bind("weapon restore", () => weapons?.Reset());
        Bind("world restore", () => world?.Restore());
    }

    internal void ChangeScene()
    {
        if (!ready || disabled)
            return;
        Restore();
        fusionRetryAttempts = 0;
        nextFusionCheck = 0f;
        Bind("Fusion", fusion.Bind);
        Bind("scene cleanup", spawn.ChangeScene);
        panel.Hide();
        sceneReadyAt = Time.unscaledTime + .35f;
        menu.Invalidate();
    }

    private void Fault(Exception exception)
    {
        disabled = true;
        log.Error("Avelis Hub BL paused after a runtime error: " + exception.GetBaseException().Message);
        Restore();
        Bind("fault cleanup", () => spawn?.Cleanup());
        Bind("fault panel cleanup", () => panel?.Hide());
        Bind("fault menu cleanup", () => menu?.Detach());
    }

    public void Dispose()
    {
        disabled = true;
        Restore();
        Bind("spawn cleanup", () => spawn?.Cleanup());
        Bind("panel cleanup", () => panel?.Dispose());
        Bind("menu cleanup", () => menu?.Detach());
        Bind("hook cleanup", () => harmony.UnpatchSelf());
    }
}
