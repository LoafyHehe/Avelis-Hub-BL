using System.Reflection;
using AvelisHubBL.Features;
using MelonLoader;
using UnityEngine;

namespace AvelisHubBL.Core;

internal sealed class FusionTools
{
    internal sealed record RemotePlayer(string Name, Vector3 Position, Quaternion Rotation);

    private Assembly? fusionAssembly;
    private bool loggedBind;
    private Func<object?, bool>? hasServer, isHost, isClient, levelNetworked;
    private Func<object?, object>? getPlayerIds, getLocalId;
    private Func<object?, byte>? getSmallId;
    private MethodInfo? tryGetPlayerByByte, tryGetPlayerById, networkSpawn, getUsernameMethod;
    private Type? spawnRequestInfoType, directSpawnableType;
    private bool networkSpawnDirectArgs;
    private Func<object?, object>? getRigRefs, getHead, getMetadata, getUsernameObj, getUsernameValProp;
    private Func<object?, string>? getUsername;
    private Func<object?, bool>? getRigValid;
    private MemberInfo? memberSpawnable, memberPosition, memberRotation, memberSpawnEffect, memberSpawnSource, memberBarcode;
    private object? spawnSourcePlayerValue;
    private int selectedIndex;

    internal bool Detected => fusionAssembly != null;
    internal string? LastError { get; private set; }
    internal bool CanNetworkSpawn => networkSpawn != null && (networkSpawnDirectArgs || (spawnRequestInfoType != null &&
        memberSpawnable != null && memberPosition != null && memberRotation != null));

    internal bool IsNetworked()
    {
        if (fusionAssembly == null) return false;
        try
        {
            return hasServer?.Invoke(null) == true
                || isHost?.Invoke(null) == true
                || isClient?.Invoke(null) == true
                || levelNetworked?.Invoke(null) == true;
        }
        catch { return false; }
    }

    internal string SessionLabel()
    {
        if (!Detected) return "Solo (Fusion not installed)";
        if (!IsNetworked()) return "Fusion idle (not in server)";
        var host = false;
        try { host = isHost?.Invoke(null) == true; } catch { }
        var count = Players().Count;
        var spawnSuffix = CanNetworkSpawn ? "" : " · netSpawn unavailable";
        return $"Fusion {(host ? "Host" : "Client")} · {count} remote player(s){spawnSuffix}";
    }

    internal void Bind()
    {
        var assembly = AppDomain.CurrentDomain.GetAssemblies().FirstOrDefault(item =>
            string.Equals(item.GetName().Name, "LabFusion", StringComparison.OrdinalIgnoreCase)
            || item.GetType("LabFusion.RPC.NetworkAssetSpawner", false) != null
            || item.GetType("LabFusion.Network.NetworkInfo", false) != null);
        if (assembly == null)
            return;
        if (ReferenceEquals(assembly, fusionAssembly) && CanNetworkSpawn)
            return;

        fusionAssembly = assembly;
        var networkInfo = FindFusionType(assembly, "LabFusion.Network.NetworkInfo", "NetworkInfo");
        hasServer = GameApi.Read<bool>(networkInfo, "HasServer");
        isHost = GameApi.Read<bool>(networkInfo, "IsHost");
        isClient = GameApi.Read<bool>(networkInfo, "IsClient");

        var networkScene = FindFusionType(assembly, "LabFusion.Scene.NetworkSceneManager", "NetworkSceneManager");
        levelNetworked = GameApi.Read<bool>(networkScene, "IsLevelNetworked");

        var idManager = FindFusionType(assembly, "LabFusion.Player.PlayerIdManager", "PlayerIdManager");
        getPlayerIds = GameApi.Read<object>(idManager, "PlayerIds");
        getLocalId = GameApi.Read<object>(idManager, "LocalId");

        var playerIdType = FindFusionType(assembly, "LabFusion.Player.PlayerId", "PlayerId");
        getSmallId = GameApi.Read<byte>(playerIdType, "SmallId");
        getMetadata = GameApi.Read<object>(playerIdType, "Metadata");
        var metaType = GameApi.MemberType(playerIdType, "Metadata")
            ?? FindFusionType(assembly, "LabFusion.Player.PlayerMetadata", "PlayerMetadata");
        getUsername = GameApi.Read<string>(metaType, "Username");
        if (getUsername == null && metaType != null)
        {
            getUsernameObj = GameApi.Read<object>(metaType, "Username");
            var usernameType = GameApi.MemberType(metaType, "Username");
            if (usernameType != null)
            {
                getUsernameMethod = GameApi.Method(usernameType, "GetValue");
                getUsernameValProp = GameApi.Read<object>(usernameType, "Value");
            }
        }

        var playerManager = FindFusionType(assembly, "LabFusion.Entities.NetworkPlayerManager", "NetworkPlayerManager")
            ?? assembly.GetType("LabFusion.Player.NetworkPlayerManager", false);
        var netPlayerType = FindFusionType(assembly, "LabFusion.Entities.NetworkPlayer", "NetworkPlayer")
            ?? assembly.GetType("LabFusion.Player.NetworkPlayer", false);

        if (playerManager != null && netPlayerType != null)
        {
            var byRefNetPlayer = netPlayerType.MakeByRefType();
            tryGetPlayerByByte = GameApi.Method(playerManager, "TryGetPlayer", typeof(byte), byRefNetPlayer);
            if (playerIdType != null)
                tryGetPlayerById = GameApi.Method(playerManager, "TryGetPlayer", playerIdType, byRefNetPlayer);
            getRigRefs = GameApi.Read<object>(netPlayerType, "RigRefs");
            var rigRefsType = GameApi.MemberType(netPlayerType, "RigRefs");
            getHead = GameApi.Read<Transform>(rigRefsType, "Head");
            getRigValid = GameApi.Read<bool>(rigRefsType, "IsValid");
        }

        BindNetworkSpawner(assembly);

        if (!loggedBind || CanNetworkSpawn)
        {
            loggedBind = true;
            MelonLogger.Msg($"Avelis: LabFusion bound ({assembly.GetName().Name}): networkSpawn={CanNetworkSpawn}, hasServer={hasServer != null}, levelNet={levelNetworked != null}, info={spawnRequestInfoType?.FullName ?? "none"}, direct={networkSpawnDirectArgs}.");
        }
    }

    private void BindNetworkSpawner(Assembly assembly)
    {
        networkSpawn = null;
        networkSpawnDirectArgs = false;
        spawnRequestInfoType = null;
        directSpawnableType = null;
        memberSpawnable = null;
        memberPosition = null;
        memberRotation = null;
        memberSpawnEffect = null;
        memberSpawnSource = null;
        memberBarcode = null;
        spawnSourcePlayerValue = null;

        var spawner = FindFusionType(assembly, "LabFusion.RPC.NetworkAssetSpawner", "NetworkAssetSpawner");
        if (spawner == null)
        {
            LastError = "LabFusion NetworkAssetSpawner type not found.";
            return;
        }

        var nestedInfo = spawner.GetNestedType("SpawnRequestInfo", BindingFlags.Public | BindingFlags.NonPublic)
            ?? FindFusionType(assembly, "LabFusion.RPC.SpawnRequestInfo", "SpawnRequestInfo");

        var methods = spawner.GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static)
            .Where(m => m.Name == "Spawn")
            .OrderBy(m => m.GetParameters().Length)
            .ToArray();

        foreach (var method in methods)
        {
            var parameters = method.GetParameters();
            if (parameters.Length < 1 || !parameters.Skip(1).All(p => p.IsOptional || p.HasDefaultValue))
                continue;

            var p0 = parameters[0].ParameterType;
            var elem = p0.IsByRef ? p0.GetElementType()! : p0;
            if ((nestedInfo != null && elem == nestedInfo) || string.Equals(elem.Name, "SpawnRequestInfo", StringComparison.OrdinalIgnoreCase))
            {
                networkSpawn = method;
                spawnRequestInfoType = elem;
                break;
            }
        }

        if (networkSpawn != null && spawnRequestInfoType != null)
        {
            memberSpawnable = FindMember(spawnRequestInfoType, "Spawnable", "spawnable");
            memberPosition = FindMember(spawnRequestInfoType, "Position", "position");
            memberRotation = FindMember(spawnRequestInfoType, "Rotation", "rotation");
            memberSpawnEffect = FindMember(spawnRequestInfoType, "SpawnEffect", "spawnEffect");
            memberSpawnSource = FindMember(spawnRequestInfoType, "SpawnSource", "spawnSource", "Source", "source");
            memberBarcode = FindMember(spawnRequestInfoType, "Barcode", "barcode");

            if (memberSpawnSource != null)
            {
                var sourceType = Nullable.GetUnderlyingType(MemberTypeOf(memberSpawnSource)) ?? MemberTypeOf(memberSpawnSource);
                if (sourceType.IsEnum)
                {
                    if (Enum.TryParse(sourceType, "Player", true, out var parsed))
                        spawnSourcePlayerValue = parsed;
                    else if (Enum.IsDefined(sourceType, 2))
                        spawnSourcePlayerValue = Enum.ToObject(sourceType, 2);
                }
            }

            if (!CanNetworkSpawn)
            {
                LastError = $"Fusion SpawnRequestInfo missing members (spawnable={memberSpawnable != null}, pos={memberPosition != null}, rot={memberRotation != null}).";
                return;
            }

            LastError = null;
            return;
        }

        var marrowSpawnable = GameApi.Marrow("Data.Spawnable");
        foreach (var method in methods)
        {
            var parameters = method.GetParameters();
            if (parameters.Length < 3 || !parameters.Skip(3).All(p => p.IsOptional || p.HasDefaultValue))
                continue;
            if (parameters[1].ParameterType != typeof(Vector3) || parameters[2].ParameterType != typeof(Quaternion))
                continue;

            var p0 = parameters[0].ParameterType;
            if ((marrowSpawnable != null && p0.IsAssignableFrom(marrowSpawnable)) || p0 == typeof(string))
            {
                networkSpawn = method;
                networkSpawnDirectArgs = true;
                directSpawnableType = p0;
                LastError = null;
                return;
            }
        }

        LastError = "LabFusion NetworkAssetSpawner.Spawn overload not found.";
    }

    internal bool TryNetworkSpawn(object spawnable, Vector3 position, Quaternion rotation, string? barcode = null)
    {
        if (!IsNetworked())
        {
            LastError = "Not connected to a Fusion session.";
            return false;
        }

        if (!CanNetworkSpawn || networkSpawn == null)
        {
            Bind();
            if (!CanNetworkSpawn || networkSpawn == null)
            {
                LastError ??= "Fusion NetworkAssetSpawner is unavailable.";
                MelonLogger.Warning("Avelis: " + LastError);
                return false;
            }
        }

        try
        {
            var parameters = networkSpawn.GetParameters();
            var args = new object?[parameters.Length];

            if (networkSpawnDirectArgs)
            {
                args[0] = directSpawnableType == typeof(string) ? (barcode ?? string.Empty) : spawnable;
                args[1] = position;
                args[2] = rotation;
                for (var i = 3; i < parameters.Length; i++)
                    args[i] = parameters[i].HasDefaultValue ? parameters[i].DefaultValue : null;
                networkSpawn.Invoke(null, args);
                LastError = null;
                return true;
            }

            var info = Activator.CreateInstance(spawnRequestInfoType!, nonPublic: true)
                ?? throw new InvalidOperationException($"Could not instantiate {spawnRequestInfoType!.Name}.");

            SetMember(info, memberSpawnable, spawnable);
            SetMember(info, memberPosition, position);
            SetMember(info, memberRotation, rotation);
            if (memberSpawnEffect != null) SetMember(info, memberSpawnEffect, true);
            if (memberSpawnSource != null && spawnSourcePlayerValue != null) SetMember(info, memberSpawnSource, spawnSourcePlayerValue);
            if (memberBarcode != null && !string.IsNullOrEmpty(barcode)) SetMember(info, memberBarcode, barcode);

            args[0] = info;
            for (var i = 1; i < parameters.Length; i++)
                args[i] = parameters[i].HasDefaultValue ? parameters[i].DefaultValue : null;

            networkSpawn.Invoke(null, args);
            LastError = null;
            return true;
        }
        catch (Exception ex)
        {
            LastError = "Fusion spawn failed: " + ex.GetBaseException().Message;
            MelonLogger.Warning("Avelis: " + LastError);
            return false;
        }
    }

    private static Type? FindFusionType(Assembly primary, string fullName, string simpleName)
    {
        var found = primary.GetType(fullName, false);
        if (found != null) return found;
        found = GameApi.Find(fullName);
        if (found != null) return found;
        try
        {
            return primary.GetTypes().FirstOrDefault(t => string.Equals(t.Name, simpleName, StringComparison.Ordinal));
        }
        catch (ReflectionTypeLoadException ex)
        {
            return ex.Types.FirstOrDefault(t => t != null && string.Equals(t.Name, simpleName, StringComparison.Ordinal));
        }
    }

    private static MemberInfo? FindMember(Type type, params string[] names)
    {
        const BindingFlags flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.IgnoreCase;
        foreach (var name in names)
        {
            if (type.GetProperty(name, flags) is { } prop && prop.GetSetMethod(true) is { IsStatic: false })
                return prop;
            if (type.GetField(name, flags) is { } field && !field.IsInitOnly)
                return field;
        }
        return null;
    }

    private static Type MemberTypeOf(MemberInfo member) => member switch
    {
        PropertyInfo prop => prop.PropertyType,
        FieldInfo field => field.FieldType,
        _ => typeof(object)
    };

    private static void SetMember(object target, MemberInfo? member, object? value)
    {
        if (member is PropertyInfo prop && prop.GetSetMethod(true) is { IsStatic: false } setter)
            setter.Invoke(target, new[] { value });
        else if (member is FieldInfo field)
            field.SetValue(target, value);
    }

    private string? ReadUsername(object pid)
    {
        try
        {
            var meta = getMetadata?.Invoke(pid);
            if (meta == null) return null;
            if (getUsername != null) return getUsername(meta);
            var raw = getUsernameObj?.Invoke(meta);
            if (raw == null) return null;
            if (raw is string direct) return direct;
            if (getUsernameMethod != null && getUsernameMethod.Invoke(raw, null)?.ToString() is { } mv) return mv;
            if (getUsernameValProp != null && getUsernameValProp.Invoke(raw)?.ToString() is { } pv) return pv;
            return raw.ToString();
        }
        catch
        {
            return null;
        }
    }

    internal List<RemotePlayer> Players()
    {
        var result = new List<RemotePlayer>();
        if (!IsNetworked() || getPlayerIds == null) return result;
        try
        {
            var local = getLocalId?.Invoke(null);
            byte? localByte = local != null && getSmallId != null ? getSmallId(local) : null;
            foreach (var pid in GameApi.Items(getPlayerIds(null)))
            {
                if (pid == null) continue;
                var small = getSmallId != null ? getSmallId(pid) : (byte)255;
                if (localByte.HasValue && small == localByte.Value) continue;
                object? netPlayer = null;
                if (tryGetPlayerById != null)
                {
                    var args = new object?[] { pid, null };
                    if (tryGetPlayerById.Invoke(null, args) is true) netPlayer = args[1];
                }
                else if (tryGetPlayerByByte != null && getSmallId != null)
                {
                    var args = new object?[] { small, null };
                    if (tryGetPlayerByByte.Invoke(null, args) is true) netPlayer = args[1];
                }
                if (netPlayer == null || getRigRefs == null || getHead == null) continue;
                var refs = getRigRefs(netPlayer);
                if (refs == null || (getRigValid != null && !getRigValid(refs))) continue;
                var head = getHead(refs) as Transform;
                if (head == null) continue;
                var name = ReadUsername(pid);
                if (string.IsNullOrWhiteSpace(name)) name = $"Player {small}";
                result.Add(new RemotePlayer(name, head.position, head.rotation));
            }
        }
        catch (Exception ex)
        {
            MelonLogger.Warning("Avelis: Fusion player query: " + ex.GetBaseException().Message);
        }
        return result;
    }

    internal string SelectedPlayerName
    {
        get
        {
            var list = Players();
            if (list.Count == 0) return IsNetworked() ? "No other players" : "Not in Fusion";
            selectedIndex = Math.Clamp(selectedIndex, 0, list.Count - 1);
            return $"{selectedIndex + 1}/{list.Count} · {list[selectedIndex].Name}";
        }
    }

    internal string CyclePlayer()
    {
        var list = Players();
        if (list.Count == 0) return IsNetworked() ? "No other players in session." : "Join a Fusion session first.";
        selectedIndex = (selectedIndex + 1) % list.Count;
        return $"Target: {list[selectedIndex].Name}";
    }

    internal RemotePlayer? CurrentTarget()
    {
        var list = Players();
        if (list.Count == 0) return null;
        selectedIndex = Math.Clamp(selectedIndex, 0, list.Count - 1);
        return list[selectedIndex];
    }

    internal string TeleportToTarget(PlayerTools player)
    {
        var target = CurrentTarget();
        if (target == null) return IsNetworked() ? "No remote Fusion player found." : "Join a Fusion session first.";
        var forward = Vector3.ProjectOnPlane(target.Rotation * Vector3.forward, Vector3.up);
        if (forward.sqrMagnitude < .01f) forward = Vector3.forward;
        var offset = target.Position - forward.normalized * 1.4f;
        return player.TeleportTo(offset);
    }
}
