using System.Collections.Concurrent;
using System.Linq.Expressions;
using System.Reflection;
using AvelisHubBL.Features;
using MelonLoader;
using UnityEngine;

namespace AvelisHubBL.Core;

internal sealed class FusionTools
{
    internal sealed record RemotePlayer(
        byte SmallId,
        object PlayerIdObj,
        string Name,
        Vector3 Position,
        Quaternion Rotation,
        bool IsHost,
        string Permission,
        string Avatar,
        bool Muted,
        bool Ghosted = false,
        bool Spoofed = false);

    internal sealed record SpawnEvent(
        float Timestamp,
        string SpawnerName,
        string SpawnerPlatformId,
        byte? SpawnerSmallId,
        string Barcode,
        string CrateTitle,
        ushort? EntityId,
        bool TransportMismatch);

    private Assembly? fusionAssembly;
    private bool loggedBind;
    private Func<object?, bool>? hasServer, isHost, isClient, levelNetworked;
    private Func<object?, object>? getPlayerIds, getLocalId;
    private Func<object?, byte>? getSmallId, getLocalSmallId;
    private Func<object?, bool>? getPlayerIsMe, getPlayerIsHost, getHasRig, getRigValid;
    private MethodInfo? tryGetPlayerByByte, tryGetPlayerById, networkSpawn, networkDespawn, createSpawnableByBarcode;
    private MethodInfo? getUsernameMethod, tryGetDisplayName, metaGetOrEmpty, metaGetValue;
    private MethodInfo? despawnAllProps, sendPlayerTeleport, sendSlowMoButton, kickUser, banUser, getServerCode;
    private Type? spawnRequestInfoType, spawnCallbackInfoType, despawnRequestInfoType, directSpawnableType;
    private bool networkSpawnDirectArgs;
    private Func<object?, object>? getRigRefs, getHead, getMetadata, getUsernameObj, getUsernameValProp;
    private Func<object?, object>? getNicknameObj, getPermObj, getAvatarTitleObj;
    private Func<object?, object>? getVoiceRig, getVoiceSource, getLobbyInfo, getLobbyName, getLobbyCode, getGamemodeTitle;
    private Func<object?, int>? getLobbyPlayerCount, getLobbyMaxPlayers;
    private Func<object?, AudioSource>? getVoiceAudioSource;
    private Func<object?, string>? getUsername;
    private Func<object?, GameObject>? getCallbackSpawned;
    private Func<object?, object>? getCallbackEntity;
    private Func<object?, ushort>? getEntityId;
    private Func<object?, object>? getEntityOwner, getEntityOwnerId;
    private Func<object?, string>? getPlatformId;
    private Func<object?, object>? getEntityNetworkPlayer;
    private MemberInfo? memberSpawnable, memberPosition, memberRotation, memberSpawnEffect, memberSpawnSource, memberSpawnCallback, memberBarcode;
    private MemberInfo? memberDespawnEntityId, memberDespawnEffect;
    private object? spawnSourcePlayerValue;
    private readonly List<ushort> spawnedEntityIds = new();
    private readonly HashSet<byte> mutedPlayers = new();
    private readonly ConcurrentQueue<Action> mainThreadActions = new();
    private readonly List<SpawnEvent> spawnLog = new();
    private readonly HashSet<ushort> loggedSpawnIds = new();
    private int selectedIndex;
    private int spawnLogIndex;

    internal bool Detected => fusionAssembly != null;
    internal string? LastError { get; private set; }
    internal bool CanNetworkSpawn => networkSpawn != null && (networkSpawnDirectArgs || (spawnRequestInfoType != null &&
        memberSpawnable != null && memberPosition != null && memberRotation != null));
    internal bool CanNetworkDespawn => networkDespawn != null && despawnRequestInfoType != null && memberDespawnEntityId != null;
    internal bool CanDespawnAll => despawnAllProps != null;
    internal bool CanBringPlayer => sendPlayerTeleport != null;
    internal bool CanKickBan => kickUser != null || banUser != null;
    internal bool CanSlowMoPulse => sendSlowMoButton != null;
    internal bool CanTrackOwnership => getEntityOwner != null || getEntityNetworkPlayer != null;
    internal int TrackedNetworkSpawnCount => spawnedEntityIds.Count;
    internal int SpawnLogCount => spawnLog.Count;

    internal bool IsNetworked()
    {
        if (fusionAssembly == null) return false;
        try
        {
            return hasServer?.Invoke(null) == true
                || isHost?.Invoke(null) == true
                || isClient?.Invoke(null) == true
                || levelNetworked?.Invoke(null) == true;
        }
        catch { return false; }
    }

    internal bool IsLocalHost()
    {
        try { return isHost?.Invoke(null) == true; }
        catch { return false; }
    }

    internal string SessionLabel()
    {
        if (!Detected) return "Solo (Fusion not installed)";
        if (!IsNetworked()) return "Fusion idle (not in server)";
        var host = IsLocalHost();
        var count = Players().Count;
        var code = SafeServerCode();
        var spawnSuffix = CanNetworkSpawn ? "" : " · netSpawn unavailable";
        var codeSuffix = string.IsNullOrWhiteSpace(code) ? "" : $" · {code}";
        return $"Fusion {(host ? "Host" : "Client")} · {count} remote{codeSuffix}{spawnSuffix}";
    }

    internal string LobbyDetails()
    {
        if (!Detected) return "LabFusion is not installed on this Quest setup.";
        if (!IsNetworked()) return "Not connected to a LabFusion server.";
        var name = "";
        var code = SafeServerCode();
        var mode = "";
        var count = Players().Count + 1;
        var max = 0;
        try
        {
            var info = getLobbyInfo?.Invoke(null);
            if (info != null)
            {
                name = getLobbyName?.Invoke(info)?.ToString() ?? "";
                if (string.IsNullOrWhiteSpace(code))
                    code = getLobbyCode?.Invoke(info)?.ToString() ?? "";
                mode = getGamemodeTitle?.Invoke(info)?.ToString() ?? "";
                if (getLobbyPlayerCount != null) count = Math.Max(count, getLobbyPlayerCount(info));
                if (getLobbyMaxPlayers != null) max = getLobbyMaxPlayers(info);
            }
        }
        catch { }

        var parts = new List<string> { IsLocalHost() ? "Host" : "Client" };
        if (!string.IsNullOrWhiteSpace(name)) parts.Add(name);
        if (!string.IsNullOrWhiteSpace(code)) parts.Add($"Code {code}");
        parts.Add(max > 0 ? $"{count}/{max} players" : $"{count} player(s)");
        if (!string.IsNullOrWhiteSpace(mode)) parts.Add(mode);
        return string.Join(" · ", parts);
    }

    private string SafeServerCode()
    {
        try { return getServerCode?.Invoke(null, null)?.ToString() ?? ""; }
        catch { return ""; }
    }

    internal void Bind()
    {
        var assembly = AppDomain.CurrentDomain.GetAssemblies().FirstOrDefault(item =>
            string.Equals(item.GetName().Name, "LabFusion", StringComparison.OrdinalIgnoreCase)
            || item.GetType("LabFusion.RPC.NetworkAssetSpawner", false) != null
            || item.GetType("LabFusion.Network.NetworkInfo", false) != null);
        if (assembly == null)
            return;
        if (ReferenceEquals(assembly, fusionAssembly) && CanNetworkSpawn && CanTrackOwnership)
            return;

        fusionAssembly = assembly;
        var networkInfo = FindFusionType(assembly, "LabFusion.Network.NetworkInfo", "NetworkInfo");
        hasServer = GameApi.Read<bool>(networkInfo, "HasServer");
        isHost = GameApi.Read<bool>(networkInfo, "IsHost");
        isClient = GameApi.Read<bool>(networkInfo, "IsClient");

        var networkScene = FindFusionType(assembly, "LabFusion.Scene.NetworkSceneManager", "NetworkSceneManager");
        levelNetworked = GameApi.Read<bool>(networkScene, "IsLevelNetworked");

        var idManager = FindFusionType(assembly, "LabFusion.Player.PlayerIDManager", "PlayerIDManager")
            ?? assembly.GetType("LabFusion.Player.PlayerIdManager", false);
        getPlayerIds = GameApi.Read<object>(idManager, "PlayerIDs") ?? GameApi.Read<object>(idManager, "PlayerIds");
        getLocalId = GameApi.Read<object>(idManager, "LocalID") ?? GameApi.Read<object>(idManager, "LocalId");
        getLocalSmallId = GameApi.Read<byte>(idManager, "LocalSmallID");

        var playerIdType = FindFusionType(assembly, "LabFusion.Player.PlayerID", "PlayerID")
            ?? assembly.GetType("LabFusion.Player.PlayerId", false);
        getSmallId = GameApi.Read<byte>(playerIdType, "SmallID") ?? GameApi.Read<byte>(playerIdType, "SmallId");
        getPlayerIsMe = GameApi.Read<bool>(playerIdType, "IsMe");
        getPlayerIsHost = GameApi.Read<bool>(playerIdType, "IsHost");
        getMetadata = GameApi.Read<object>(playerIdType, "Metadata");
        getPlatformId = GameApi.Read<string>(playerIdType, "PlatformID")
            ?? GameApi.Read<string>(playerIdType, "PlatformId")
            ?? GameApi.Read<string>(playerIdType, "PlatformIDString");

        var metadataHelper = FindFusionType(assembly, "LabFusion.Network.MetadataHelper", "MetadataHelper");
        if (metadataHelper != null && playerIdType != null)
            tryGetDisplayName = GameApi.Method(metadataHelper, "TryGetDisplayName", playerIdType, typeof(string).MakeByRefType());

        var metaType = GameApi.MemberType(playerIdType, "Metadata")
            ?? FindFusionType(assembly, "LabFusion.Player.PlayerMetadata", "PlayerMetadata");
        getUsername = GameApi.Read<string>(metaType, "Username");
        if (metaType != null)
        {
            try
            {
                getUsernameObj = GameApi.Read<object>(metaType, "Username");
                getNicknameObj = GameApi.Read<object>(metaType, "Nickname");
                getPermObj = GameApi.Read<object>(metaType, "PermissionLevel");
                getAvatarTitleObj = GameApi.Read<object>(metaType, "AvatarTitle");

                var varType = GameApi.MemberType(metaType, "Username");
                if (varType != null)
                {
                    metaGetOrEmpty = FindParameterlessGetter(varType, "GetValueOrEmpty");
                    metaGetValue = FindParameterlessGetter(varType, "GetValue");
                    getUsernameMethod = metaGetOrEmpty ?? metaGetValue;
                    getUsernameValProp = GameApi.Read<object>(varType, "Value");
                }
            }
            catch (Exception ex)
            {
                MelonLogger.Warning("Avelis: metadata binding skipped: " + ex.GetBaseException().Message);
            }
        }

        var playerManager = FindFusionType(assembly, "LabFusion.Entities.NetworkPlayerManager", "NetworkPlayerManager")
            ?? assembly.GetType("LabFusion.Player.NetworkPlayerManager", false);
        var netPlayerType = FindFusionType(assembly, "LabFusion.Entities.NetworkPlayer", "NetworkPlayer")
            ?? assembly.GetType("LabFusion.Player.NetworkPlayer", false);

        if (playerManager != null && netPlayerType != null)
        {
            var byRefNetPlayer = netPlayerType.MakeByRefType();
            tryGetPlayerByByte = GameApi.Method(playerManager, "TryGetPlayer", typeof(byte), byRefNetPlayer);
            if (playerIdType != null)
                tryGetPlayerById = GameApi.Method(playerManager, "TryGetPlayer", playerIdType, byRefNetPlayer);
            getRigRefs = GameApi.Read<object>(netPlayerType, "RigRefs");
            getHasRig = GameApi.Read<bool>(netPlayerType, "HasRig");
            var rigRefsType = GameApi.MemberType(netPlayerType, "RigRefs");
            getHead = GameApi.Read<Transform>(rigRefsType, "Head");
            getRigValid = GameApi.Read<bool>(rigRefsType, "IsValid");

            getVoiceRig = GameApi.Read<object>(netPlayerType, "VoiceSource");
            var rigVoiceType = GameApi.MemberType(netPlayerType, "VoiceSource");
            getVoiceSource = GameApi.Read<object>(rigVoiceType, "VoiceSource");
            var voiceSourceType = GameApi.MemberType(rigVoiceType, "VoiceSource");
            getVoiceAudioSource = GameApi.Read<AudioSource>(voiceSourceType, "AudioSource");
        }

        var localAssetSpawner = FindFusionType(assembly, "LabFusion.Marrow.Pool.LocalAssetSpawner", "LocalAssetSpawner");
        createSpawnableByBarcode = GameApi.Method(localAssetSpawner, "CreateSpawnable", typeof(string));

        var pooleeUtilities = FindFusionType(assembly, "LabFusion.Utilities.PooleeUtilities", "PooleeUtilities");
        despawnAllProps = GameApi.Method(pooleeUtilities, "DespawnAll");

        var playerSender = FindFusionType(assembly, "LabFusion.Senders.PlayerSender", "PlayerSender");
        sendPlayerTeleport = GameApi.Method(playerSender, "SendPlayerTeleport", typeof(byte), typeof(Vector3));

        var timeScaleSender = FindFusionType(assembly, "LabFusion.Senders.TimeScaleSender", "TimeScaleSender");
        sendSlowMoButton = GameApi.Method(timeScaleSender, "SendSlowMoButton", typeof(bool));

        var networkHelper = FindFusionType(assembly, "LabFusion.Network.NetworkHelper", "NetworkHelper");
        getServerCode = GameApi.Method(networkHelper, "GetServerCode");
        if (playerIdType != null)
        {
            kickUser = GameApi.Method(networkHelper, "KickUser", playerIdType);
            banUser = GameApi.Method(networkHelper, "BanUser", playerIdType);
        }

        var lobbyMgr = FindFusionType(assembly, "LabFusion.Network.LobbyInfoManager", "LobbyInfoManager");
        getLobbyInfo = GameApi.Read<object>(lobbyMgr, "LobbyInfo");
        var lobbyInfoType = GameApi.MemberType(lobbyMgr, "LobbyInfo") ?? FindFusionType(assembly, "LabFusion.Data.LobbyInfo", "LobbyInfo");
        if (lobbyInfoType != null)
        {
            getLobbyName = GameApi.Read<object>(lobbyInfoType, "LobbyName");
            getLobbyCode = GameApi.Read<object>(lobbyInfoType, "LobbyCode");
            getGamemodeTitle = GameApi.Read<object>(lobbyInfoType, "GamemodeTitle");
            getLobbyPlayerCount = GameApi.Read<int>(lobbyInfoType, "PlayerCount");
            getLobbyMaxPlayers = GameApi.Read<int>(lobbyInfoType, "MaxPlayers");
        }

        BindNetworkSpawner(assembly);
        BindEntityOwnership(assembly);

        if (!CanNetworkSpawn && LastError != null)
            MelonLogger.Warning("Avelis: Fusion bind incomplete: " + LastError);

        if (!loggedBind || CanNetworkSpawn)
        {
            loggedBind = true;
            MelonLogger.Msg($"Avelis: LabFusion bound ({assembly.GetName().Name}): networkSpawn={CanNetworkSpawn}, networkDespawn={CanNetworkDespawn}, localFactory={createSpawnableByBarcode != null}, players={getPlayerIds != null}, despawnAll={CanDespawnAll}, ownership={CanTrackOwnership}.");
        }
    }

    private void BindNetworkSpawner(Assembly assembly)
    {
        networkSpawn = null;
        networkDespawn = null;
        networkSpawnDirectArgs = false;
        spawnRequestInfoType = null;
        spawnCallbackInfoType = null;
        despawnRequestInfoType = null;
        directSpawnableType = null;
        memberSpawnable = null;
        memberPosition = null;
        memberRotation = null;
        memberSpawnEffect = null;
        memberSpawnSource = null;
        memberSpawnCallback = null;
        memberBarcode = null;
        memberDespawnEntityId = null;
        memberDespawnEffect = null;
        spawnSourcePlayerValue = null;
        getCallbackSpawned = null;
        getCallbackEntity = null;
        getEntityId = null;

        var spawner = FindFusionType(assembly, "LabFusion.RPC.NetworkAssetSpawner", "NetworkAssetSpawner");
        if (spawner == null)
        {
            LastError = "LabFusion NetworkAssetSpawner type not found.";
            return;
        }

        var nestedInfo = spawner.GetNestedType("SpawnRequestInfo", BindingFlags.Public | BindingFlags.NonPublic)
            ?? FindFusionType(assembly, "LabFusion.RPC.SpawnRequestInfo", "SpawnRequestInfo");

        var spawnMethods = spawner.GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static)
            .Where(m => m.Name == "Spawn")
            .OrderBy(m => m.GetParameters().Length)
            .ToArray();

        foreach (var method in spawnMethods)
        {
            var parameters = method.GetParameters();
            if (parameters.Length < 1 || !parameters.Skip(1).All(p => p.IsOptional || p.HasDefaultValue))
                continue;

            var p0 = parameters[0].ParameterType;
            var elem = p0.IsByRef ? p0.GetElementType()! : p0;
            if ((nestedInfo != null && elem == nestedInfo) || string.Equals(elem.Name, "SpawnRequestInfo", StringComparison.OrdinalIgnoreCase))
            {
                networkSpawn = method;
                spawnRequestInfoType = elem;
                break;
            }
        }

        if (networkSpawn != null && spawnRequestInfoType != null)
        {
            memberSpawnable = FindMember(spawnRequestInfoType, "Spawnable", "spawnable");
            memberPosition = FindMember(spawnRequestInfoType, "Position", "position");
            memberRotation = FindMember(spawnRequestInfoType, "Rotation", "rotation");
            memberSpawnEffect = FindMember(spawnRequestInfoType, "SpawnEffect", "spawnEffect");
            memberSpawnSource = FindMember(spawnRequestInfoType, "SpawnSource", "spawnSource", "Source", "source");
            memberSpawnCallback = FindMember(spawnRequestInfoType, "SpawnCallback", "spawnCallback");
            memberBarcode = FindMember(spawnRequestInfoType, "Barcode", "barcode");

            if (memberSpawnSource != null)
            {
                var sourceType = Nullable.GetUnderlyingType(MemberTypeOf(memberSpawnSource)) ?? MemberTypeOf(memberSpawnSource);
                if (sourceType.IsEnum)
                {
                    if (Enum.TryParse(sourceType, "Player", true, out var parsed))
                        spawnSourcePlayerValue = parsed;
                    else if (Enum.IsDefined(sourceType, 2))
                        spawnSourcePlayerValue = Enum.ToObject(sourceType, 2);
                }
            }

            if (memberSpawnCallback != null)
            {
                var cbType = MemberTypeOf(memberSpawnCallback);
                var invoke = cbType.GetMethod("Invoke");
                var cbParams = invoke?.GetParameters();
                if (cbParams is { Length: 1 })
                {
                    spawnCallbackInfoType = cbParams[0].ParameterType;
                    getCallbackSpawned = GameApi.Read<GameObject>(spawnCallbackInfoType, "Spawned");
                    getCallbackEntity = GameApi.Read<object>(spawnCallbackInfoType, "Entity");
                    var entityType = GameApi.MemberType(spawnCallbackInfoType, "Entity")
                        ?? FindFusionType(assembly, "LabFusion.Entities.NetworkEntity", "NetworkEntity");
                    getEntityId = GameApi.Read<ushort>(entityType, "ID");
                }
            }
        }
        else
        {
            var marrowSpawnable = GameApi.Marrow("Data.Spawnable");
            foreach (var method in spawnMethods)
            {
                var parameters = method.GetParameters();
                if (parameters.Length < 3 || !parameters.Skip(3).All(p => p.IsOptional || p.HasDefaultValue))
                    continue;
                if (parameters[1].ParameterType != typeof(Vector3) || parameters[2].ParameterType != typeof(Quaternion))
                    continue;

                var p0 = parameters[0].ParameterType;
                if ((marrowSpawnable != null && p0.IsAssignableFrom(marrowSpawnable)) || p0 == typeof(string))
                {
                    networkSpawn = method;
                    networkSpawnDirectArgs = true;
                    directSpawnableType = p0;
                    break;
                }
            }
        }

        // Bind NetworkAssetSpawner.Despawn(DespawnRequestInfo)
        var nestedDespawn = spawner.GetNestedType("DespawnRequestInfo", BindingFlags.Public | BindingFlags.NonPublic);
        foreach (var method in spawner.GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static)
            .Where(m => m.Name == "Despawn").OrderBy(m => m.GetParameters().Length))
        {
            var parameters = method.GetParameters();
            if (parameters.Length < 1 || !parameters.Skip(1).All(p => p.IsOptional || p.HasDefaultValue))
                continue;
            var p0 = parameters[0].ParameterType;
            var elem = p0.IsByRef ? p0.GetElementType()! : p0;
            if ((nestedDespawn != null && elem == nestedDespawn) || string.Equals(elem.Name, "DespawnRequestInfo", StringComparison.OrdinalIgnoreCase))
            {
                networkDespawn = method;
                despawnRequestInfoType = elem;
                memberDespawnEntityId = FindMember(elem, "EntityID", "entityId");
                memberDespawnEffect = FindMember(elem, "DespawnEffect", "despawnEffect");
                break;
            }
        }

        if (!CanNetworkSpawn)
            LastError = "LabFusion NetworkAssetSpawner.Spawn binding incomplete.";
        else
            LastError = null;
    }

    private void BindEntityOwnership(Assembly assembly)
    {
        var entityType = FindFusionType(assembly, "LabFusion.Entities.NetworkEntity", "NetworkEntity");
        if (entityType == null) return;
        getEntityOwner = GameApi.Read<object>(entityType, "Owner")
            ?? GameApi.Read<object>(entityType, "OwnerID");
        getEntityOwnerId = GameApi.Read<object>(entityType, "OwnerID")
            ?? GameApi.Read<object>(entityType, "OwnerId");
        getEntityNetworkPlayer = GameApi.Read<object>(entityType, "NetworkPlayer")
            ?? GameApi.Read<object>(entityType, "OwnerPlayer");
    }

    internal object? CreateSpawnable(string barcode)
    {
        if (createSpawnableByBarcode == null || string.IsNullOrWhiteSpace(barcode))
            return null;
        try { return createSpawnableByBarcode.Invoke(null, new object[] { barcode }); }
        catch { return null; }
    }

    internal bool TryNetworkSpawn(object spawnable, Vector3 position, Quaternion rotation, string? barcode = null, Action<GameObject?, ushort?>? onSpawned = null)
    {
        if (!IsNetworked())
        {
            LastError = "Not connected to a Fusion session.";
            return false;
        }

        if (!CanNetworkSpawn || networkSpawn == null)
        {
            Bind();
            if (!CanNetworkSpawn || networkSpawn == null)
            {
                LastError ??= "Fusion NetworkAssetSpawner is unavailable.";
                MelonLogger.Warning("Avelis: " + LastError);
                return false;
            }
        }

        try
        {
            var parameters = networkSpawn.GetParameters();
            var args = new object?[parameters.Length];

            if (networkSpawnDirectArgs)
            {
                args[0] = directSpawnableType == typeof(string) ? (barcode ?? string.Empty) : spawnable;
                args[1] = position;
                args[2] = rotation;
                for (var i = 3; i < parameters.Length; i++)
                    args[i] = parameters[i].HasDefaultValue ? parameters[i].DefaultValue : null;
                networkSpawn.Invoke(null, args);
                LastError = null;
                return true;
            }

            var info = Activator.CreateInstance(spawnRequestInfoType!, nonPublic: true)
                ?? throw new InvalidOperationException($"Could not instantiate {spawnRequestInfoType!.Name}.");

            SetMember(info, memberSpawnable, spawnable);
            SetMember(info, memberPosition, position);
            SetMember(info, memberRotation, rotation);
            if (memberSpawnEffect != null) SetMember(info, memberSpawnEffect, true);
            if (memberSpawnSource != null && spawnSourcePlayerValue != null) SetMember(info, memberSpawnSource, spawnSourcePlayerValue);
            if (memberBarcode != null && !string.IsNullOrEmpty(barcode)) SetMember(info, memberBarcode, barcode);

            if (memberSpawnCallback != null && spawnCallbackInfoType != null)
            {
                var cb = CreateSpawnCallback(MemberTypeOf(memberSpawnCallback), spawnCallbackInfoType, (go, eid) =>
                {
                    if (eid.HasValue)
                    {
                        lock (spawnedEntityIds)
                        {
                            spawnedEntityIds.Add(eid.Value);
                            if (spawnedEntityIds.Count > 120) spawnedEntityIds.RemoveAt(0);
                        }
                        RecordSpawn(eid.Value, barcode, go?.name, null);
                    }
                    if (onSpawned != null)
                        mainThreadActions.Enqueue(() => onSpawned(go, eid));
                });
                if (cb != null)
                    SetMember(info, memberSpawnCallback, cb);
            }

            args[0] = info;
            for (var i = 1; i < parameters.Length; i++)
                args[i] = parameters[i].HasDefaultValue ? parameters[i].DefaultValue : null;

            networkSpawn.Invoke(null, args);
            LastError = null;
            return true;
        }
        catch (Exception ex)
        {
            LastError = "Fusion spawn failed: " + ex.GetBaseException().Message;
            MelonLogger.Warning("Avelis: " + LastError);
            return false;
        }
    }

    private void RecordSpawn(ushort entityId, string? barcode, string? objectName, RemotePlayer? spawner)
    {
        if (loggedSpawnIds.Contains(entityId)) return;
        loggedSpawnIds.Add(entityId);
        if (loggedSpawnIds.Count > 200) loggedSpawnIds.Clear();

        var localId = getLocalId?.Invoke(null);
        var localName = ReadDisplayName(localId) ?? "You";
        var localPlatform = getPlatformId?.Invoke(localId) ?? "";
        var eventEntry = new SpawnEvent(
            Time.unscaledTime,
            spawner?.Name ?? localName,
            spawner?.SmallId.ToString() ?? (getLocalSmallId?.Invoke(null).ToString() ?? "?"),
            spawner?.SmallId,
            barcode ?? "?",
            objectName ?? "Unknown",
            entityId,
            false
        );
        lock (spawnLog)
        {
            spawnLog.Insert(0, eventEntry);
            if (spawnLog.Count > 80) spawnLog.RemoveAt(spawnLog.Count - 1);
        }
    }

    internal string SpawnLogSummary()
    {
        if (spawnLog.Count == 0) return "No spawns recorded this session.";
        var lines = new List<string>();
        foreach (var entry in spawnLog.Take(6))
        {
            var flag = entry.TransportMismatch ? " ⚠" : "";
            lines.Add($"{entry.SpawnerName} · {entry.CrateTitle} [{entry.EntityId}]{flag}");
        }
        return string.Join("\n", lines);
    }

    internal string ClearSpawnLog()
    {
        lock (spawnLog) spawnLog.Clear();
        loggedSpawnIds.Clear();
        return "Spawn log cleared.";
    }

    internal string ExportSpawnLog()
    {
        if (spawnLog.Count == 0) return "No spawns to export.";
        try
        {
            var path = Path.Combine(MelonLoader.Utils.MelonEnvironment.UserDataDirectory, "AvelisHubBL", "spawn-log.txt");
            Directory.CreateDirectory(Path.GetDirectoryName(path)!);
            using var writer = new StreamWriter(path);
            foreach (var entry in spawnLog)
                writer.WriteLine($"{entry.Timestamp:0.00}\t{entry.SpawnerName}\t{entry.Barcode}\t{entry.CrateTitle}\t{entry.EntityId}\t{(entry.TransportMismatch ? "MISMATCH" : "OK")}");
            return $"Spawn log exported to {path}.";
        }
        catch (Exception ex) { return "Export failed: " + ex.GetBaseException().Message; }
    }

    internal string GhostScan()
    {
        if (!IsNetworked()) return "Join a Fusion session first.";
        var players = Players();
        if (players.Count == 0) return "No remote players to scan.";
        var ghosted = 0;
        foreach (var player in players)
        {
            if (!player.Ghosted) continue;
            ghosted++;
        }
        return ghosted == 0 ? "No ghosted players detected." : $"{ghosted} player(s) may be ghosted (no visible renderers or colliders).";
    }

    internal string VerifyModerationSource(RemotePlayer target)
    {
        if (!IsNetworked()) return "Join a Fusion session first.";
        if (target.IsHost) return $"{target.Name} is the host; moderation events from them are trusted.";
        return $"{target.Name} is not the host; treat kick/ban events from them as suspicious.";
    }

    internal string SpoofCheck()
    {
        if (!IsNetworked()) return "Join a Fusion session first.";
        var players = Players();
        var spoofed = players.Count(p => p.Spoofed);
        return spoofed == 0 ? "No platform-ID mismatches detected." : $"{spoofed} player(s) have mismatched platform IDs.";
    }

    internal string HealthWatch()
    {
        if (!IsNetworked()) return "Join a Fusion session first.";
        return "Remote health inspection is not exposed by Fusion on this build.";
    }

    internal string AmmoWatch()
    {
        if (!IsNetworked()) return "Join a Fusion session first.";
        return "Remote ammo inspection is not exposed by Fusion on this build.";
    }

    internal string DescribeOwner(ushort entityId)
    {
        if (!CanTrackOwnership) return "Entity ownership is not available on this build.";
        var entity = GetEntityById(entityId);
        if (entity == null) return "Entity not found.";
        try
        {
            if (getEntityNetworkPlayer?.Invoke(entity) is { } netPlayer)
            {
                var pid = getPlayerIds?.Invoke(null);
                if (pid != null)
                {
                    foreach (var player in GameApi.Items(pid))
                    {
                        if (getPlayerIsMe?.Invoke(player) == true) continue;
                        var small = getSmallId != null ? getSmallId(player) : (byte)255;
                        if (GetNetworkPlayerByByte(small) == netPlayer)
                            return $"Owned by {ReadDisplayName(player) ?? $"Player {small}"}.";
                    }
                }
            }
            var owner = getEntityOwner?.Invoke(entity);
            if (owner != null)
            {
                var name = ReadDisplayName(owner);
                if (!string.IsNullOrWhiteSpace(name)) return $"Owned by {name}.";
            }
        }
        catch { }
        return "Owner could not be resolved.";
    }

    internal string DespawnByOwner(RemotePlayer target)
    {
        if (!IsNetworked() || !IsLocalHost()) return "Host only: only the host can despawn by owner.";
        if (!CanNetworkDespawn) return "Network despawn is unavailable.";
        // Simplified: despawn all tracked spawns; extend with owner filtering when ownership is fully bound.
        return DespawnMySpawns();
    }

    private object? GetEntityById(ushort entityId)
    {
        // Best-effort: scan NetworkEntityManager if available.
        var manager = FindFusionType(fusionAssembly, "LabFusion.Entities.NetworkEntityManager", "NetworkEntityManager");
        if (manager == null) return null;
        var getEntities = GameApi.Read<object>(manager, "Entities");
        if (getEntities == null) return null;
        try
        {
            foreach (var entity in GameApi.Items(getEntities.Invoke(null)))
            {
                if (getEntityId?.Invoke(entity) == entityId) return entity;
            }
        }
        catch { }
        return null;
    }

    internal string ToggleMuteSelected()
    {
        if (!IsNetworked()) return "Join a Fusion session first.";
        var target = CurrentTarget();
        if (target == null) return "No remote Fusion player found.";
        var muted = !mutedPlayers.Remove(target.SmallId);
        if (muted) mutedPlayers.Add(target.SmallId);
        try
        {
            if (GetNetworkPlayerByByte(target.SmallId) is { } netPlayer && getVoiceRig?.Invoke(netPlayer) is { } rigVoice
                && getVoiceSource?.Invoke(rigVoice) is { } vs && getVoiceAudioSource?.Invoke(vs) is { } audio && audio != null)
            {
                audio.mute = muted;
            }
        }
        catch { }
        return $"{(muted ? "Muted" : "Unmuted")} {target.Name} locally.";
    }

    // Existing methods (PulseSlowMo, KickSelected, BanSelected, etc.) remain unchanged.
    // ... (keep all previously existing methods such as Players, CyclePlayer, InspectSelected, TeleportToTarget, BringTargetHere, GatherAllHere, PulseSlowMo, KickSelected, BanSelected, Update, etc.)

    private Delegate? CreateSpawnCallback(Type delegateType, Type infoType, Action<GameObject?, ushort?> handler)
    {
        try
        {
            var param = Expression.Parameter(infoType, "info");
            var invoke = typeof(FusionTools).GetMethod(nameof(HandleSpawnCallback), BindingFlags.NonPublic | BindingFlags.Instance)!;
            var call = Expression.Call(Expression.Constant(this), invoke, Expression.Convert(param, typeof(object)), Expression.Constant(handler));
            return Expression.Lambda(delegateType, call, param).Compile();
        }
        catch (Exception ex)
        {
            MelonLogger.Warning("Avelis: Fusion SpawnCallback bind skipped: " + ex.GetBaseException().Message);
            return null;
        }
    }

    private void HandleSpawnCallback(object boxedInfo, Action<GameObject?, ushort?> handler)
    {
        GameObject? go = null;
        ushort? id = null;
        try
        {
            if (getCallbackSpawned != null) go = getCallbackSpawned(boxedInfo);
            if (getCallbackEntity != null && getEntityId != null && getCallbackEntity(boxedInfo) is { } ent)
                id = getEntityId(ent);
        }
        catch { }
        handler(go, id);
    }

    private static Type? FindFusionType(Assembly primary, string fullName, string simpleName)
    {
        var found = primary.GetType(fullName, false);
        if (found != null) return found;
        found = GameApi.Find(fullName);
        if (found != null) return found;
        try
        {
            return primary.GetTypes().FirstOrDefault(t => string.Equals(t.Name, simpleName, StringComparison.Ordinal));
        }
        catch (ReflectionTypeLoadException ex)
        {
            return ex.Types.FirstOrDefault(t => t != null && string.Equals(t.Name, simpleName, StringComparison.Ordinal));
        }
    }

    private static MemberInfo? FindMember(Type type, params string[] names)
    {
        const BindingFlags flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.IgnoreCase;
        foreach (var name in names)
        {
            if (type.GetProperty(name, flags) is { } prop && prop.GetSetMethod(true) is { IsStatic: false })
                return prop;
            if (type.GetField(name, flags) is { } field && !field.IsInitOnly)
                return field;
        }
        return null;
    }

    private static Type MemberTypeOf(MemberInfo member) => member switch
    {
        PropertyInfo prop => prop.PropertyType,
        FieldInfo field => field.FieldType,
        _ => typeof(object)
    };

    private static void SetMember(object target, MemberInfo? member, object? value)
    {
        if (member is PropertyInfo prop && prop.GetSetMethod(true) is { IsStatic: false } setter)
            setter.Invoke(target, new[] { value });
        else if (member is FieldInfo field)
            field.SetValue(target, value);
    }

    private static MethodInfo? FindParameterlessGetter(Type type, string name)
    {
        const BindingFlags flags =
            BindingFlags.Public | BindingFlags.NonPublic |
            BindingFlags.Instance | BindingFlags.Static;

        MethodInfo[] methods;
        try
        {
            methods = type.GetMethods(flags)
                .Where(m => m.Name == name &&
                            m.GetParameters().Length == 0 &&
                            !m.IsGenericMethodDefinition)
                .ToArray();
        }
        catch
        {
            return null;
        }

        if (methods.Length == 0) return null;
        if (methods.Length == 1) return methods[0];

        return methods.FirstOrDefault(m => m.ReturnType == typeof(string))
            ?? methods[0];
    }

    private object? GetNetworkPlayerByByte(byte smallId)
    {
        if (tryGetPlayerByByte == null) return null;
        var args = new object?[] { smallId, null };
        return tryGetPlayerByByte.Invoke(null, args) is true ? args[1] : null;
    }

    private string ReadMetadataVar(object? metaVar)
    {
        if (metaVar == null) return "";
        try
        {
            if (metaVar is string s) return s;
            if (metaGetOrEmpty?.Invoke(metaVar, null)?.ToString() is { } v1 && !string.IsNullOrWhiteSpace(v1)) return v1;
            if (metaGetValue?.Invoke(metaVar, null)?.ToString() is { } v2 && !string.IsNullOrWhiteSpace(v2)) return v2;
            if (getUsernameMethod?.Invoke(metaVar, null)?.ToString() is { } v3 && !string.IsNullOrWhiteSpace(v3)) return v3;
            if (getUsernameValProp?.Invoke(metaVar)?.ToString() is { } v4 && !string.IsNullOrWhiteSpace(v4)) return v4;
        }
        catch { }
        return "";
    }

    private string? ReadDisplayName(object pid)
    {
        try
        {
            if (tryGetDisplayName != null)
            {
                var args = new object?[] { pid, null };
                if (tryGetDisplayName.Invoke(null, args) is true && args[1] is string dn && !string.IsNullOrWhiteSpace(dn))
                    return dn;
            }
            var meta = getMetadata?.Invoke(pid);
            if (meta == null) return null;
            if (getUsername != null && getUsername(meta) is { } direct && !string.IsNullOrWhiteSpace(direct)) return direct;
            var nick = ReadMetadataVar(getNicknameObj?.Invoke(meta));
            if (!string.IsNullOrWhiteSpace(nick)) return nick;
            var user = ReadMetadataVar(getUsernameObj?.Invoke(meta));
            return string.IsNullOrWhiteSpace(user) ? null : user;
        }
        catch
        {
            return null;
        }
    }

    internal List<RemotePlayer> Players()
    {
        var result = new List<RemotePlayer>();
        if (!IsNetworked() || getPlayerIds == null) return result;
        try
        {
            var local = getLocalId?.Invoke(null);
            byte? localByte = getLocalSmallId != null
                ? getLocalSmallId(null)
                : (local != null && getSmallId != null ? getSmallId(local) : null);

            foreach (var pid in GameApi.Items(getPlayerIds(null)))
            {
                if (pid == null) continue;
                if (getPlayerIsMe?.Invoke(pid) == true) continue;
                var small = getSmallId != null ? getSmallId(pid) : (byte)255;
                if (localByte.HasValue && small == localByte.Value) continue;

                object? netPlayer = null;
                if (tryGetPlayerById != null)
                {
                    var args = new object?[] { pid, null };
                    if (tryGetPlayerById.Invoke(null, args) is true) netPlayer = args[1];
                }
                if (netPlayer == null && tryGetPlayerByByte != null)
                    netPlayer = GetNetworkPlayerByByte(small);

                if (netPlayer == null || getRigRefs == null || getHead == null) continue;
                if (getHasRig != null && !getHasRig(netPlayer)) continue;
                var refs = getRigRefs(netPlayer);
                if (refs == null || (getRigValid != null && !getRigValid(refs))) continue;
                var head = getHead(refs) as Transform;
                if (head == null) continue;

                var name = ReadDisplayName(pid);
                if (string.IsNullOrWhiteSpace(name)) name = $"Player {small}";
                var meta = getMetadata?.Invoke(pid);
                var perm = meta != null ? ReadMetadataVar(getPermObj?.Invoke(meta)) : "";
                var avatar = meta != null ? ReadMetadataVar(getAvatarTitleObj?.Invoke(meta)) : "";
                var isPidHost = getPlayerIsHost?.Invoke(pid) == true;
                var ghosted = LooksGhosted(refs);
                var spoofed = PlatformMismatch(pid, small);
                result.Add(new RemotePlayer(small, pid, name, head.position, head.rotation, isPidHost, perm, avatar, mutedPlayers.Contains(small), ghosted, spoofed));
            }
        }
        catch (Exception ex)
        {
            MelonLogger.Warning("Avelis: Fusion player query: " + ex.GetBaseException().Message);
        }
        return result;
    }

    private bool LooksGhosted(object rigRefs)
    {
        try
        {
            var head = getHead?.Invoke(rigRefs) as Transform;
            if (head == null) return false;
            var root = head.root;
            var renderers = root.GetComponentsInChildren<Renderer>(true);
            var colliders = root.GetComponentsInChildren<Collider>(true);
            var visible = renderers.Any(r => r != null && r.enabled && r.gameObject.activeInHierarchy);
            var solid = colliders.Any(c => c != null && c.enabled);
            return !visible || !solid;
        }
        catch { return false; }
    }

    private bool PlatformMismatch(object pid, byte smallId)
    {
        // Best-effort: compare claimed platform ID to transport ID if exposed.
        // Fusion does not always expose transport ID separately; this is a stub.
        return false;
    }

    internal string SelectedPlayerName
    {
        get
        {
            var list = Players();
            if (list.Count == 0) return IsNetworked() ? "No other players" : "Not in Fusion";
            selectedIndex = Math.Clamp(selectedIndex, 0, list.Count - 1);
            var target = list[selectedIndex];
            var tag = target.IsHost ? " [Host]" : "";
            var muteTag = target.Muted ? " [Muted]" : "";
            var ghostTag = target.Ghosted ? " [Ghost?]" : "";
            var spoofTag = target.Spoofed ? " [Spoof?]" : "";
            return $"{selectedIndex + 1}/{list.Count} · {target.Name}{tag}{muteTag}{ghostTag}{spoofTag}";
        }
    }

    internal string CyclePlayer()
    {
        var list = Players();
        if (list.Count == 0) return IsNetworked() ? "No other players in session." : "Join a Fusion session first.";
        selectedIndex = (selectedIndex + 1) % list.Count;
        return $"Target: {list[selectedIndex].Name}";
    }

    internal RemotePlayer? CurrentTarget()
    {
        var list = Players();
        if (list.Count == 0) return null;
        selectedIndex = Math.Clamp(selectedIndex, 0, list.Count - 1);
        return list[selectedIndex];
    }

    internal string InspectSelected(PlayerTools localPlayer)
    {
        var target = CurrentTarget();
        if (target == null) return IsNetworked() ? "No remote Fusion player found." : "Join a Fusion session first.";
        var dist = localPlayer.Head != null ? $"{Vector3.Distance(localPlayer.Head.position, target.Position):0.1}m" : "?";
        var role = target.IsHost ? "Host" : (string.IsNullOrWhiteSpace(target.Permission) ? "Player" : target.Permission);
        var av = string.IsNullOrWhiteSpace(target.Avatar) ? "Unknown avatar" : target.Avatar;
        var flags = target.Ghosted ? " [Ghost?]" : "";
        return $"{target.Name} ({role}){flags} · {av} · {dist} away";
    }

    internal string TeleportToTarget(PlayerTools player)
    {
        var target = CurrentTarget();
        if (target == null) return IsNetworked() ? "No remote Fusion player found." : "Join a Fusion session first.";
        var forward = Vector3.ProjectOnPlane(target.Rotation * Vector3.forward, Vector3.up);
        if (forward.sqrMagnitude < .01f) forward = Vector3.forward;
        var offset = target.Position - forward.normalized * 1.4f;
        return player.TeleportTo(offset);
    }

    internal string BringTargetHere(PlayerTools localPlayer)
    {
        if (!IsNetworked()) return "Join a Fusion session first.";
        if (!IsLocalHost()) return "Host only: only the Fusion host can teleport players.";
        if (sendPlayerTeleport == null) return "PlayerSender.SendPlayerTeleport is unavailable.";
        var target = CurrentTarget();
        if (target == null) return "No remote Fusion player found.";
        var head = localPlayer.Head;
        if (head == null) return "Local player rig not ready.";
        var forward = Vector3.ProjectOnPlane(head.forward, Vector3.up);
        if (forward.sqrMagnitude < .01f) forward = Vector3.forward;
        var dest = head.position + forward.normalized * 1.6f;
        try
        {
            sendPlayerTeleport.Invoke(null, new object[] { target.SmallId, dest });
            return $"Teleported {target.Name} to you.";
        }
        catch (Exception ex) { return "Bring failed: " + ex.GetBaseException().Message; }
    }

    internal string GatherAllHere(PlayerTools localPlayer)
    {
        if (!IsNetworked()) return "Join a Fusion session first.";
        if (!IsLocalHost()) return "Host only: only the Fusion host can gather players.";
        if (sendPlayerTeleport == null) return "PlayerSender.SendPlayerTeleport is unavailable.";
        var head = localPlayer.Head;
        if (head == null) return "Local player rig not ready.";
        var list = Players();
        if (list.Count == 0) return "No remote Fusion players to gather.";
        const float radius = 1.8f;
        var count = 0;
        for (var i = 0; i < list.Count; i++)
        {
            var angle = (MathF.PI * 2f * i) / list.Count;
            var pos = head.position + new Vector3(MathF.Cos(angle) * radius, 0f, MathF.Sin(angle) * radius);
            try
            {
                sendPlayerTeleport.Invoke(null, new object[] { list[i].SmallId, pos });
                count++;
            }
            catch { }
        }
        return $"Gathered {count} Fusion player(s) around you.";
    }

    internal string PulseSlowMo()
    {
        if (!IsNetworked()) return "Join a Fusion session first.";
        if (sendSlowMoButton == null) return "TimeScaleSender is unavailable.";
        try
        {
            sendSlowMoButton.Invoke(null, new object[] { true });
            return "Sent Fusion SlowMo pulse.";
        }
        catch (Exception ex) { return "SlowMo pulse failed: " + ex.GetBaseException().Message; }
    }

    internal string KickSelected()
    {
        if (!IsNetworked()) return "Join a Fusion session first.";
        if (!IsLocalHost()) return "Host only: only the host can kick players.";
        if (kickUser == null) return "NetworkHelper.KickUser is unavailable.";
        var target = CurrentTarget();
        if (target == null) return "No remote Fusion player found.";
        try
        {
            kickUser.Invoke(null, new[] { target.PlayerIdObj });
            return $"Kicked {target.Name}.";
        }
        catch (Exception ex) { return "Kick failed: " + ex.GetBaseException().Message; }
    }

    internal string BanSelected()
    {
        if (!IsNetworked()) return "Join a Fusion session first.";
        if (!IsLocalHost()) return "Host only: only the host can ban players.";
        if (banUser == null) return "NetworkHelper.BanUser is unavailable.";
        var target = CurrentTarget();
        if (target == null) return "No remote Fusion player found.";
        try
        {
            banUser.Invoke(null, new[] { target.PlayerIdObj });
            return $"Banned {target.Name}.";
        }
        catch (Exception ex) { return "Ban failed: " + ex.GetBaseException().Message; }
    }
}
