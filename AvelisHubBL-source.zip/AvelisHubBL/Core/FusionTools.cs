using System.Reflection;
using AvelisHubBL.Features;
using MelonLoader;
using UnityEngine;

namespace AvelisHubBL.Core;

internal sealed class FusionTools
{
    internal sealed record RemotePlayer(string Name, Vector3 Position, Quaternion Rotation);

    private Assembly? fusionAssembly;
    private Func<object?, bool>? hasServer, isHost;
    private Func<object?, object>? getPlayerIds, getLocalId;
    private Func<object?, byte>? getSmallId;
    private MethodInfo? tryGetPlayerByByte, tryGetPlayerById, networkSpawn, getUsernameMethod;
    private Type? spawnRequestInfoType;
    private Func<object?, object>? getRigRefs, getHead, getMetadata, getUsernameObj, getUsernameValProp;
    private Func<object?, string>? getUsername;
    private Func<object?, bool>? getRigValid;
    private PropertyInfo? propSpawnable, propPosition, propRotation, propSpawnEffect;
    private FieldInfo? fieldSpawnable, fieldPosition, fieldRotation, fieldSpawnEffect;
    private int selectedIndex;

    internal bool Detected => fusionAssembly != null;
    internal bool CanNetworkSpawn => networkSpawn != null && spawnRequestInfoType != null &&
        (propSpawnable != null || fieldSpawnable != null) &&
        (propPosition != null || fieldPosition != null) &&
        (propRotation != null || fieldRotation != null);

    internal bool IsNetworked()
    {
        if (fusionAssembly == null) return false;
        try { return hasServer?.Invoke(null) == true; }
        catch { return false; }
    }

    internal string SessionLabel()
    {
        if (!Detected) return "Solo (Fusion not installed)";
        if (!IsNetworked()) return "Fusion idle (not in server)";
        var host = false;
        try { host = isHost?.Invoke(null) == true; } catch { }
        var count = Players().Count;
        return $"Fusion {(host ? "Host" : "Client")} · {count} remote player(s)";
    }

    internal void Bind()
    {
        var assembly = AppDomain.CurrentDomain.GetAssemblies()
            .FirstOrDefault(item => item.GetName().Name == "LabFusion");
        if (assembly == null || ReferenceEquals(assembly, fusionAssembly))
            return;

        fusionAssembly = assembly;
        var networkInfo = assembly.GetType("LabFusion.Network.NetworkInfo");
        hasServer = GameApi.Read<bool>(networkInfo, "HasServer");
        isHost = GameApi.Read<bool>(networkInfo, "IsHost");

        var idManager = assembly.GetType("LabFusion.Player.PlayerIdManager");
        getPlayerIds = GameApi.Read<object>(idManager, "PlayerIds");
        getLocalId = GameApi.Read<object>(idManager, "LocalId");

        var playerIdType = assembly.GetType("LabFusion.Player.PlayerId");
        getSmallId = GameApi.Read<byte>(playerIdType, "SmallId");
        getMetadata = GameApi.Read<object>(playerIdType, "Metadata");
        var metaType = GameApi.MemberType(playerIdType, "Metadata") ?? assembly.GetType("LabFusion.Player.PlayerMetadata");
        getUsername = GameApi.Read<string>(metaType, "Username");
        if (getUsername == null && metaType != null)
        {
            getUsernameObj = GameApi.Read<object>(metaType, "Username");
            var usernameType = GameApi.MemberType(metaType, "Username");
            if (usernameType != null)
            {
                getUsernameMethod = GameApi.Method(usernameType, "GetValue");
                getUsernameValProp = GameApi.Read<object>(usernameType, "Value");
            }
        }

        var playerManager = assembly.GetType("LabFusion.Entities.NetworkPlayerManager")
            ?? assembly.GetType("LabFusion.Player.NetworkPlayerManager");
        var netPlayerType = assembly.GetType("LabFusion.Entities.NetworkPlayer")
            ?? assembly.GetType("LabFusion.Player.NetworkPlayer");

        if (playerManager != null && netPlayerType != null)
        {
            var byRefNetPlayer = netPlayerType.MakeByRefType();
            tryGetPlayerByByte = GameApi.Method(playerManager, "TryGetPlayer", typeof(byte), byRefNetPlayer);
            if (playerIdType != null)
                tryGetPlayerById = GameApi.Method(playerManager, "TryGetPlayer", playerIdType, byRefNetPlayer);
            getRigRefs = GameApi.Read<object>(netPlayerType, "RigRefs");
            var rigRefsType = GameApi.MemberType(netPlayerType, "RigRefs");
            getHead = GameApi.Read<Transform>(rigRefsType, "Head");
            getRigValid = GameApi.Read<bool>(rigRefsType, "IsValid");
        }

        var spawner = assembly.GetType("LabFusion.RPC.NetworkAssetSpawner");
        if (spawner != null)
        {
            spawnRequestInfoType = spawner.GetNestedType("SpawnRequestInfo", BindingFlags.Public | BindingFlags.NonPublic)
                ?? assembly.GetType("LabFusion.RPC.SpawnRequestInfo");
            if (spawnRequestInfoType != null)
            {
                networkSpawn = GameApi.Method(spawner, "Spawn", spawnRequestInfoType);
                propSpawnable = GameApi.Property(spawnRequestInfoType, "Spawnable");
                propPosition = GameApi.Property(spawnRequestInfoType, "Position");
                propRotation = GameApi.Property(spawnRequestInfoType, "Rotation");
                propSpawnEffect = GameApi.Property(spawnRequestInfoType, "SpawnEffect");
                fieldSpawnable = spawnRequestInfoType.GetField("Spawnable", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance)
                    ?? spawnRequestInfoType.GetField("spawnable", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
                fieldPosition = spawnRequestInfoType.GetField("Position", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance)
                    ?? spawnRequestInfoType.GetField("position", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
                fieldRotation = spawnRequestInfoType.GetField("Rotation", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance)
                    ?? spawnRequestInfoType.GetField("rotation", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
                fieldSpawnEffect = spawnRequestInfoType.GetField("SpawnEffect", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance)
                    ?? spawnRequestInfoType.GetField("spawnEffect", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            }
        }
        MelonLogger.Msg($"Avelis: LabFusion detected (networkSpawn={CanNetworkSpawn}).");
    }

    internal bool TryNetworkSpawn(object spawnable, Vector3 position, Quaternion rotation)
    {
        if (!CanNetworkSpawn || !IsNetworked()) return false;
        try
        {
            var info = Activator.CreateInstance(spawnRequestInfoType!)!;
            SetMember(info, propSpawnable, fieldSpawnable, spawnable);
            SetMember(info, propPosition, fieldPosition, position);
            SetMember(info, propRotation, fieldRotation, rotation);
            SetMember(info, propSpawnEffect, fieldSpawnEffect, true);
            networkSpawn!.Invoke(null, new[] { info });
            return true;
        }
        catch (Exception ex)
        {
            MelonLogger.Warning("Avelis: Fusion NetworkAssetSpawner fallback to local: " + ex.GetBaseException().Message);
            return false;
        }
    }

    private static void SetMember(object target, PropertyInfo? prop, FieldInfo? field, object value)
    {
        if (prop != null && prop.CanWrite) prop.SetValue(target, value);
        else field?.SetValue(target, value);
    }

    private string? ReadUsername(object pid)
    {
        try
        {
            var meta = getMetadata?.Invoke(pid);
            if (meta == null) return null;
            if (getUsername != null) return getUsername(meta);
            var raw = getUsernameObj?.Invoke(meta);
            if (raw == null) return null;
            if (raw is string direct) return direct;
            if (getUsernameMethod != null && getUsernameMethod.Invoke(raw, null)?.ToString() is { } mv) return mv;
            if (getUsernameValProp != null && getUsernameValProp.Invoke(raw)?.ToString() is { } pv) return pv;
            return raw.ToString();
        }
        catch
        {
            return null;
        }
    }

    internal List<RemotePlayer> Players()
    {
        var result = new List<RemotePlayer>();
        if (!IsNetworked() || getPlayerIds == null) return result;
        try
        {
            var local = getLocalId?.Invoke(null);
            byte? localByte = local != null && getSmallId != null ? getSmallId(local) : null;
            foreach (var pid in GameApi.Items(getPlayerIds(null)))
            {
                if (pid == null) continue;
                var small = getSmallId != null ? getSmallId(pid) : (byte)255;
                if (localByte.HasValue && small == localByte.Value) continue;
                object? netPlayer = null;
                if (tryGetPlayerById != null)
                {
                    var args = new object?[] { pid, null };
                    if (tryGetPlayerById.Invoke(null, args) is true) netPlayer = args[1];
                }
                else if (tryGetPlayerByByte != null && getSmallId != null)
                {
                    var args = new object?[] { small, null };
                    if (tryGetPlayerByByte.Invoke(null, args) is true) netPlayer = args[1];
                }
                if (netPlayer == null || getRigRefs == null || getHead == null) continue;
                var refs = getRigRefs(netPlayer);
                if (refs == null || (getRigValid != null && !getRigValid(refs))) continue;
                var head = getHead(refs) as Transform;
                if (head == null) continue;
                var name = ReadUsername(pid);
                if (string.IsNullOrWhiteSpace(name)) name = $"Player {small}";
                result.Add(new RemotePlayer(name, head.position, head.rotation));
            }
        }
        catch (Exception ex)
        {
            MelonLogger.Warning("Avelis: Fusion player query: " + ex.GetBaseException().Message);
        }
        return result;
    }

    internal string SelectedPlayerName
    {
        get
        {
            var list = Players();
            if (list.Count == 0) return IsNetworked() ? "No other players" : "Not in Fusion";
            selectedIndex = Math.Clamp(selectedIndex, 0, list.Count - 1);
            return $"{selectedIndex + 1}/{list.Count} · {list[selectedIndex].Name}";
        }
    }

    internal string CyclePlayer()
    {
        var list = Players();
        if (list.Count == 0) return IsNetworked() ? "No other players in session." : "Join a Fusion session first.";
        selectedIndex = (selectedIndex + 1) % list.Count;
        return $"Target: {list[selectedIndex].Name}";
    }

    internal RemotePlayer? CurrentTarget()
    {
        var list = Players();
        if (list.Count == 0) return null;
        selectedIndex = Math.Clamp(selectedIndex, 0, list.Count - 1);
        return list[selectedIndex];
    }

    internal string TeleportToTarget(PlayerTools player)
    {
        var target = CurrentTarget();
        if (target == null) return IsNetworked() ? "No remote Fusion player found." : "Join a Fusion session first.";
        var forward = Vector3.ProjectOnPlane(target.Rotation * Vector3.forward, Vector3.up);
        if (forward.sqrMagnitude < .01f) forward = Vector3.forward;
        var offset = target.Position - forward.normalized * 1.4f;
        return player.TeleportTo(offset);
    }
}
