using AvelisHubBL.Core;
using UnityEngine;

namespace AvelisHubBL.Features;

internal sealed class WorldTools(HubSettings settings)
{
    private Vector3 gravity, lastGravity;
    private float time, lastTime, fixedTime, lastFixedTime;
    private bool gravityApplied, timeApplied;

    internal void Update()
    {
        if (settings.Gravity.Value == 1f)
            RestoreGravity();
        else
        {
            var current = Physics.gravity;
            if (!gravityApplied || current != lastGravity)
                gravity = current;
            lastGravity = gravity * settings.Gravity.Value;
            if (current != lastGravity)
                Physics.gravity = lastGravity;
            gravityApplied = true;
        }

        if (settings.TimeScale.Value == 1f)
            RestoreTime();
        else if (Time.timeScale > .001f)
        {
            var current = Time.timeScale;
            if (!timeApplied || !Mathf.Approximately(current, lastTime))
                time = current;
            if (!timeApplied || !Mathf.Approximately(Time.fixedDeltaTime, lastFixedTime))
                fixedTime = Time.fixedDeltaTime;
            lastTime = time * settings.TimeScale.Value;
            lastFixedTime = fixedTime * settings.TimeScale.Value;
            if (!Mathf.Approximately(current, lastTime)) Time.timeScale = lastTime;
            if (!Mathf.Approximately(Time.fixedDeltaTime, lastFixedTime)) Time.fixedDeltaTime = lastFixedTime;
            timeApplied = true;
        }
    }

    private void RestoreGravity()
    {
        if (gravityApplied && Physics.gravity == lastGravity) Physics.gravity = gravity;
        gravityApplied = false;
    }

    private void RestoreTime()
    {
        if (timeApplied && Mathf.Approximately(Time.timeScale, lastTime)) Time.timeScale = time;
        if (timeApplied && Mathf.Approximately(Time.fixedDeltaTime, lastFixedTime)) Time.fixedDeltaTime = fixedTime;
        timeApplied = false;
    }

    internal void Restore()
    {
        RestoreGravity();
        RestoreTime();
    }
}
