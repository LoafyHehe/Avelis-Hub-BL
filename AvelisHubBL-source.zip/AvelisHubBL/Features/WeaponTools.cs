using System.Reflection;
using AvelisHubBL.Core;
using HarmonyLib;
using MelonLoader;
using UnityEngine;

namespace AvelisHubBL.Features;

internal sealed class WeaponTools(HubSettings initialSettings, PlayerTools player, Func<bool> canModifyGameplay)
{
    private readonly HubSettings settings = initialSettings;
    private readonly Func<bool> gameplayAllowed = canModifyGameplay;
    private static WeaponTools? active;
    [ThreadStatic] private static Transform? recoilScope;
    private Func<GameObject, object?>? gunChild, gunParent;
    private Func<object?, object>? inventoryInstance, magState, cartridge, projectile;
    private Func<object?, int>? ammo, gunAmmo;
    private Func<object?, float>? damage, roundsPerMinute, roundsPerSecond, fireDuration;
    private Action<object, float>? setDamage, setRoundsPerMinute, setRoundsPerSecond, setFireDuration;
    private Action<object>? refill;
    private GameObject? leftObject, rightObject;
    private Component? leftGun, rightGun;
    private readonly Dictionary<Component, (FireRate Original, FireRate Applied)> modifiedRates = new();
    private readonly List<Component> release = new(2);
    private float nextRefill;
    private readonly record struct FireRate(float Rpm, float RoundsPerSecond, float Duration);

    internal bool CanReserve { get; private set; }
    internal bool CanMagazine { get; private set; }
    internal bool CanRecoil { get; private set; }
    internal bool CanDamage { get; private set; }
    internal bool CanRapid => gunChild != null && roundsPerMinute != null && roundsPerSecond != null && fireDuration != null &&
        setRoundsPerMinute != null && setRoundsPerSecond != null && setFireDuration != null;
    internal bool CanReload => CanMagazine && ammo != null;
    internal bool CanInspect => gunChild != null;

    internal void Bind(global::HarmonyLib.Harmony harmony)
    {
        active = this;
        var gun = GameApi.Marrow("Gun");
        var inventory = GameApi.Marrow("AmmoInventory");
        var cartridgeType = GameApi.Marrow("Data.CartridgeData");
        var magazineType = GameApi.MemberType(gun, "_magState");
        var projectileType = GameApi.MemberType(cartridgeType, "projectile");
        gunChild = GameApi.ComponentLookup(gun);
        gunParent = GameApi.ComponentLookup(gun, parents: true);
        inventoryInstance = GameApi.Read<object>(inventory, "Instance");
        magState = GameApi.Read<object>(gun, "_magState");
        refill = GameApi.Action(GameApi.Method(magazineType, "Refill"));
        ammo = GameApi.Read<int>(magazineType, "AmmoCount");
        gunAmmo = GameApi.Call<int>(GameApi.Method(gun, "AmmoCount"));
        cartridge = GameApi.Read<object>(gun, "chamberedCartridge") ?? GameApi.Read<object>(gun, "defaultCartridge");
        projectile = GameApi.Read<object>(cartridgeType, "projectile");
        damage = GameApi.Read<float>(projectileType, "damageMultiplier");
        setDamage = GameApi.Write<float>(projectileType, "damageMultiplier");
        roundsPerMinute = GameApi.Read<float>(gun, "roundsPerMinute");
        roundsPerSecond = GameApi.Read<float>(gun, "roundsPerSecond");
        fireDuration = GameApi.Read<float>(gun, "fireDuration");
        setRoundsPerMinute = GameApi.Write<float>(gun, "roundsPerMinute");
        setRoundsPerSecond = GameApi.Write<float>(gun, "roundsPerSecond");
        setFireDuration = GameApi.Write<float>(gun, "fireDuration");

        if (cartridgeType != null && inventoryInstance != null)
            CanReserve = Hook(harmony, GameApi.Method(inventory, "RemoveCartridge", cartridgeType, typeof(int)), prefix: nameof(KeepReserve));

        if (gunChild == null)
            return;
        if (refill != null && magState != null)
            CanMagazine = Hook(harmony, GameApi.Unique(gun, "PullCartridge"), postfix: nameof(RefillAfterPull));

        if (Hook(harmony, GameApi.Method(gun, "Fire"), prefix: nameof(BeginFire), finalizer: nameof(EndFire)))
        {
            CanDamage = cartridge != null && projectile != null && damage != null && setDamage != null;
            CanRecoil = Hook(harmony, GameApi.Method(typeof(Rigidbody), "AddForceAtPosition", typeof(Vector3), typeof(Vector3), typeof(ForceMode)),
                prefix: nameof(FilterRecoil));
        }
    }

    private static bool Hook(global::HarmonyLib.Harmony harmony, MethodInfo? target, string? prefix = null, string? postfix = null, string? finalizer = null)
    {
        if (target == null)
            return false;
        try
        {
            harmony.Patch(target, prefix: Patch(prefix), postfix: Patch(postfix), finalizer: Patch(finalizer));
            return true;
        }
        catch (Exception exception)
        {
            MelonLogger.Warning($"Avelis: hook {target.Name} unavailable: {exception.Message}");
            return false;
        }
    }

    private static HarmonyMethod? Patch(string? name) => name == null ? null : new HarmonyMethod(typeof(WeaponTools), name);

    internal void Update()
    {
        if (gunChild == null)
            return;
        CacheHeld(player.HeldLeft, ref leftObject, ref leftGun);
        CacheHeld(player.HeldRight, ref rightObject, ref rightGun);
        if (CanRapid)
        {
            if (settings.FireRate.Value == 1f)
                RestoreRates();
            else
            {
                release.Clear();
                foreach (var other in modifiedRates.Keys)
                    if (!other || (other != leftGun && other != rightGun)) release.Add(other);
                foreach (var other in release)
                    RestoreRate(other);
                ApplyRate(leftGun);
                if (rightGun != leftGun)
                    ApplyRate(rightGun);
            }
        }
        if (CanReload && settings.Reload.On && Time.unscaledTime >= nextRefill)
        {
            nextRefill = Time.unscaledTime + .2f;
            TryRefill(leftGun, onlyEmpty: true);
            if (rightGun != leftGun)
                TryRefill(rightGun, onlyEmpty: true);
        }
    }

    private void CacheHeld(GameObject? held, ref GameObject? saved, ref Component? gun)
    {
        if (held == saved && (held != null || gun == null))
            return;
        saved = held;
        gun = held != null ? (gunParent?.Invoke(held) ?? gunChild?.Invoke(held)) as Component : null;
    }

    private bool LocalGun(object instance) => instance is Component component && component != null && (component == leftGun || component == rightGun);

    private static bool KeepReserve(object __instance)
    {
        var tools = active;
        return tools == null || !tools.settings.Reserve.On || !tools.gameplayAllowed() ||
            !PlayerTools.SameObject(__instance, tools.inventoryInstance?.Invoke(null));
    }

    private static void RefillAfterPull(object __instance)
    {
        var tools = active;
        if (tools == null || !tools.gameplayAllowed() || !tools.LocalGun(__instance))
            return;
        if (tools.settings.Magazine.On)
            tools.TryRefill(__instance, onlyEmpty: false);
        else if (tools.CanReload && tools.settings.Reload.On)
            tools.TryRefill(__instance, onlyEmpty: true);
    }

    private void TryRefill(object? gun, bool onlyEmpty)
    {
        if (!GameApi.Alive(gun) || magState?.Invoke(gun) is not { } state)
            return;
        if (!onlyEmpty || ammo?.Invoke(state) == 0)
            refill?.Invoke(state);
    }

    private record struct ShotState(Transform? Previous, object? Projectile, float Damage);

    private static void BeginFire(object __instance, out ShotState __state)
    {
        __state = new ShotState(recoilScope, null, 0f);
        recoilScope = null;
        var tools = active;
        if (tools == null || !tools.gameplayAllowed() || !tools.LocalGun(__instance))
            return;
        if (tools.CanRecoil && tools.settings.Recoil.On && __instance is Component gun)
        {
            var body = gun.GetComponentInParent<Rigidbody>();
            recoilScope = body != null ? body.transform : gun.transform;
        }
        if (!tools.CanDamage || tools.settings.Damage.Value == 1f)
            return;
        var round = tools.cartridge!(__instance);
        var shot = GameApi.Alive(round) ? tools.projectile!(round) : null;
        if (!GameApi.Alive(shot))
            return;
        var original = tools.damage!(shot);
        __state.Projectile = shot;
        __state.Damage = original;
        tools.setDamage!(shot!, original * tools.settings.Damage.Value);
    }

    private static Exception? EndFire(Exception? __exception, ShotState __state)
    {
        recoilScope = __state.Previous;
        if (GameApi.Alive(__state.Projectile))
            active?.setDamage?.Invoke(__state.Projectile!, __state.Damage);
        return __exception;
    }

    private static void FilterRecoil(Rigidbody __instance, ref Vector3 __0)
    {
        if (recoilScope != null && __instance != null && __instance.transform.IsChildOf(recoilScope))
            __0 = Vector3.zero;
    }

    private void ApplyRate(Component? gun)
    {
        if (gun == null)
            return;
        var current = ReadRate(gun);
        var original = modifiedRates.TryGetValue(gun, out var change) && change.Applied == current ? change.Original : current;
        if (!float.IsFinite(original.Rpm) || original.Rpm <= 0f) return;
        var rpm = original.Rpm * settings.FireRate.Value;
        var updated = new FireRate(rpm, rpm / 60f, 60f / rpm);
        if (current != updated)
        {
            modifiedRates[gun] = (original, updated);
            WriteRate(gun, updated);
        }
    }

    private FireRate ReadRate(Component gun) => new(roundsPerMinute!(gun), roundsPerSecond!(gun), fireDuration!(gun));

    private void WriteRate(Component gun, FireRate rate)
    {
        setRoundsPerMinute!(gun, rate.Rpm);
        setRoundsPerSecond!(gun, rate.RoundsPerSecond);
        setFireDuration!(gun, rate.Duration);
    }

    private void RestoreRate(Component gun)
    {
        if (modifiedRates.Remove(gun, out var values) && gun != null && ReadRate(gun) == values.Applied)
            WriteRate(gun, values.Original);
    }

    private void RestoreRates()
    {
        if (modifiedRates.Count == 0)
            return;
        foreach (var weapon in modifiedRates.Keys.ToArray())
            RestoreRate(weapon);
    }

    internal string Describe()
    {
        var gun = rightGun != null ? rightGun : leftGun;
        if (gun == null)
            return "Hold a compatible weapon to inspect it.";
        var count = gunAmmo?.Invoke(gun);
        var rpm = roundsPerMinute?.Invoke(gun);
        return $"{gun.name}: {count?.ToString() ?? "?"} rounds | {rpm?.ToString("0") ?? "?"} RPM";
    }

    internal void Reset()
    {
        RestoreRates();
        leftGun = rightGun = null;
        leftObject = rightObject = null;
        recoilScope = null;
    }
}
