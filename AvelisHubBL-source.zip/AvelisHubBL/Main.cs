using AvelisHubBL.Core;
using MelonLoader;

[assembly: MelonInfo(typeof(AvelisHubBL.Main), "Avelis Hub BL", AvelisHubBL.Main.Version, "Avelis")]
[assembly: MelonGame("Stress Level Zero", "BONELAB")]
[assembly: MelonPlatform(MelonPlatformAttribute.CompatiblePlatforms.ANDROID)]

namespace AvelisHubBL;

public sealed class Main : MelonMod
{
    internal const string Version = "0.3.0";
    private HubRuntime? runtime;

    public override void OnInitializeMelon()
    {
        if (MelonUtils.CurrentPlatform != MelonPlatformAttribute.CompatiblePlatforms.ANDROID)
            return;

        runtime = new HubRuntime(LoggerInstance, HarmonyInstance);
        runtime.Initialize();
    }

    public override void OnUpdate() => runtime?.Update();
    public override void OnFixedUpdate() => runtime?.FixedUpdate();
    public override void OnSceneWasLoaded(int buildIndex, string sceneName) => runtime?.ChangeScene();
    public override void OnDeinitializeMelon() => runtime?.Dispose();
}
