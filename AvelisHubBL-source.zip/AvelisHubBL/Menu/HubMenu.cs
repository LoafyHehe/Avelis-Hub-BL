using AvelisHubBL.Core;
using AvelisHubBL.Features;
using BoneLib.BoneMenu;
using MelonLoader;
using UnityEngine;

namespace AvelisHubBL.Menu;

internal sealed class HubMenu
{
    internal sealed record Section(string Title, string Description, HubRow[] Rows);
    internal sealed record HubRow(string Title, HubSettings.Setting? Setting = null, Func<string>? Invoke = null,
        Func<string>? Value = null, Func<bool>? Available = null, bool Gameplay = true, Action<string>? Search = null);

    private readonly Func<bool> canAct;
    private readonly Func<string> currentRuntimeStatus;
    private readonly List<Action> syncBone = new();
    private Page? root;
    private int boneRevision = -1;

    internal Section[] Sections { get; }
    internal int Revision { get; private set; }
    internal string Status { get; private set; } = "X + Y to close · Right Trigger to select";
    internal string RuntimeStatus => currentRuntimeStatus();

    internal HubMenu(HubSettings settings, PlayerTools player, WeaponTools weapons, SpawnTools spawn, Func<bool> canAct,
        Func<string> currentRuntimeStatus, Func<string> panel, Func<string> resetPlayer, Func<string> resetWorld)
    {
        this.canAct = canAct;
        this.currentRuntimeStatus = currentRuntimeStatus;
        var chooseCrate = new HubRow("Search by name or barcode", Value: () => spawn.Query, Available: () => spawn.CanBrowse,
            Gameplay: false, Search: text => SetStatus(spawn.Search(text)));
        var spawnSelected = Do("Spawn selected", spawn.SpawnSelected, () => spawn.CanSpawn, value: () => spawn.SelectedCrate);
        var prevCrate = Do("Previous result", () => spawn.Browse(-1), gameplay: false);
        var nextCrate = Do("Next result", () => spawn.Browse(1), gameplay: false);
        var scan = Do("Refresh warehouse", spawn.Refresh, () => spawn.CanBrowse, gameplay: false, value: () => spawn.Progress);
        var previousObject = Do("Previous tracked object", () => spawn.SelectTracked(-1), gameplay: false);
        var nextObject = Do("Next tracked object", () => spawn.SelectTracked(1), gameplay: false, value: () => spawn.SelectedObject);
        var noFall = new HubRow("No fall damage", Available: () => false, Value: () => "No verified fall-only hook");

        Sections = new[]
        {
            new Section("Player", "Health, locomotion and local rig overrides", new[]
            {
                Option("God mode", settings.God, () => player.CanGod), Do("Restore health", player.Heal, () => player.CanHeal),
                Option("Infinite reserve ammo", settings.Reserve, () => weapons.CanReserve),
                Option("Infinite magazine", settings.Magazine, () => weapons.CanMagazine), Option("No recoil", settings.Recoil, () => weapons.CanRecoil),
                noFall, Option("Jump multiplier", settings.Jump, () => player.CanJump), Option("Speed multiplier", settings.Speed, () => player.CanSpeed),
                Option("Freeze player", settings.Freeze)
            }),
            new Section("Weapons", "Tools for compatible weapons held by the local player", new[]
            {
                Option("Infinite reserve ammo", settings.Reserve, () => weapons.CanReserve),
                Option("Infinite magazine", settings.Magazine, () => weapons.CanMagazine), Option("No recoil", settings.Recoil, () => weapons.CanRecoil),
                Option("Damage multiplier", settings.Damage, () => weapons.CanDamage), Option("Fire rate multiplier", settings.FireRate, () => weapons.CanRapid),
                Option("Refill empty magazine", settings.Reload, () => weapons.CanReload),
                Do("Inspect held weapon", weapons.Describe, () => weapons.CanInspect),
                Do("Reset weapon overrides", () =>
                {
                    settings.Reserve.Reset(); settings.Magazine.Reset(); settings.Recoil.Reset();
                    settings.Damage.Reset(); settings.FireRate.Reset(); settings.Reload.Reset();
                    weapons.Reset();
                    return "Weapon overrides restored.";
                })
            }),
            new Section("Spawning", "Browse real crates from the active Asset Warehouse", new[]
            {
                Do("Next crate category", () => spawn.SetCategory((SpawnTools.Kind)(((int)spawn.Category + 1) % Enum.GetValues<SpawnTools.Kind>().Length)),
                    () => spawn.CanBrowse, gameplay: false, value: () => spawn.Category.ToString()),
                scan, chooseCrate, prevCrate, nextCrate, spawnSelected,
                Option("Distance (m)", settings.SpawnDistance), Option("Quantity", settings.SpawnCount), Option("Yaw (degrees)", settings.SpawnYaw),
                Option("Place on surface", settings.SpawnFloor), previousObject, nextObject,
                Do("Remove selected", () => spawn.RemoveSelected()), Do("Clear tracked spawns", () => spawn.Cleanup())
            }),
            new Section("Movement", "Left stick moves in flight; right stick lifts or lowers", new[]
            {
                Option("Flight", settings.Flight, () => player.CanFly), Option("Flight speed (m/s)", settings.FlySpeed, () => player.CanFly),
                Option("Noclip", settings.Noclip, () => player.CanFly), Do("Teleport to aim", player.Teleport, () => player.CanTeleport),
                Option("Teleport range (m)", settings.Teleport, () => player.CanTeleport), Option("Speed multiplier", settings.Speed, () => player.CanSpeed),
                Option("Jump multiplier", settings.Jump, () => player.CanJump), Option("Gravity multiplier", settings.Gravity)
            }),
            new Section("World", "Reversible scene and tracked prop controls", new[]
            {
                Option("Gravity multiplier", settings.Gravity), Option("Time scale", settings.TimeScale), previousObject, nextObject,
                Option("Object scale", settings.ObjectScale), Option("Object yaw", settings.ObjectYaw),
                Do("Apply scale and rotation", () => spawn.Manipulate(false)), Do("Move selected to aim", () => spawn.Manipulate(true)),
                Do("Restore selected transform", spawn.ResetSelected), Do("Freeze tracked NPCs", () => spawn.FreezeNpc(true, true)),
                Do("Unfreeze tracked NPCs", () => spawn.FreezeNpc(false, true)), Do("Remove tracked NPCs", () => spawn.Cleanup(true)),
                Do("Clear tracked spawns", () => spawn.Cleanup()), Do("Reset world overrides", resetWorld)
            }),
            new Section("NPCs", "Browse tagged NPC crates; manage this hub's spawns", new[]
            {
                Do("Browse NPC crates", () => spawn.SetCategory(SpawnTools.Kind.NPCs), () => spawn.CanBrowse, gameplay: false, value: () => spawn.SelectedCrate),
                chooseCrate, prevCrate, nextCrate,
                Do("Spawn selected NPC", () => spawn.Category == SpawnTools.Kind.NPCs ? spawn.SpawnSelected() : "Choose Browse NPC crates first.",
                    () => spawn.CanSpawn, value: () => spawn.Category == SpawnTools.Kind.NPCs ? spawn.SelectedCrate : "Select NPC crates"),
                Do("Select next spawned NPC", spawn.SelectNpc, gameplay: false, value: () => spawn.SelectedObject),
                Do("Freeze selected", () => spawn.FreezeNpc(true, false)), Do("Unfreeze selected", () => spawn.FreezeNpc(false, false)),
                Do("Inspect selected", spawn.DescribeNpc), Do("Remove selected", () => spawn.RemoveSelected(true)), Do("Remove tracked NPCs", () => spawn.Cleanup(true))
            }),
            new Section("Utilities", "Cleanup, recovery and compatibility information", new[]
            {
                Do("Clear tracked spawns", () => spawn.Cleanup()), Do("Reset player overrides", resetPlayer), Do("Reset world overrides", resetWorld),
                Do("About Avelis Hub BL", () => $"Avelis Hub BL {Main.Version} · by Avelis · Quest / LemonLoader 0.6.5.1 · BoneLib", gameplay: false),
                Do("Controller help", () => "Left X + Y opens/closes. Aim with right hand, pull Right Trigger to select. A jumps.", gameplay: false)
            }),
            new Section("Settings", "Save changes between Quest play sessions", new[]
            {
                Do("Save settings", () => { settings.Save(); return "Settings saved."; }, gameplay: false),
                Do("Load saved settings", () => { settings.Load(); return "Saved settings loaded."; }, gameplay: false),
                Do("Restore defaults and save", () => { settings.Defaults(); settings.Save(); return "Default settings restored and saved."; }, gameplay: false),
                Do("Toggle VR panel", panel, () => player.CanInput, gameplay: false)
            })
        };
    }

    internal bool Enabled(HubRow row) => row.Available?.Invoke() != false && (!row.Gameplay || canAct());
    internal void Invalidate() => Revision++;

    private static HubRow Option(string title, HubSettings.Setting setting, Func<bool>? available = null) => new(title, setting, Available: available);
    private static HubRow Do(string title, Func<string> invoke, Func<bool>? available = null, bool gameplay = true, Func<string>? value = null) =>
        new(title, Invoke: invoke, Value: value, Available: available, Gameplay: gameplay);

    internal void Activate(HubRow row, float? set = null, string? search = null)
    {
        if (!Enabled(row))
        {
            SetStatus(row.Available?.Invoke() == false ? row.Value?.Invoke() ?? "Not available on this game assembly." : RuntimeStatus);
            return;
        }
        try
        {
            if (row.Setting is { } setting && set.HasValue)
            {
                setting.Value = set.Value;
                SetStatus($"{row.Title}: {Format(setting)}");
            }
            else if (row.Search != null && search != null)
                row.Search(search);
            else if (row.Invoke != null)
                SetStatus(row.Invoke());
        }
        catch (Exception exception)
        {
            MelonLogger.Warning($"Avelis: {row.Title} failed: {exception.GetBaseException().Message}");
            SetStatus($"Could not complete {row.Title}. See Latest.log.");
        }
    }

    private void SetStatus(string text)
    {
        Status = text;
        Invalidate();
    }

    internal static string Format(HubSettings.Setting setting) => setting.Toggle ? setting.On ? "ON" : "OFF" : setting.Value.ToString("0.##");

    internal void TryAttach()
    {
        if (root != null || Page.Root == null)
            return;
        root = Page.Root.CreatePage("Avelis Hub BL", Color.white);
        foreach (var section in Sections)
        {
            var page = root.CreatePage(section.Title, Color.white, 10);
            var status = page.CreateFunction("Status", Color.gray, () => BoneLib.BoneMenu.Menu.DisplayDialog("Avelis Hub BL", Status + "\n" + RuntimeStatus));
            syncBone.Add(() => SetLabel(status, "Status: " + RuntimeStatus));
            foreach (var row in section.Rows)
            {
                if (row.Available?.Invoke() == false && row.Setting != null)
                    continue;
                if (row.Setting is { Toggle: true } toggle)
                {
                    var element = page.CreateBool(row.Title, Color.white, toggle.On, value => Activate(row, value ? 1f : 0f));
                    syncBone.Add(() => { if (element.Value != toggle.On) element.Value = toggle.On; });
                }
                else if (row.Setting is { } number)
                {
                    var element = page.CreateFloat(row.Title, Color.white, number.Value, number.Step, number.Minimum, number.Maximum, value => Activate(row, value));
                    syncBone.Add(() => { if (element.Value != number.Value) element.Value = number.Value; });
                }
                else if (row.Search != null && row.Available?.Invoke() != false)
                {
                    var element = page.CreateString(row.Title, Color.white, row.Value?.Invoke() ?? "", value => Activate(row, search: value));
                    syncBone.Add(() => { var text = row.Value?.Invoke() ?? ""; if (element.Value != text) element.Value = text; });
                }
                else if (row.Invoke != null && row.Available?.Invoke() != false)
                {
                    var element = page.CreateFunction(row.Title, Color.white, () =>
                    {
                        Activate(row);
                        if (row.Value == null)
                            BoneLib.BoneMenu.Menu.DisplayDialog("Avelis Hub BL", Status);
                    });
                    if (row.Value != null)
                        syncBone.Add(() => SetLabel(element, row.Title + " · " + row.Value()));
                }
            }
        }
        SyncBoneMenu();
    }

    private static void SetLabel(Element element, string label)
    {
        if (label != element.ElementName) element.ElementName = label;
    }

    internal void SyncBoneMenu()
    {
        if (root == null || boneRevision == Revision) return;
        boneRevision = Revision;
        foreach (var sync in syncBone) sync();
    }

    internal void Detach()
    {
        if (root != null)
            Page.Root.RemovePage(root);
        root = null;
        syncBone.Clear();
    }
}
