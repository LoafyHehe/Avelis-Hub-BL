using AvelisHubBL.Features;
using Il2CppInterop.Runtime.InteropTypes.Arrays;
using UnityEngine;
using Object = UnityEngine.Object;

namespace AvelisHubBL.Menu;

internal sealed class VrPanel(HubMenu menu, PlayerTools player) : IDisposable
{
    private const int RowsPerPage = 6;
    private static readonly string[] Icons = { "user-round", "crosshair", "package", "move", "globe", "users-round", "wrench", "sliders-horizontal" };
    private static readonly string[] Keyboard = { "1234567890", "QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM-_." };
    private static readonly Color Bright = Color.white;
    private static readonly Color Muted = new(.66f, .66f, .66f);
    private static readonly Color Quiet = new(.48f, .48f, .48f);

    private sealed record Target(Rect Bounds, Action<float> Select);
    private sealed record RowView(GameObject Root, TextMesh Label, TextMesh Detail, TextMesh Value,
        MeshRenderer Switch, MeshRenderer Track, Transform Fill, TextMesh Minus, TextMesh Plus);
    private readonly List<Object> assets = new();
    private readonly List<Target> targets = new();
    private readonly List<RowView> rows = new();
    private readonly MeshRenderer[] navTiles = new MeshRenderer[Icons.Length];
    private readonly TextMesh[] navLabels = new TextMesh[Icons.Length];
    private readonly List<(string Key, Rect Bounds)> keyTargets = new();
    private GameObject? root;
    private Transform? rowsRoot, keyboardRoot, cursor;
    private TextMesh? heading, caption, message, pagination, queryView;
    private MeshRenderer? pageBack, pageForward;
    private LineRenderer? beam;
    private Shader? colorShader, textureShader;
    private Material black = null!, border = null!, raised = null!, selected = null!, white = null!, track = null!;
    private int sectionIndex, pageIndex, seenRevision = -1;
    private bool dirty = true;
    private HubMenu.HubRow? editing;
    private string query = "";

    internal bool Visible => root != null && root.activeSelf;

    internal bool Toggle()
    {
        if (Visible)
        {
            Hide();
            return false;
        }
        var head = player.Head;
        if (head == null)
            return false;
        if (root == null) Build();
        var ahead = Vector3.ProjectOnPlane(head.forward, Vector3.up);
        if (ahead.sqrMagnitude < .01f) ahead = Vector3.forward;
        ahead = ahead.normalized;
        root!.transform.SetPositionAndRotation(head.position + ahead * 1.15f - Vector3.up * .12f, Quaternion.LookRotation(ahead));
        root.SetActive(true);
        dirty = true;
        return true;
    }

    internal void Hide()
    {
        if (root != null) root.SetActive(false);
        editing = null;
    }

    internal void Update()
    {
        if (!Visible) return;
        if (player.Head == null)
        {
            Hide();
            return;
        }
        if (dirty || seenRevision != menu.Revision) Draw();
        var aim = player.Aim;
        if (aim == null)
        {
            cursor!.gameObject.SetActive(false);
            beam!.enabled = false;
            return;
        }
        var origin = aim.position;
        var direction = aim.forward;
        var localOrigin = root!.transform.InverseTransformPoint(origin);
        var localDirection = root.transform.InverseTransformDirection(direction);
        var distance = localDirection.z <= .001f ? -1f : (-.024f - localOrigin.z) / localDirection.z;
        var point = localOrigin + localDirection * distance;
        var hit = distance is > 0f and < 4f && Mathf.Abs(point.x) < .56f && Mathf.Abs(point.y) < .345f;
        cursor!.gameObject.SetActive(hit);
        beam!.enabled = hit;
        if (!hit) return;
        cursor.localPosition = new Vector3(point.x, point.y, -.027f);
        beam.SetPosition(0, origin + direction * .045f);
        beam.SetPosition(1, root.transform.TransformPoint(cursor.localPosition));
        if (!player.Select) return;
        var position = new Vector2(point.x, point.y);
        foreach (var target in targets)
        {
            if (!target.Bounds.Contains(position)) continue;
            var fraction = Mathf.InverseLerp(target.Bounds.xMin, target.Bounds.xMax, point.x);
            target.Select(fraction);
            dirty = true;
            break;
        }
    }

    private void Build()
    {
        colorShader = Shader.Find("Universal Render Pipeline/Unlit");
        if (colorShader == null) colorShader = Shader.Find("Unlit/Color");
        textureShader = Shader.Find("Sprites/Default");
        if (colorShader == null) colorShader = textureShader;
        if (colorShader == null) throw new InvalidOperationException("No supported unlit shader is available for the VR panel.");
        root = new GameObject("Avelis Hub BL · VR Panel");
        Object.DontDestroyOnLoad(root);
        black = Material(colorShader, new Color(.035f, .035f, .035f));
        border = Material(colorShader, new Color(.32f, .32f, .32f));
        raised = Material(colorShader, new Color(.085f, .085f, .085f));
        selected = Material(colorShader, new Color(.19f, .19f, .19f));
        white = Material(colorShader, Color.white);
        track = Material(colorShader, new Color(.28f, .28f, .28f));

        var panel = root.transform;
        Tile(panel, 0f, 0f, 1.12f, .69f, .005f, border);
        Tile(panel, 0f, 0f, 1.112f, .682f, .003f, black);
        Tile(panel, -.402f, .02f, .285f, .462f, 0f, raised);
        Tile(panel, -.25f, .02f, .0018f, .462f, -.004f, border);
        Tile(panel, 0f, .246f, 1.05f, .0018f, -.005f, border);
        Tile(panel, 0f, -.268f, 1.05f, .0018f, -.005f, border);
        Text(panel, -.52f, .296f, "AVELIS HUB BL", .028f, Bright);
        Text(panel, .52f, .294f, "QUEST  /  V" + Main.Version, .013f, Muted, TextAnchor.MiddleRight);

        for (var index = 0; index < Icons.Length; index++)
        {
            var ordinate = .212f - index * .054f;
            navTiles[index] = Tile(panel, -.405f, ordinate, .255f, .047f, -.006f, raised);
            if (textureShader != null && Icon(Icons[index], textureShader) is { } material)
                Tile(panel, -.505f, ordinate, .025f, .025f, -.010f, material);
            navLabels[index] = Text(panel, -.481f, ordinate, menu.Sections[index].Title, .020f, Muted);
        }

        heading = Text(panel, -.222f, .211f, "", .028f, Bright);
        caption = Text(panel, -.222f, .176f, "", .013f, Muted);
        message = Text(panel, -.52f, -.302f, "", .014f, Muted);
        rowsRoot = Child(panel, "Control rows");
        for (var index = 0; index < RowsPerPage; index++)
        {
            var line = Child(rowsRoot, "Control row");
            line.localPosition = new Vector3(0f, .127f - index * .060f, 0f);
            Tile(line, .15f, 0f, .738f, .053f, -.007f, raised);
            var label = Text(line, -.206f, 0f, "", .018f, Bright);
            var detail = Text(line, -.206f, -.013f, "", .0125f, Muted);
            var value = Text(line, .494f, 0f, "", .014f, Bright, TextAnchor.MiddleRight);
            var button = Tile(line, .459f, 0f, .095f, .032f, -.010f, selected);
            var trackBar = Tile(line, .232f, 0f, .14f, .008f, -.009f, track);
            var fill = Tile(line, .232f, 0f, .14f, .006f, -.011f, white).transform;
            var minus = Text(line, .136f, 0f, "−", .019f, Bright, TextAnchor.MiddleCenter);
            var plus = Text(line, .329f, 0f, "+", .019f, Bright, TextAnchor.MiddleCenter);
            rows.Add(new RowView(line.gameObject, label, detail, value, button, trackBar, fill, minus, plus));
        }

        pageBack = Tile(panel, .267f, -.238f, .075f, .033f, -.007f, selected);
        pageForward = Tile(panel, .48f, -.238f, .075f, .033f, -.007f, selected);
        Text(panel, .267f, -.239f, "<", .018f, Bright, TextAnchor.MiddleCenter);
        Text(panel, .48f, -.239f, ">", .018f, Bright, TextAnchor.MiddleCenter);
        pagination = Text(panel, .376f, -.239f, "", .013f, Muted, TextAnchor.MiddleCenter);

        keyboardRoot = Child(panel, "Search keyboard");
        Tile(keyboardRoot, .146f, -.034f, .752f, .37f, -.012f, black);
        Tile(keyboardRoot, .146f, .101f, .713f, .044f, -.013f, raised);
        queryView = Text(keyboardRoot, -.189f, .101f, "", .019f, Bright);
        for (var row = 0; row < Keyboard.Length; row++)
            for (var column = 0; column < Keyboard[row].Length; column++)
                BuildKey(Keyboard[row][column].ToString(), -.155f + .062f * (column + (10 - Keyboard[row].Length) * .5f), .045f - row * .043f, .052f);
        BuildKey("Cancel", -.143f, -.146f, .095f);
        BuildKey("Space", .004f, -.146f, .148f);
        BuildKey("Delete", .143f, -.146f, .099f);
        BuildKey("Clear", .255f, -.146f, .09f);
        BuildKey("Search", .404f, -.146f, .154f);
        keyboardRoot.gameObject.SetActive(false);

        cursor = Tile(panel, 0f, 0f, .009f, .009f, -.026f, white).transform;
        beam = Child(panel, "Controller pointer").gameObject.AddComponent<LineRenderer>();
        beam.sharedMaterial = white;
        beam.useWorldSpace = true;
        beam.positionCount = 2;
        beam.startWidth = .0014f;
        beam.endWidth = .0014f;
        beam.enabled = false;
    }

    private void Draw()
    {
        dirty = false;
        seenRevision = menu.Revision;
        targets.Clear();
        var section = menu.Sections[sectionIndex];
        heading!.text = editing == null ? section.Title : "Search warehouse";
        caption!.text = editing == null ? Clip(section.Description, 74) : "Use the pointer to type a crate name or barcode.";
        message!.text = Clip(menu.Status, 100);
        for (var index = 0; index < Icons.Length; index++)
        {
            var tab = index;
            navTiles[index].sharedMaterial = tab == sectionIndex ? selected : raised;
            navLabels[index].color = tab == sectionIndex ? Bright : Muted;
            Add(-.405f, .212f - tab * .054f, .255f, .047f, () => { sectionIndex = tab; pageIndex = 0; editing = null; });
        }

        var showKeyboard = editing != null;
        rowsRoot!.gameObject.SetActive(!showKeyboard);
        keyboardRoot!.gameObject.SetActive(showKeyboard);
        if (showKeyboard)
        {
            queryView!.text = query.Length == 0 ? "Type to search…" : Clip(query, 48);
            pagination!.text = "FILTER";
            foreach (var key in keyTargets)
            {
                var name = key.Key;
                targets.Add(new Target(key.Bounds, _ => UseKey(name)));
            }
            return;
        }

        var pages = (section.Rows.Length + RowsPerPage - 1) / RowsPerPage;
        pageIndex = Mathf.Clamp(pageIndex, 0, pages - 1);
        pagination!.text = $"{pageIndex + 1} / {pages}";
        pageBack!.sharedMaterial = pageIndex > 0 ? selected : raised;
        pageForward!.sharedMaterial = pageIndex + 1 < pages ? selected : raised;
        if (pageIndex > 0) Add(.267f, -.238f, .075f, .033f, () => pageIndex--);
        if (pageIndex + 1 < pages) Add(.48f, -.238f, .075f, .033f, () => pageIndex++);

        for (var index = 0; index < rows.Count; index++)
        {
            var view = rows[index];
            var rowIndex = pageIndex * RowsPerPage + index;
            view.Root.SetActive(rowIndex < section.Rows.Length);
            if (rowIndex >= section.Rows.Length) continue;
            var row = section.Rows[rowIndex];
            var detail = row.Value?.Invoke();
            var available = menu.Enabled(row);
            var ordinate = .127f - index * .060f;
            view.Label.text = Clip(row.Title, 43);
            view.Label.color = available ? Bright : Quiet;
            view.Label.transform.localPosition = new Vector3(-.206f, string.IsNullOrEmpty(detail) ? 0f : .009f, -.015f);
            view.Detail.text = Clip(detail ?? "", 58);
            view.Switch.gameObject.SetActive(row.Setting?.Toggle != false);
            view.Track.gameObject.SetActive(row.Setting?.Toggle == false);
            view.Fill.gameObject.SetActive(row.Setting?.Toggle == false);
            view.Plus.gameObject.SetActive(row.Setting?.Toggle == false);
            view.Minus.gameObject.SetActive(row.Setting?.Toggle == false);
            view.Value.color = available ? Bright : Quiet;

            if (row.Setting is { } setting)
            {
                view.Value.text = available ? HubMenu.Format(setting) : "Locked";
                if (setting.Toggle)
                {
                    view.Switch.sharedMaterial = setting.On && available ? white : selected;
                    if (setting.On && available) view.Value.color = Color.black;
                    Add(.15f, ordinate, .738f, .053f, () => menu.Activate(row, setting.On ? 0f : 1f));
                }
                else
                {
                    var rate = Mathf.InverseLerp(setting.Minimum, setting.Maximum, setting.Value);
                    view.Fill.localScale = new Vector3(Mathf.Max(.001f, .14f * rate), .006f, 1f);
                    view.Fill.localPosition = new Vector3(.162f + .07f * rate, 0f, -.011f);
                    Add(.136f, ordinate, .043f, .048f, () => menu.Activate(row, setting.Value - setting.Step));
                    Add(.329f, ordinate, .043f, .048f, () => menu.Activate(row, setting.Value + setting.Step));
                    targets.Add(new Target(Box(.232f, ordinate, .14f, .048f), part => menu.Activate(row, Mathf.Lerp(setting.Minimum, setting.Maximum, part))));
                }
            }
            else
            {
                view.Switch.sharedMaterial = selected;
                view.Value.text = available ? row.Search != null ? "Edit" : "Open  >" : "Locked";
                Add(.15f, ordinate, .738f, .053f, () =>
                {
                    if (row.Search != null && menu.Enabled(row))
                    {
                        editing = row;
                        query = row.Value?.Invoke() ?? "";
                    }
                    else menu.Activate(row);
                });
            }
        }
    }

    private void UseKey(string key)
    {
        switch (key)
        {
            case "Cancel": editing = null; break;
            case "Search":
                if (editing != null) menu.Activate(editing, search: query);
                editing = null;
                break;
            case "Delete": if (query.Length > 0) query = query[..^1]; break;
            case "Clear": query = ""; break;
            default: if (query.Length < 48) query += key == "Space" ? " " : key; break;
        }
    }

    private void BuildKey(string key, float x, float y, float width)
    {
        Tile(keyboardRoot!, x, y, width, .035f, -.015f, selected);
        Text(keyboardRoot!, x, y, key, .015f, Bright, TextAnchor.MiddleCenter);
        keyTargets.Add((key, Box(x, y, width, .035f)));
    }

    private void Add(float x, float y, float width, float height, Action select) => targets.Add(new Target(Box(x, y, width, height), _ => select()));
    private static Rect Box(float x, float y, float width, float height) => new(x - width / 2f, y - height / 2f, width, height);

    private Material? Icon(string name, Shader shader)
    {
        using var bytes = typeof(VrPanel).Assembly.GetManifestResourceStream("Avelis.Icons." + name);
        if (bytes == null || bytes.Length != 1024) return null;
        var content = new byte[1024];
        bytes.ReadExactly(content);
        var pixels = new Il2CppStructArray<Color32>(content.Length);
        for (var index = 0; index < content.Length; index++) pixels[index] = new Color32(255, 255, 255, content[index]);
        var texture = new Texture2D(32, 32, TextureFormat.RGBA32, false);
        texture.SetPixels32(pixels);
        texture.Apply(false, true);
        assets.Add(texture);
        var material = Material(shader, Color.white);
        material.mainTexture = texture;
        return material;
    }

    private Material Material(Shader shader, Color color)
    {
        var material = new Material(shader) { color = color };
        if (material.HasProperty("_BaseColor")) material.SetColor("_BaseColor", color);
        assets.Add(material);
        return material;
    }

    private static Transform Child(Transform parent, string name)
    {
        var child = new GameObject(name).transform;
        child.SetParent(parent, false);
        return child;
    }

    private static MeshRenderer Tile(Transform parent, float x, float y, float width, float height, float depth, Material material)
    {
        var tile = GameObject.CreatePrimitive(PrimitiveType.Quad);
        tile.transform.SetParent(parent, false);
        tile.transform.localPosition = new Vector3(x, y, depth);
        tile.transform.localScale = new Vector3(width, height, 1f);
        if (tile.GetComponent<Collider>() is { } collider)
        {
            collider.enabled = false;
            Object.Destroy(collider);
        }
        var renderer = tile.GetComponent<MeshRenderer>();
        renderer.sharedMaterial = material;
        return renderer;
    }

    private static TextMesh Text(Transform parent, float x, float y, string text, float size, Color color, TextAnchor anchor = TextAnchor.MiddleLeft)
    {
        var item = Child(parent, "Label");
        item.localPosition = new Vector3(x, y, -.018f);
        var mesh = item.gameObject.AddComponent<TextMesh>();
        mesh.fontSize = 48;
        mesh.characterSize = size;
        mesh.anchor = anchor;
        mesh.alignment = TextAlignment.Left;
        mesh.richText = false;
        mesh.color = color;
        mesh.text = text;
        return mesh;
    }

    private static string Clip(string value, int length)
    {
        if (value.AsSpan().Contains('\n') || value.AsSpan().Contains('\r')) value = value.Replace('\n', ' ').Replace('\r', ' ');
        return value.Length <= length ? value : value[..(length - 1)] + "…";
    }

    public void Dispose()
    {
        if (root != null) Object.Destroy(root);
        foreach (var asset in assets) if (asset != null) Object.Destroy(asset);
        assets.Clear();
    }
}
