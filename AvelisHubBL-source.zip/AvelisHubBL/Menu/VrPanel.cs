using AvelisHubBL.Features;
using Il2CppInterop.Runtime.InteropTypes.Arrays;
using MelonLoader;
using UnityEngine;
using Object = UnityEngine.Object;

namespace AvelisHubBL.Menu;

internal sealed class VrPanel(HubMenu menu, PlayerTools player, MelonLogger.Instance log) : IDisposable
{
    private const int RowsPerPage = 6;
    private const float OpenSeconds = .18f;
    private const float OpenStartScale = .975f;
    private const float RailCenterX = -.455f, RailWidth = .275f, PanelHeight = .665f, ShellRadius = .038f;
    private const float MainCenterX = .155f, MainWidth = .895f;
    private const string Unavailable = "VR panel unavailable this session. Use Bone Menu and check Latest.log.";
    private static readonly string[] Icons = { "user-round", "crosshair", "package", "move", "globe", "users-round", "wrench", "sliders-horizontal" };
    private static readonly string[] Keyboard = { "1234567890", "QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM-_." };
    private static readonly Color Bright = Color.white;
    private static readonly Color Muted = new(.78f, .80f, .84f);
    private static readonly Color Quiet = new(.56f, .59f, .64f);

    private sealed record Target(Rect Bounds, Action<float> Select, MeshRenderer? Surface);
    private sealed record RowView(GameObject Root, MeshRenderer Surface, TextMesh Label, TextMesh Detail, TextMesh Value,
        MeshRenderer Switch, MeshRenderer SwitchThumb, MeshRenderer Track, MeshRenderer Thumb, TextMesh Minus, TextMesh Plus);

    private readonly List<Object> assets = new();
    private readonly Dictionary<(float Width, float Height, float Radius), Mesh> roundedMeshes = new();
    private readonly List<Target> targets = new();
    private readonly List<RowView> rows = new();
    private readonly MeshRenderer[] navTiles = new MeshRenderer[Icons.Length];
    private readonly TextMesh[] navLabels = new TextMesh[Icons.Length];
    private readonly List<(string Key, Rect Bounds, MeshRenderer Surface)> keyTargets = new();

    private GameObject? root;
    private Transform? rowsRoot, keyboardRoot, cursor;
    private TextMesh? heading, caption, message, pagination, queryView;
    private MeshRenderer? pageBack, pageForward;
    private MeshRenderer? focusedSurface;
    private LineRenderer? beam;
    private Mesh quad = null!;
    private Material obsidian = null!, rail = null!, kbPanel = null!, rim = null!, divider = null!, card = null!, activeNav = null!, hover = null!,
        pillOff = null!, pillOn = null!, actionPill = null!, white = null!, track = null!;
    private Material? unfocusedMaterial;
    private float openedAt;
    private int sectionIndex, pageIndex, seenRevision = -1;
    private bool dirty = true, failed, settling;
    private HubMenu.HubRow? editing;
    private string query = "";

    internal bool Visible => !failed && root != null && root.activeSelf;

    internal string Toggle()
    {
        if (failed) return Unavailable;
        var stage = "opening";
        try
        {
            if (Visible)
            {
                stage = "closing";
                Deactivate();
                return "VR panel closed.";
            }
            var head = player.Head;
            if (!player.CanInput || head == null) return "VR controller or head tracking is unavailable.";
            var firstOpen = root == null;
            if (firstOpen)
            {
                stage = "building the layout";
                Build();
            }
            stage = "positioning and drawing";
            var ahead = Vector3.ProjectOnPlane(head.forward, Vector3.up);
            if (ahead.sqrMagnitude < .01f) ahead = Vector3.forward;
            ahead = ahead.normalized;
            root!.transform.SetPositionAndRotation(head.position + ahead * 1.15f - Vector3.up * .12f, Quaternion.LookRotation(ahead));
            Draw();
            stage = "activating the layout";
            if (firstOpen) log.Msg("VR panel: activating the first view.");
            root.transform.localScale = Vector3.one * OpenStartScale;
            openedAt = Time.unscaledTime;
            settling = true;
            player.ResetSelect();
            root.SetActive(true);
            if (firstOpen) log.Msg("VR panel: first open complete.");
            return "VR panel open.";
        }
        catch (Exception exception)
        {
            Fail(stage, exception);
            return Unavailable;
        }
    }

    internal void Hide()
    {
        if (failed) return;
        try { Deactivate(); }
        catch (Exception exception) { Fail("hiding the layout", exception); }
    }

    private void Deactivate()
    {
        SetFocus(null);
        settling = false;
        player.ResetSelect();
        if (root != null) root.SetActive(false);
        if (cursor != null) cursor.gameObject.SetActive(false);
        if (beam != null) beam.enabled = false;
        editing = null;
    }

    internal void Update()
    {
        try { UpdateVisible(); }
        catch (Exception exception) { Fail("updating the view", exception); }
    }

    private void UpdateVisible()
    {
        if (!Visible) return;
        if (player.Head == null)
        {
            Hide();
            return;
        }
        if (settling)
        {
            var progress = Mathf.Clamp01((Time.unscaledTime - openedAt) / OpenSeconds);
            var remaining = 1f - progress;
            var scale = 1f - (1f - OpenStartScale) * remaining * remaining * remaining;
            root!.transform.localScale = Vector3.one * scale;
            if (progress < 1f) return;
            settling = false;
        }
        var selectPressed = player.ConsumeSelect();
        if (dirty || seenRevision != menu.Revision) Draw();
        var aim = player.Aim;
        if (aim == null)
        {
            SetFocus(null);
            cursor!.gameObject.SetActive(false);
            if (beam != null) beam.enabled = false;
            return;
        }
        var origin = aim.position;
        var direction = aim.forward;
        var localOrigin = root!.transform.InverseTransformPoint(origin);
        var localDirection = root.transform.InverseTransformDirection(direction);
        var distance = localDirection.z <= .001f ? -1f : (-.024f - localOrigin.z) / localDirection.z;
        var point = localOrigin + localDirection * distance;
        var hit = distance is > 0f and < 4f && InShell(point);
        cursor!.gameObject.SetActive(hit);
        if (beam != null) beam.enabled = hit;
        if (!hit)
        {
            SetFocus(null);
            return;
        }
        cursor.localPosition = new Vector3(point.x, point.y, -.027f);
        if (beam != null)
        {
            beam.SetPosition(0, origin + direction * .045f);
            beam.SetPosition(1, root.transform.TransformPoint(cursor.localPosition));
        }
        var position = new Vector2(point.x, point.y);
        foreach (var target in targets)
        {
            if (!target.Bounds.Contains(position)) continue;
            SetFocus(target.Surface);
            if (!selectPressed) return;
            var fraction = Mathf.InverseLerp(target.Bounds.xMin, target.Bounds.xMax, point.x);
            target.Select(fraction);
            dirty = true;
            return;
        }
        SetFocus(null);
    }

    private void SetFocus(MeshRenderer? surface)
    {
        if (ReferenceEquals(focusedSurface, surface)) return;
        if (focusedSurface != null && unfocusedMaterial != null) focusedSurface.sharedMaterial = unfocusedMaterial;
        focusedSurface = surface;
        unfocusedMaterial = surface != null ? surface.sharedMaterial : null;
        if (surface != null) surface.sharedMaterial = hover;
    }

    private void Build()
    {
        log.Msg("VR panel: preparing spatial obsidian glass shaders and meshes.");
        var textureShader = FindShader("Sprites/Default");
        var colorShader = FindShader("Universal Render Pipeline/Unlit") ?? FindShader("Unlit/Color") ?? textureShader;
        if (colorShader == null) throw new InvalidOperationException("No supported unlit shader is available for the VR panel.");
        var glassShader = textureShader ?? colorShader;

        root = new GameObject("Avelis Hub BL · VR Panel");
        root.SetActive(false);
        Object.DontDestroyOnLoad(root);
        quad = CreateQuad();

        // Ordered renderQueue layers keep glass strictly behind cards, pills, TextMesh (3000), and thumbs/icons (3002).
        rim = Material(glassShader, new Color(.86f, .90f, .98f, .28f), 2990);
        obsidian = Material(glassShader, new Color(.045f, .048f, .060f, .90f), 2992);
        rail = Material(glassShader, new Color(.065f, .070f, .086f, .92f), 2992);
        divider = Material(glassShader, new Color(1f, 1f, 1f, .11f), 2994);
        kbPanel = Material(glassShader, new Color(.075f, .082f, .098f, .94f), 2995);
        card = Material(glassShader, new Color(.115f, .125f, .148f, .78f), 2996);
        activeNav = Material(glassShader, new Color(.24f, .27f, .33f, .92f), 2996);
        hover = Material(glassShader, new Color(.21f, .23f, .29f, .88f), 2997);
        pillOff = Material(glassShader, new Color(.20f, .22f, .26f, .95f), 2998);
        pillOn = Material(glassShader, new Color(.20f, .78f, .35f, .98f), 2998);
        actionPill = Material(glassShader, new Color(.20f, .22f, .26f, .92f), 2998);
        track = Material(glassShader, new Color(1f, 1f, 1f, .28f), 2998);
        white = Material(colorShader, Color.white, 3002);

        log.Msg("VR panel: building detached spatial sidebar and obsidian workspace.");
        var panel = root.transform;

        // Detached left navigation glass rail with crisp specular rim
        Tile(panel, RailCenterX, 0f, RailWidth + .005f, PanelHeight + .005f, .005f, rim, ShellRadius + .002f);
        Tile(panel, RailCenterX, 0f, RailWidth, PanelHeight, .003f, rail, ShellRadius);
        Text(panel, -.566f, .276f, "Avelis Hub BL", .022f, Bright);
        Text(panel, -.566f, .243f, "Spatial Tools", .0125f, Quiet);
        Tile(panel, RailCenterX, .214f, .222f, .0012f, -.004f, divider);

        for (var index = 0; index < Icons.Length; index++)
        {
            var ordinate = .166f - index * .054f;
            navTiles[index] = Tile(panel, RailCenterX, ordinate, .238f, .044f, -.006f, rail, .021f);
            navLabels[index] = Text(panel, -.514f, ordinate, menu.Sections[index].Title, .017f, Muted);
        }

        // Main obsidian glass window with crisp specular rim
        Tile(panel, MainCenterX, 0f, MainWidth + .005f, PanelHeight + .005f, .005f, rim, ShellRadius + .002f);
        Tile(panel, MainCenterX, 0f, MainWidth, PanelHeight, .003f, obsidian, ShellRadius);

        heading = Text(panel, -.248f, .272f, "", .026f, Bright);
        Text(panel, .558f, .272f, "Quest · " + Main.Version, .0125f, Quiet, TextAnchor.MiddleRight);
        caption = Text(panel, -.248f, .235f, "", .013f, Muted);
        Tile(panel, MainCenterX, .204f, .816f, .0012f, -.004f, divider);

        Tile(panel, MainCenterX, -.224f, .816f, .0012f, -.004f, divider);
        message = Text(panel, -.248f, -.268f, "", .0125f, Muted);

        rowsRoot = Child(panel, "Control rows");
        for (var index = 0; index < RowsPerPage; index++)
        {
            var line = Child(rowsRoot, "Control row");
            line.localPosition = new Vector3(0f, .144f - index * .060f, 0f);
            var surface = Tile(line, MainCenterX, 0f, .818f, .052f, -.007f, card, .017f);
            var label = Text(line, -.228f, 0f, "", .016f, Bright);
            var detail = Text(line, -.228f, -.013f, "", .0115f, Muted);
            var value = Text(line, .448f, 0f, "", .013f, Muted, TextAnchor.MiddleRight);
            var toggleTrack = Tile(line, .506f, 0f, .074f, .030f, -.010f, pillOff, .015f);
            var toggleThumb = Tile(line, .489f, 0f, .023f, .023f, -.012f, white, .0114f);
            var trackBar = Tile(line, .295f, 0f, .180f, .0055f, -.009f, track, .0027f);
            var thumb = Tile(line, .295f, 0f, .016f, .016f, -.011f, white, .0079f);
            var minus = Text(line, .175f, 0f, "−", .0185f, Bright, TextAnchor.MiddleCenter);
            var plus = Text(line, .415f, 0f, "+", .0185f, Bright, TextAnchor.MiddleCenter);
            rows.Add(new RowView(line.gameObject, surface, label, detail, value, toggleTrack, toggleThumb, trackBar, thumb, minus, plus));
        }

        pageBack = Tile(panel, .392f, -.268f, .062f, .032f, -.007f, actionPill, .016f);
        pageForward = Tile(panel, .544f, -.268f, .062f, .032f, -.007f, actionPill, .016f);
        Text(panel, .392f, -.269f, "‹", .020f, Bright, TextAnchor.MiddleCenter);
        Text(panel, .544f, -.269f, "›", .020f, Bright, TextAnchor.MiddleCenter);
        pagination = Text(panel, .468f, -.269f, "", .013f, Muted, TextAnchor.MiddleCenter);

        cursor = Tile(panel, 0f, 0f, .009f, .009f, -.026f, white, .0044f).transform;
        cursor.gameObject.SetActive(false);
        BuildBeam(panel);
        if (textureShader != null) BuildIcons(panel, textureShader);
    }

    private void BuildKeyboard()
    {
        log.Msg("VR panel: building the search keyboard.");
        keyboardRoot = Child(root!.transform, "Search keyboard");
        keyboardRoot.gameObject.SetActive(false);
        Tile(keyboardRoot, MainCenterX, -.015f, .818f, .385f, -.012f, kbPanel, .026f);
        Tile(keyboardRoot, MainCenterX, .120f, .774f, .044f, -.013f, card, .020f);
        queryView = Text(keyboardRoot, -.212f, .120f, "", .017f, Bright);
        for (var row = 0; row < Keyboard.Length; row++)
            for (var column = 0; column < Keyboard[row].Length; column++)
                BuildKey(Keyboard[row][column].ToString(), -.145f + .064f * (column + (10 - Keyboard[row].Length) * .5f), .062f - row * .043f, .054f);
        BuildKey("Cancel", -.145f, -.134f, .098f);
        BuildKey("Space", .006f, -.134f, .156f);
        BuildKey("Delete", .148f, -.134f, .100f);
        BuildKey("Clear", .263f, -.134f, .092f);
        BuildKey("Search", .414f, -.134f, .156f);
    }

    private void BuildBeam(Transform panel)
    {
        var pointer = Child(panel, "Controller pointer").gameObject;
        try
        {
            var line = pointer.AddComponent<LineRenderer>();
            if (line == null) throw new InvalidOperationException("LineRenderer is unavailable.");
            line.enabled = false;
            line.sharedMaterial = white;
            line.useWorldSpace = true;
            line.positionCount = 2;
            line.startWidth = .0014f;
            line.endWidth = .0014f;
            beam = line;
        }
        catch (Exception exception)
        {
            Object.Destroy(pointer);
            log.Warning($"VR panel: using the cursor without a pointer beam: {exception.GetBaseException().Message}");
        }
    }

    private void Draw()
    {
        SetFocus(null);
        dirty = false;
        seenRevision = menu.Revision;
        targets.Clear();
        var section = menu.Sections[sectionIndex];
        heading!.text = editing == null ? section.Title : "Search warehouse";
        caption!.text = editing == null ? Clip(section.Description, 66) : "Point with right hand and pull Right Trigger to type.";
        message!.text = Clip(menu.Status, 54);

        for (var index = 0; index < Icons.Length; index++)
        {
            var tab = index;
            navTiles[index].sharedMaterial = tab == sectionIndex ? activeNav : rail;
            navLabels[index].color = tab == sectionIndex ? Bright : Muted;
            Add(RailCenterX, .166f - tab * .054f, .238f, .044f, () => { sectionIndex = tab; pageIndex = 0; editing = null; }, navTiles[index]);
        }

        var showKeyboard = editing != null;
        if (showKeyboard && keyboardRoot == null) BuildKeyboard();
        rowsRoot!.gameObject.SetActive(!showKeyboard);
        if (keyboardRoot != null) keyboardRoot.gameObject.SetActive(showKeyboard);
        if (showKeyboard)
        {
            queryView!.text = query.Length == 0 ? "Type to search…" : Clip(query, 48);
            pagination!.text = "FILTER";
            foreach (var key in keyTargets)
            {
                var name = key.Key;
                targets.Add(new Target(key.Bounds, _ => UseKey(name), key.Surface));
            }
            return;
        }

        var pages = (section.Rows.Length + RowsPerPage - 1) / RowsPerPage;
        pageIndex = Mathf.Clamp(pageIndex, 0, pages - 1);
        pagination!.text = $"{pageIndex + 1} / {pages}";
        pageBack!.sharedMaterial = pageIndex > 0 ? activeNav : card;
        pageForward!.sharedMaterial = pageIndex + 1 < pages ? activeNav : card;
        if (pageIndex > 0) Add(.392f, -.268f, .062f, .032f, () => pageIndex--, pageBack);
        if (pageIndex + 1 < pages) Add(.544f, -.268f, .062f, .032f, () => pageIndex++, pageForward);

        for (var index = 0; index < rows.Count; index++)
        {
            var view = rows[index];
            var rowIndex = pageIndex * RowsPerPage + index;
            view.Root.SetActive(rowIndex < section.Rows.Length);
            if (rowIndex >= section.Rows.Length) continue;
            var row = section.Rows[rowIndex];
            var detail = row.Value?.Invoke();
            var available = menu.Enabled(row);
            var surface = available ? view.Surface : null;
            var ordinate = .144f - index * .060f;
            view.Label.text = Clip(row.Title, 32);
            view.Label.color = available ? Bright : Quiet;
            view.Label.transform.localPosition = new Vector3(-.228f, string.IsNullOrEmpty(detail) ? 0f : .009f, -.018f);
            view.Detail.text = Clip(detail ?? "", 46);
            var isToggle = row.Setting?.Toggle == true;
            var isSlider = row.Setting?.Toggle == false;
            var isAction = row.Setting == null;
            view.Switch.gameObject.SetActive(isToggle || isAction);
            view.SwitchThumb.gameObject.SetActive(isToggle);
            view.Track.gameObject.SetActive(isSlider);
            view.Thumb.gameObject.SetActive(isSlider);
            view.Plus.gameObject.SetActive(isSlider);
            view.Minus.gameObject.SetActive(isSlider);
            view.Value.color = available ? Bright : Quiet;

            if (row.Setting is { } setting)
            {
                view.Value.text = available ? HubMenu.Format(setting) : "Locked";
                if (setting.Toggle)
                {
                    view.Value.anchor = TextAnchor.MiddleRight;
                    view.Value.alignment = TextAlignment.Right;
                    view.Value.transform.localPosition = new Vector3(.452f, 0f, -.018f);
                    view.Switch.transform.localPosition = new Vector3(.506f, 0f, -.010f);
                    view.Switch.transform.localScale = new Vector3(.074f, .030f, 1f);
                    view.Switch.sharedMaterial = setting.On && available ? pillOn : pillOff;
                    view.SwitchThumb.transform.localPosition = new Vector3(setting.On && available ? .523f : .489f, 0f, -.012f);
                    Add(MainCenterX, ordinate, .818f, .052f, () => menu.Activate(row, setting.On ? 0f : 1f), surface);
                }
                else
                {
                    view.Value.anchor = TextAnchor.MiddleRight;
                    view.Value.alignment = TextAlignment.Right;
                    view.Value.transform.localPosition = new Vector3(.546f, 0f, -.018f);
                    var rate = Mathf.InverseLerp(setting.Minimum, setting.Maximum, setting.Value);
                    view.Thumb.transform.localPosition = new Vector3(.205f + .180f * rate, 0f, -.011f);
                    view.Thumb.sharedMaterial = available ? white : divider;
                    view.Plus.color = view.Minus.color = available ? Bright : Quiet;
                    Add(.175f, ordinate, .044f, .048f, () => menu.Activate(row, setting.Value - setting.Step), surface);
                    Add(.415f, ordinate, .044f, .048f, () => menu.Activate(row, setting.Value + setting.Step), surface);
                    targets.Add(new Target(Box(.295f, ordinate, .180f, .048f), part => menu.Activate(row, Mathf.Lerp(setting.Minimum, setting.Maximum, part)), surface));
                }
            }
            else
            {
                view.Switch.transform.localPosition = new Vector3(.494f, 0f, -.010f);
                view.Switch.transform.localScale = new Vector3(.104f, .030f, 1f);
                view.Switch.sharedMaterial = available ? actionPill : pillOff;
                view.Value.anchor = TextAnchor.MiddleCenter;
                view.Value.alignment = TextAlignment.Center;
                view.Value.transform.localPosition = new Vector3(.494f, 0f, -.018f);
                view.Value.text = !available ? "Locked" : row.Search != null ? "Search ›" : "Open ›";
                Add(MainCenterX, ordinate, .818f, .052f, () =>
                {
                    if (row.Search != null)
                    {
                        editing = row;
                        query = detail ?? "";
                    }
                    else
                        menu.Activate(row);
                }, surface);
            }
        }
    }

    private void UseKey(string key)
    {
        switch (key)
        {
            case "Cancel": editing = null; break;
            case "Search":
                if (editing != null) menu.Activate(editing, search: query);
                editing = null;
                break;
            case "Delete": if (query.Length > 0) query = query[..^1]; break;
            case "Clear": query = ""; break;
            default: if (query.Length < 48) query += key == "Space" ? " " : key; break;
        }
    }

    private void BuildKey(string key, float x, float y, float width)
    {
        var surface = Tile(keyboardRoot!, x, y, width, .035f, -.015f, actionPill, .012f);
        Text(keyboardRoot!, x, y, key, .0145f, Bright, TextAnchor.MiddleCenter);
        keyTargets.Add((key, Box(x, y, width, .035f), surface));
    }

    private void Add(float x, float y, float width, float height, Action select, MeshRenderer? surface) =>
        targets.Add(new Target(Box(x, y, width, height), _ => select(), surface));

    private static Rect Box(float x, float y, float width, float height) => new(x - width / 2f, y - height / 2f, width, height);

    private static bool InShell(Vector3 point) =>
        InRoundedRect(point.x - RailCenterX, point.y, RailWidth, PanelHeight, ShellRadius) ||
        InRoundedRect(point.x - MainCenterX, point.y, MainWidth, PanelHeight, ShellRadius);

    private static bool InRoundedRect(float dx, float dy, float width, float height, float radius)
    {
        var cornerX = Mathf.Max(0f, Mathf.Abs(dx) - (width * .5f - radius));
        var cornerY = Mathf.Max(0f, Mathf.Abs(dy) - (height * .5f - radius));
        return cornerX * cornerX + cornerY * cornerY <= radius * radius;
    }

    private void BuildIcons(Transform panel, Shader shader)
    {
        log.Msg("VR panel: loading optional navigation icons.");
        try
        {
            for (var index = 0; index < Icons.Length; index++)
                if (Icon(Icons[index], shader) is { } material)
                    Tile(panel, -.544f, .166f - index * .054f, .021f, .021f, -.010f, material);
        }
        catch (Exception exception)
        {
            log.Warning($"VR panel: some navigation icons are unavailable: {exception.GetBaseException().Message}");
        }
    }

    private Material? Icon(string name, Shader shader)
    {
        using var bytes = typeof(VrPanel).Assembly.GetManifestResourceStream("Avelis.Icons." + name);
        if (bytes == null || bytes.Length != 1024) return null;
        var content = new byte[1024];
        bytes.ReadExactly(content);
        var pixels = new byte[content.Length * 4];
        Array.Fill(pixels, byte.MaxValue);
        for (var index = 0; index < content.Length; index++) pixels[index * 4 + 3] = content[index];
        var texture = new Texture2D(32, 32, TextureFormat.RGBA32, false);
        assets.Add(texture);
        texture.LoadRawTextureData(new Il2CppStructArray<byte>(pixels));
        texture.Apply(false, true);
        var material = Material(shader, Color.white, 3002);
        material.mainTexture = texture;
        return material;
    }

    private Shader? FindShader(string name)
    {
        try
        {
            var shader = Shader.Find(name);
            return shader != null && shader.isSupported ? shader : null;
        }
        catch (Exception exception)
        {
            log.Warning($"VR panel: shader {name} is unavailable: {exception.GetBaseException().Message}");
            return null;
        }
    }

    private Material Material(Shader shader, Color color, int queue)
    {
        var material = new Material(shader);
        assets.Add(material);
        material.renderQueue = queue;
        if (material.HasProperty("_BaseColor")) material.SetColor("_BaseColor", color);
        else if (material.HasProperty("_Color")) material.SetColor("_Color", color);
        return material;
    }

    private Mesh CreateQuad() => CreateMesh(new Vector3[]
    {
        new(-.5f, -.5f, 0f), new(-.5f, .5f, 0f), new(.5f, .5f, 0f), new(.5f, -.5f, 0f)
    }, new[] { 0, 1, 2, 0, 2, 3 });

    private Mesh RoundedMesh(float width, float height, float radius)
    {
        var shape = (width, height, radius);
        if (roundedMeshes.TryGetValue(shape, out var cached)) return cached;
        const int cornerSteps = 6;
        const int perimeter = 4 * (cornerSteps + 1);
        var vertices = new Vector3[perimeter + 1];
        var triangles = new int[perimeter * 3];
        var radiusX = radius / width;
        var radiusY = radius / height;
        for (var corner = 0; corner < 4; corner++)
        {
            var centerX = (.5f - radiusX) * (corner < 2 ? 1f : -1f);
            var centerY = (.5f - radiusY) * (corner is 0 or 3 ? 1f : -1f);
            for (var step = 0; step <= cornerSteps; step++)
            {
                var angle = MathF.PI * .5f * (1f - corner - step / (float)cornerSteps);
                var index = corner * (cornerSteps + 1) + step;
                vertices[index + 1] = new Vector3(centerX + radiusX * MathF.Cos(angle), centerY + radiusY * MathF.Sin(angle), 0f);
                triangles[index * 3 + 1] = index + 1;
                triangles[index * 3 + 2] = (index + 1) % perimeter + 1;
            }
        }
        var mesh = CreateMesh(vertices, triangles);
        roundedMeshes.Add(shape, mesh);
        return mesh;
    }

    private Mesh CreateMesh(Vector3[] vertices, int[] triangles)
    {
        var uv = new Vector2[vertices.Length];
        for (var index = 0; index < vertices.Length; index++)
            uv[index] = new Vector2(vertices[index].x + .5f, vertices[index].y + .5f);
        var mesh = new Mesh();
        assets.Add(mesh);
        mesh.vertices = new Il2CppStructArray<Vector3>(vertices);
        mesh.uv = new Il2CppStructArray<Vector2>(uv);
        mesh.triangles = new Il2CppStructArray<int>(triangles);
        return mesh;
    }

    private static Transform Child(Transform parent, string name)
    {
        var child = new GameObject(name).transform;
        child.SetParent(parent, false);
        return child;
    }

    private MeshRenderer Tile(Transform parent, float x, float y, float width, float height, float depth, Material material, float radius = 0f)
    {
        var tile = Child(parent, "Tile");
        tile.localPosition = new Vector3(x, y, depth);
        tile.localScale = new Vector3(width, height, 1f);
        var filter = tile.gameObject.AddComponent<MeshFilter>();
        var renderer = tile.gameObject.AddComponent<MeshRenderer>();
        if (filter == null || renderer == null) throw new InvalidOperationException("Cannot add the VR panel mesh components.");
        filter.sharedMesh = radius > 0f ? RoundedMesh(width, height, radius) : quad;
        renderer.sharedMaterial = material;
        return renderer;
    }

    private static TextMesh Text(Transform parent, float x, float y, string text, float size, Color color, TextAnchor anchor = TextAnchor.MiddleLeft)
    {
        var item = Child(parent, "Label");
        item.localPosition = new Vector3(x, y, -.018f);
        var mesh = item.gameObject.AddComponent<TextMesh>();
        if (mesh == null) throw new InvalidOperationException("TextMesh is unavailable for VR panel labels.");
        mesh.fontSize = 48;
        mesh.characterSize = size * .31f;
        mesh.anchor = anchor;
        mesh.alignment = anchor is TextAnchor.MiddleCenter or TextAnchor.UpperCenter or TextAnchor.LowerCenter
            ? TextAlignment.Center
            : anchor is TextAnchor.MiddleRight or TextAnchor.UpperRight or TextAnchor.LowerRight
                ? TextAlignment.Right
                : TextAlignment.Left;
        mesh.richText = false;
        mesh.color = color;
        mesh.text = text;
        return mesh;
    }

    private static string Clip(string value, int length)
    {
        if (value.AsSpan().Contains('\n') || value.AsSpan().Contains('\r')) value = value.Replace('\n', ' ').Replace('\r', ' ');
        return value.Length <= length ? value : value[..(length - 1)] + "…";
    }

    private void Fail(string stage, Exception exception)
    {
        failed = true;
        log.Error($"VR panel failed while {stage}; Bone Menu remains available. {exception}");
        try { Dispose(); }
        catch (Exception cleanup) { log.Warning($"VR panel cleanup failed: {cleanup.GetBaseException().Message}"); }
    }

    public void Dispose()
    {
        var panelRoot = root;
        root = null;
        if (panelRoot != null)
        {
            panelRoot.SetActive(false);
            Object.Destroy(panelRoot);
        }
        foreach (var asset in assets) if (asset != null) Object.Destroy(asset);
        assets.Clear();
        roundedMeshes.Clear();
    }
}
