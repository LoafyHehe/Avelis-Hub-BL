#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")/.."

sdk_version=8.0.419
dotnet_bin=dotnet
if ! command -v dotnet >/dev/null || ! dotnet --list-sdks | grep -E '^8\.0\.' >/dev/null; then
  sdk_dir="$PWD/.dotnet-sdk"
  if [[ ! -x "$sdk_dir/dotnet" ]]; then
    installer=$(mktemp)
    trap 'rm -f "$installer"' EXIT
    curl --fail --silent --show-error --location https://dot.net/v1/dotnet-install.sh -o "$installer"
    bash "$installer" --version "$sdk_version" --install-dir "$sdk_dir" --no-path
    rm -f "$installer"
    trap - EXIT
  fi
  dotnet_bin="$sdk_dir/dotnet"
fi

scratch=$(mktemp -d)
trap 'rm -rf "$scratch"' EXIT
export DOTNET_CLI_TELEMETRY_OPTOUT=1
export DOTNET_NOLOGO=1

"$dotnet_bin" publish AvelisHubBL/AvelisHubBL.csproj --configuration Release --output "$scratch/payload" \
  -p:BaseOutputPath="$scratch/bin/" -p:BaseIntermediateOutputPath="$scratch/obj/" \
  -p:RestoreIgnoreFailedSources=true

mkdir -p dist
install -m 644 "$scratch/payload/AvelisHubBL.dll" dist/AvelisHubBL.dll
install -m 644 scripts/download.html dist/index.html
install -m 644 README.md dist/README.txt
install -m 644 AvelisHubBL/Menu/Icons/LICENSE dist/Lucide-LICENSE.txt
zip -q -r "$scratch/AvelisHubBL-source.zip" AvelisHubBL README.md AGENTS.md scripts netlify.toml .gitignore \
  -x '*/bin/*' '*/obj/*'
install -m 644 "$scratch/AvelisHubBL-source.zip" dist/AvelisHubBL-source.zip
(
  cd dist
  sha256sum AvelisHubBL.dll AvelisHubBL-source.zip > SHA256SUMS.txt
)
