using BoneLib;
using AvelisHubBL.Core;
using HarmonyLib;
using System.Reflection;
using UnityEngine;

namespace AvelisHubBL.Features;

internal sealed class PlayerTools(HubSettings initialSettings, Func<bool> canModifyGameplay)
{
    private readonly HubSettings settings = initialSettings;
    private readonly Func<bool> gameplayAllowed = canModifyGameplay;
    private readonly Func<object?, Component>? getRig = GameApi.Read<Component>(typeof(Player), "RigManager");
    private readonly Func<object?, Component>? getPhysics = GameApi.Read<Component>(typeof(Player), "PhysicsRig");
    private readonly Func<object?, Component>? getRemap = GameApi.Read<Component>(typeof(Player), "RemapRig");
    private readonly Func<object?, object>? getLeft = GameApi.Read<object>(typeof(Player), "LeftController");
    private readonly Func<object?, object>? getRight = GameApi.Read<object>(typeof(Player), "RightController");
    private readonly Func<object?, object>? getLeftHand = GameApi.Read<object>(typeof(Player), "LeftHand");
    private readonly Func<object?, object>? getRightHand = GameApi.Read<object>(typeof(Player), "RightHand");
    private readonly List<Collider> disabledColliders = new();
    private readonly List<Rigidbody> frozenBodies = new();
    private Func<object?, object>? getHealth, getAvatar, getAttached, getGrounder, getTorso;
    private Func<object?, Rigidbody>? getPelvis;
    private Func<object?, bool>? buttonA, buttonB, buttonADown, grounded, alive;
    private Func<object?, Vector2>? stick;
    private Func<object?, object>? readHealthMode;
    private Action<object, object>? writeHealthMode;
    private object? invincible;
    private Func<object?, float>? maxHealth, readSpeed;
    private Action<object, float>? writeHealth, writeSpeed;
    private MethodInfo? teleport, createTransform, resetPose, resetHands;
    private Func<object?, object>? remapRigs;
    private Func<object?, object>? marrowEntity;
    private Func<object?, Transform>? pressure;
    private Component? physicsRig;
    private Component? rig;
    private object? protectedHealth, previousMode, modifiedAvatar, collisionAvatar, bothHands;
    private float previousSpeed, appliedSpeed;
    private bool jumped, noclipApplied, freezeApplied;
    private static PlayerTools? active;

    internal bool CanJump { get; private set; }
    internal bool CanInput => buttonA != null && buttonB != null && buttonADown != null;
    internal bool CanFly => stick != null && getPelvis != null;
    internal bool CanTeleport => teleport != null && createTransform != null && remapRigs != null && pressure != null;
    internal bool CanGod => invincible != null && writeHealthMode != null && readHealthMode != null;
    internal bool CanHeal => getHealth != null && maxHealth != null && writeHealth != null;
    internal bool CanSpeed => readSpeed != null && writeSpeed != null && getAvatar != null;
    internal Transform? Head => Player.Head;
    internal Transform? Aim => getRight?.Invoke(null) is Component controller && controller != null ? controller.transform :
        getRightHand?.Invoke(null) is Component hand && hand != null ? hand.transform : null;
    internal GameObject? HeldLeft => Held(getLeftHand?.Invoke(null));
    internal GameObject? HeldRight => Held(getRightHand?.Invoke(null));

    internal void Bind(global::HarmonyLib.Harmony harmony)
    {
        active = this;
        var rigType = GameApi.Marrow("RigManager");
        var physicsType = GameApi.Marrow("PhysicsRig");
        var controller = GameApi.MemberType(typeof(Player), "LeftController");
        var hand = GameApi.MemberType(typeof(Player), "LeftHand");
        var healthType = GameApi.MemberType(rigType, "health");
        var avatar = GameApi.MemberType(rigType, "avatar");
        var locomotion = GameApi.Marrow("Rig");
        var pose = GameApi.Marrow("Utilities.SimpleTransform");
        var torso = GameApi.MemberType(physicsType, "torso");
        var grounder = GameApi.MemberType(physicsType, "physG");

        getHealth = GameApi.Read<object>(rigType, "health");
        getAvatar = GameApi.Read<object>(rigType, "avatar");
        getAttached = GameApi.Read<object>(hand, "m_CurrentAttachedGO");
        getGrounder = GameApi.Read<object>(physicsType, "physG");
        grounded = GameApi.Read<bool>(grounder, "isGrounded");
        getTorso = GameApi.Read<object>(physicsType, "torso");
        getPelvis = GameApi.Read<Rigidbody>(torso, "rbPelvis");
        buttonA = GameApi.Call<bool>(GameApi.Method(controller, "GetAButton"));
        buttonB = GameApi.Call<bool>(GameApi.Method(controller, "GetBButton"));
        buttonADown = GameApi.Call<bool>(GameApi.Method(controller, "GetAButtonDown"));
        stick = GameApi.Call<Vector2>(GameApi.Method(controller, "GetThumbStickAxis"));
        alive = GameApi.Read<bool>(healthType, "alive");
        readHealthMode = GameApi.Read<object>(healthType, "healthMode");
        writeHealthMode = GameApi.WriteBoxed(healthType, "healthMode");
        var mode = GameApi.MemberType(healthType, "healthMode");
        if (mode?.IsEnum == true && Enum.IsDefined(mode, "Invincible"))
            invincible = Enum.Parse(mode, "Invincible");
        maxHealth = GameApi.Read<float>(healthType, "max_Health");
        writeHealth = GameApi.Write<float>(healthType, "curr_Health");
        readSpeed = GameApi.Read<float>(avatar, "_speed");
        writeSpeed = GameApi.Write<float>(avatar, "_speed");
        remapRigs = GameApi.Read<object>(rigType, "remapRigs");
        pressure = GameApi.Read<Transform>(locomotion, "centerOfPressure");
        marrowEntity = GameApi.Read<object>(physicsType, "marrowEntity");
        resetPose = GameApi.Method(GameApi.MemberType(physicsType, "marrowEntity"), "ResetPose", typeof(bool));
        var handedness = GameApi.Marrow("Interaction.Handedness");
        if (handedness?.IsEnum == true && Enum.IsDefined(handedness, "BOTH"))
        {
            resetHands = GameApi.Method(physicsType, "ResetHands", handedness);
            bothHands = Enum.Parse(handedness, "BOTH");
        }
        if (pose != null)
        {
            teleport = GameApi.Method(locomotion, "Teleport", pose, typeof(bool));
            createTransform = GameApi.Method(pose, "Create", typeof(Vector3), typeof(Quaternion));
        }
        var jump = GameApi.Unique(GameApi.Marrow("RemapRig"), "Jump");
        if (jump != null && grounded != null && getPelvis != null)
        {
            try
            {
                harmony.Patch(jump, prefix: new HarmonyMethod(typeof(PlayerTools), nameof(OnJump)));
                CanJump = true;
            }
            catch (Exception exception)
            {
                MelonLoader.MelonLogger.Warning("Avelis: jump hook unavailable: " + exception.Message);
            }
        }
    }

    private GameObject? Held(object? hand) => GameApi.Alive(hand) ? getAttached?.Invoke(hand) as GameObject : null;
    internal bool Chord => ReadButton(getLeft, buttonA) && ReadButton(getLeft, buttonB);
    internal bool Select => ReadButton(getRight, buttonADown);

    private static bool ReadButton(Func<object?, object>? getter, Func<object?, bool>? read)
    {
        var controller = getter?.Invoke(null);
        return GameApi.Alive(controller) && read?.Invoke(controller) == true;
    }

    private Vector2 ReadStick(Func<object?, object>? getter)
    {
        var controller = getter?.Invoke(null);
        return GameApi.Alive(controller) ? stick?.Invoke(controller) ?? Vector2.zero : Vector2.zero;
    }

    private Rigidbody? Pelvis()
    {
        var torso = physicsRig != null ? getTorso?.Invoke(physicsRig) : null;
        return GameApi.Alive(torso) ? getPelvis?.Invoke(torso) : null;
    }

    internal void FixedUpdate(bool menuOpen)
    {
        var current = getRig?.Invoke(null);
        var currentPhysics = getPhysics?.Invoke(null);
        if (current != rig || currentPhysics != physicsRig)
        {
            Restore();
            rig = current;
            physicsRig = currentPhysics;
        }
        if (rig == null || physicsRig == null)
            return;

        UpdateHealth();
        UpdateSpeed();
        UpdatePhysicsModes();
        var jump = jumped;
        jumped = false;

        if (frozenBodies.Count != 0)
            return;
        if (settings.Flight.On || settings.Noclip.On)
        {
            var head = Head;
            var pelvis = Pelvis();
            if (head == null || pelvis == null || pelvis.isKinematic)
                return;
            var horizontal = menuOpen ? Vector2.zero : ReadStick(getLeft);
            var vertical = menuOpen ? 0f : ReadStick(getRight).y;
            if (Mathf.Abs(vertical) < .18f) vertical = 0f;
            if (horizontal.sqrMagnitude < .035f) horizontal = Vector2.zero;
            var forward = Vector3.ProjectOnPlane(head.forward, Vector3.up).normalized;
            var side = Vector3.Cross(Vector3.up, forward);
            var desired = Vector3.ClampMagnitude(forward * horizontal.y + side * horizontal.x + Vector3.up * vertical, 1f) * settings.FlySpeed.Value;
            pelvis.AddForce(desired - pelvis.velocity, ForceMode.VelocityChange);
        }
        else if (jump && settings.Jump.Value > 1f)
        {
            var pelvis = Pelvis();
            if (pelvis != null && !pelvis.isKinematic)
                pelvis.AddForce(Vector3.up * (settings.Jump.Value - 1f) * 2.5f, ForceMode.VelocityChange);
        }
    }

    private static void OnJump(object __instance)
    {
        var tools = active;
        if (tools == null || tools.settings.Jump.Value <= 1f || !tools.gameplayAllowed() ||
            (__instance as Component) != tools.getRemap?.Invoke(null) || tools.physicsRig == null)
            return;
        var grounder = tools.getGrounder?.Invoke(tools.physicsRig);
        tools.jumped = GameApi.Alive(grounder) && tools.grounded?.Invoke(grounder) == true;
    }

    private void UpdateHealth()
    {
        if (!settings.God.On || !CanGod)
        {
            RestoreHealth();
            return;
        }
        var health = getHealth?.Invoke(rig);
        if (!GameApi.Alive(health))
        {
            RestoreHealth();
            return;
        }
        if (!SameObject(health, protectedHealth))
        {
            RestoreHealth();
            protectedHealth = health;
            previousMode = readHealthMode!(health);
        }
        if (!Equals(readHealthMode!(health), invincible))
            writeHealthMode!(health!, invincible!);
    }

    internal string Heal()
    {
        var health = rig != null ? getHealth?.Invoke(rig) : null;
        if (!CanHeal || !GameApi.Alive(health) || alive?.Invoke(health) == false)
            return "No living local player to heal.";
        writeHealth!(health!, maxHealth!(health));
        return "Health restored.";
    }

    private void UpdateSpeed()
    {
        if (!CanSpeed || settings.Speed.Value == 1f)
        {
            RestoreSpeed();
            return;
        }
        var avatar = getAvatar!(rig);
        if (!GameApi.Alive(avatar))
        {
            RestoreSpeed();
            return;
        }
        if (!SameObject(avatar, modifiedAvatar))
        {
            RestoreSpeed();
            previousSpeed = readSpeed!(avatar);
            appliedSpeed = previousSpeed;
            modifiedAvatar = avatar;
        }
        var speed = previousSpeed * settings.Speed.Value;
        if (!Mathf.Approximately(speed, appliedSpeed))
        {
            writeSpeed!(avatar, speed);
            appliedSpeed = speed;
        }
    }

    private void UpdatePhysicsModes()
    {
        if (settings.Noclip.On || settings.Freeze.On)
        {
            var avatar = getAvatar?.Invoke(rig);
            if (!SameObject(collisionAvatar, avatar))
            {
                RestoreColliders();
                RestoreBodies();
                collisionAvatar = avatar;
            }
        }
        else
            collisionAvatar = null;

        if (settings.Noclip.On != noclipApplied)
        {
            RestoreColliders();
            noclipApplied = settings.Noclip.On;
            if (noclipApplied)
                foreach (var collider in physicsRig!.GetComponentsInChildren<Collider>(true))
                    if (collider != null && collider.enabled && !collider.isTrigger)
                    {
                        disabledColliders.Add(collider);
                        collider.enabled = false;
                    }
        }
        if (settings.Freeze.On != freezeApplied)
        {
            RestoreBodies();
            freezeApplied = settings.Freeze.On;
            if (freezeApplied)
                foreach (var body in physicsRig!.GetComponentsInChildren<Rigidbody>(true))
                    if (body != null && !body.isKinematic)
                    {
                        frozenBodies.Add(body);
                        body.velocity = Vector3.zero;
                        body.angularVelocity = Vector3.zero;
                        body.isKinematic = true;
                    }
        }
    }

    internal string Teleport()
    {
        var head = Head;
        if (!CanTeleport || rig == null || physicsRig == null || head == null || freezeApplied)
            return "Teleport unavailable for this rig.";
        var distance = settings.Teleport.Value;
        if (TryRay(head.position, head.forward, distance, out var obstruction))
            distance = obstruction.distance - .55f;
        if (distance < .65f)
            return "Teleport blocked by nearby geometry.";
        var face = head.position + head.forward * distance;
        if (!TryRay(face + Vector3.up * .35f, Vector3.down, 4f, out var floor) || floor.normal.y < .65f)
            return "No walkable landing in range.";

        var centerOfPressure = pressure!(physicsRig);
        if (centerOfPressure == null) return "The local rig has no pressure center yet.";
        var target = floor.point + Vector3.up * .05f;
        const float radius = .24f;
        var height = Mathf.Clamp(head.position.y - centerOfPressure.position.y, .95f, 2f);
        foreach (var collider in Physics.OverlapCapsule(target + Vector3.up * (radius + .06f), target + Vector3.up * (height - radius + .08f), radius, Physics.DefaultRaycastLayers, QueryTriggerInteraction.Ignore))
            if (collider != null && !PartOfRig(collider.transform))
                return "Teleport blocked: not enough clearance.";

        var others = GameApi.Items(remapRigs!(rig)).OfType<Component>().Where(component => component != null && component != physicsRig).ToArray();
        if (resetPose != null && marrowEntity?.Invoke(physicsRig) is { } entity && GameApi.Alive(entity))
        {
            resetPose.Invoke(entity, new object[] { true });
            centerOfPressure.SetLocalPositionAndRotation(Vector3.zero, Quaternion.identity);
        }
        MoveRig(physicsRig, target);
        if (bothHands != null) resetHands?.Invoke(physicsRig, new[] { bothHands });
        foreach (var other in others)
            MoveRig(other, target);
        return "Teleported.";
    }

    private void MoveRig(Component component, Vector3 location)
    {
        var center = pressure!(component);
        if (center == null)
            return;
        var offset = createTransform!.Invoke(null, new object[] { location - center.position, Quaternion.identity });
        teleport!.Invoke(component, new[] { offset, (object)true });
    }

    internal bool TryRay(Vector3 origin, Vector3 direction, float distance, out RaycastHit closest)
    {
        closest = default;
        var nearest = distance;
        var found = false;
        foreach (var hit in Physics.RaycastAll(origin, direction, distance, Physics.DefaultRaycastLayers, QueryTriggerInteraction.Ignore))
        {
            if (hit.distance >= nearest || hit.collider == null || PartOfRig(hit.collider.transform))
                continue;
            closest = hit;
            nearest = hit.distance;
            found = true;
        }
        return found;
    }

    private bool PartOfRig(Transform target) => rig != null && target.IsChildOf(rig.transform);

    internal static bool SameObject(object? left, object? right) => left is UnityEngine.Object unity && right is UnityEngine.Object other
        ? unity == other : ReferenceEquals(left, right);

    private void RestoreHealth()
    {
        if (GameApi.Alive(protectedHealth) && previousMode != null && Equals(readHealthMode?.Invoke(protectedHealth), invincible))
            writeHealthMode?.Invoke(protectedHealth!, previousMode);
        protectedHealth = null;
        previousMode = null;
    }

    private void RestoreSpeed()
    {
        if (GameApi.Alive(modifiedAvatar) && readSpeed != null && Mathf.Approximately(readSpeed(modifiedAvatar), appliedSpeed))
            writeSpeed?.Invoke(modifiedAvatar!, previousSpeed);
        modifiedAvatar = null;
    }

    private void RestoreColliders()
    {
        foreach (var collider in disabledColliders)
            if (collider != null)
                collider.enabled = true;
        disabledColliders.Clear();
        noclipApplied = false;
    }

    private void RestoreBodies()
    {
        foreach (var body in frozenBodies)
            if (body != null)
                body.isKinematic = false;
        frozenBodies.Clear();
        freezeApplied = false;
    }

    internal void Restore()
    {
        RestoreHealth();
        RestoreSpeed();
        RestoreColliders();
        RestoreBodies();
        collisionAvatar = null;
        jumped = false;
    }
}
