using System.Collections.Concurrent;
using System.Reflection;
using AvelisHubBL.Core;
using HarmonyLib;
using MelonLoader;
using UnityEngine;

namespace AvelisHubBL.Features;

internal sealed class SpawnTools(HubSettings settings, PlayerTools player)
{
    internal enum Kind { All, Objects, Weapons, Firearms, Melee, NPCs, Vehicles }
    private sealed record Crate(string Barcode, string Title, Kind Category);

    private sealed class Spawned(Crate crate, Component poolee)
    {
        internal Crate Crate { get; } = crate;
        internal Component Poolee { get; } = poolee;
        internal Transform OriginalTransform { get; } = poolee.transform;
        internal Vector3 Origin { get; } = poolee.transform.position;
        internal Quaternion Rotation { get; } = poolee.transform.rotation;
        internal Vector3 Scale { get; } = poolee.transform.localScale;
        internal readonly List<Rigidbody> Frozen = new();
        internal readonly List<Behaviour> Paused = new();
        internal bool IsFrozen;
        internal bool Transformed;
    }

    private const int MaximumActive = 30;
    private static SpawnTools? active;
    private readonly List<Crate> catalog = new();
    private readonly List<Crate> matches = new();
    private readonly List<Spawned> tracked = new();
    private readonly Dictionary<string, object> registered = new(StringComparer.Ordinal);
    private readonly ConcurrentQueue<(Crate Crate, Component? Item, int Epoch, int NpcEpoch)> completed = new();
    private Func<object?, object>? warehouse, crateBarcode, getAwaiter;
    private Func<object?, string>? title, barcodeValue;
    private Func<object?, object>? tags, puppetBehaviours;
    private Func<object?, Component>? getResult;
    private ConstructorInfo? crateReference, spawnable;
    private MethodInfo? list, register, spawnAsync, onCompleted;
    private Action<object, object>? setCrate;
    private Action<object>? despawn;
    private Func<GameObject, object?>? puppet;
    private int matchIndex, trackedIndex, pending, epoch, npcEpoch;

    internal Kind Category { get; private set; }
    internal string Query { get; private set; } = "";
    internal bool CanBrowse => list != null && warehouse != null && crateBarcode != null && barcodeValue != null && title != null;
    internal bool CanSpawn { get; private set; }
    internal string SelectedCrate => matches.Count == 0 ? "No matching crates" : $"{matchIndex + 1}/{matches.Count} · {matches[matchIndex].Title}";
    internal string SelectedObject => Current is { } item ? $"{item.Crate.Title}{(item.IsFrozen ? " [frozen]" : "")}" : "No tracked object";
    internal string Progress => $"{tracked.Count} active · {pending} pending";
    private Spawned? Current => tracked.Count == 0 ? null : tracked[trackedIndex];

    internal void Bind(global::HarmonyLib.Harmony harmony)
    {
        active = this;
        var warehouseType = GameApi.Marrow("Warehouse.AssetWarehouse");
        var crateType = GameApi.Marrow("Warehouse.SpawnableCrate");
        var barcode = GameApi.MemberType(crateType, "Barcode");
        var spawnableType = GameApi.Marrow("Data.Spawnable");
        var referenceType = GameApi.Marrow("Warehouse.SpawnableCrateReference");
        var assetSpawner = GameApi.Marrow("Pool.AssetSpawner");
        var poolee = GameApi.Marrow("Pool.Poolee");
        var puppetType = GameApi.Marrow("PuppetMasta.PuppetMaster");
        warehouse = GameApi.Read<object>(warehouseType, "Instance");
        crateBarcode = GameApi.Read<object>(crateType, "Barcode");
        barcodeValue = GameApi.Read<string>(barcode, "ID");
        title = GameApi.Read<string>(crateType, "Title");
        tags = GameApi.Read<object>(crateType, "Tags");
        puppet = GameApi.ComponentLookup(puppetType);
        puppetBehaviours = GameApi.Read<object>(puppetType, "behaviours");
        if (crateType != null)
        {
            list = warehouseType?.GetMethods().Where(method => method.Name == "GetCrates" && method.IsGenericMethodDefinition &&
                method.GetGenericArguments().Length == 1 && method.GetParameters().All(parameter => parameter.HasDefaultValue))
                .OrderBy(method => method.GetParameters().Length).FirstOrDefault()?.MakeGenericMethod(crateType);
        }

        if (spawnableType == null || referenceType == null || poolee == null)
            return;
        crateReference = referenceType.GetConstructor(new[] { typeof(string) });
        spawnable = spawnableType.GetConstructor(Type.EmptyTypes);
        setCrate = GameApi.WriteBoxed(spawnableType, "crateRef");
        register = GameApi.Method(assetSpawner, "Register", spawnableType);
        var signature = new[] { spawnableType, typeof(Vector3), typeof(Quaternion), typeof(Il2CppSystem.Nullable<Vector3>), typeof(Transform),
            typeof(bool), typeof(Il2CppSystem.Nullable<int>), typeof(Il2CppSystem.Action<GameObject>), typeof(Il2CppSystem.Action<GameObject>) };
        spawnAsync = GameApi.Method(assetSpawner, "SpawnAsync", signature.Append(typeof(Il2CppSystem.Action<GameObject>)).ToArray()) ??
            GameApi.Method(assetSpawner, "SpawnAsync", signature);
        var awaiter = GameApi.Method(spawnAsync?.ReturnType, "GetAwaiter");
        getAwaiter = GameApi.Call<object>(awaiter);
        getResult = GameApi.Call<Component>(GameApi.Method(awaiter?.ReturnType, "GetResult"));
        onCompleted = GameApi.Method(awaiter?.ReturnType, "OnCompleted", typeof(Il2CppSystem.Action));
        despawn = GameApi.Action(GameApi.Method(poolee, "Despawn"));
        var notification = GameApi.Unique(poolee, "OnDespawnEvent");
        if (notification == null || despawn == null || !CanBrowse || spawnAsync == null || getAwaiter == null || getResult == null ||
            onCompleted == null || crateReference == null || spawnable == null || setCrate == null || register == null)
            return;
        try
        {
            harmony.Patch(notification, prefix: new HarmonyMethod(typeof(SpawnTools), nameof(OnDespawn)));
            CanSpawn = true;
        }
        catch (Exception exception)
        {
            MelonLogger.Warning("Avelis: pool tracking hook unavailable: " + exception.Message);
        }
    }

    internal string Refresh()
    {
        if (!CanBrowse || warehouse?.Invoke(null) is not { } source)
            return "The asset warehouse is not ready.";
        var crates = list!.Invoke(source, list.GetParameters().Select(parameter => parameter.DefaultValue).ToArray());
        var seen = new HashSet<string>(StringComparer.Ordinal);
        var updated = new List<Crate>();
        foreach (var crate in GameApi.Items(crates))
        {
            if (crateBarcode!(crate) is not { } identity) continue;
            var code = barcodeValue!(identity);
            if (string.IsNullOrWhiteSpace(code) || !seen.Add(code))
                continue;
            var name = title!(crate);
            updated.Add(new Crate(code, string.IsNullOrWhiteSpace(name) ? code : name, Classify(tags?.Invoke(crate))));
        }
        updated.Sort((left, right) => StringComparer.OrdinalIgnoreCase.Compare(left.Title, right.Title));
        catalog.Clear();
        catalog.AddRange(updated);
        ApplyFilter();
        return $"Indexed {catalog.Count} spawnable crates.";
    }

    private static Kind Classify(object? values)
    {
        var result = Kind.Objects;
        foreach (var tag in GameApi.Items(values))
        {
            var value = tag.ToString()?.Trim().ToLowerInvariant();
            if (value is "npc" or "npcs" or "enemy" or "enemies") return Kind.NPCs;
            if (value is "vehicle" or "vehicles") return Kind.Vehicles;
            if (value is "gun" or "guns" or "firearm" or "firearms" or "pistol" or "rifle" or "shotgun") result = Kind.Firearms;
            if (value is "melee" or "melee weapon") result = Kind.Melee;
            if (result == Kind.Objects && (value is "weapon" or "weapons")) result = Kind.Weapons;
        }
        return result;
    }

    internal string SetCategory(Kind category)
    {
        Category = category;
        if (catalog.Count == 0)
            return Refresh();
        ApplyFilter();
        return $"{category}: {matches.Count} matching crates.";
    }

    internal string Search(string query)
    {
        Query = query.Trim();
        if (Query.Length > 48) Query = Query[..48];
        if (catalog.Count == 0)
            return Refresh();
        ApplyFilter();
        return $"{matches.Count} matching crates.";
    }

    private void ApplyFilter()
    {
        matches.Clear();
        matchIndex = 0;
        foreach (var crate in catalog)
            if ((Category == Kind.All || Category == crate.Category || (Category == Kind.Weapons && crate.Category is Kind.Firearms or Kind.Melee)) && (Query.Length == 0 ||
                crate.Title.Contains(Query, StringComparison.OrdinalIgnoreCase) || crate.Barcode.Contains(Query, StringComparison.OrdinalIgnoreCase)))
                matches.Add(crate);
    }

    internal string Browse(int step)
    {
        if (matches.Count > 0)
            matchIndex = (matchIndex + step % matches.Count + matches.Count) % matches.Count;
        return SelectedCrate;
    }

    internal string SpawnSelected()
    {
        var head = player.Head;
        if (!CanSpawn || head == null || matches.Count == 0)
            return "Choose a crate and enter a playable scene first.";
        var count = Math.Min((int)settings.SpawnCount.Value, MaximumActive - tracked.Count - pending);
        if (count <= 0)
            return "Spawn limit reached. Remove tracked objects first.";
        var crate = matches[matchIndex];
        var entry = RegisterCrate(crate);
        var distance = settings.SpawnDistance.Value;
        if (player.TryRay(head.position, head.forward, distance, out var wall))
            distance = wall.distance - .45f;
        if (distance < .65f)
            return "Spawn blocked by nearby geometry.";

        var center = head.position + head.forward * distance;
        var facing = Vector3.ProjectOnPlane(head.forward, Vector3.up);
        if (facing.sqrMagnitude < .01f) facing = Vector3.forward;
        var rotation = Quaternion.LookRotation(facing) * Quaternion.Euler(0f, settings.SpawnYaw.Value, 0f);
        var requestEpoch = epoch;
        var requestNpcEpoch = npcEpoch;
        for (var index = 0; index < count; index++)
        {
            var position = center + rotation * Vector3.right * (index - (count - 1) * .5f) * 1.15f;
            if (settings.SpawnFloor.On || crate.Category is Kind.NPCs or Kind.Vehicles)
                if (player.TryRay(position + Vector3.up * .35f, Vector3.down, 5f, out var floor))
                    position = floor.point + Vector3.up * .08f;
            var scale = new Il2CppSystem.Nullable<Vector3>(Vector3.zero) { hasValue = false };
            var group = new Il2CppSystem.Nullable<int>(0) { hasValue = false };
            var arguments = new object?[spawnAsync!.GetParameters().Length];
            arguments[0] = entry;
            arguments[1] = position;
            arguments[2] = rotation;
            arguments[3] = scale;
            arguments[5] = false;
            arguments[6] = group;
            var task = spawnAsync.Invoke(null, arguments);
            var awaiter = getAwaiter!(task);
            if (awaiter == null)
                continue;
            var callback = (Il2CppSystem.Action)(Action)(() => Complete(crate, awaiter, requestEpoch, requestNpcEpoch));
            pending++;
            try { onCompleted!.Invoke(awaiter, new object[] { callback }); }
            catch
            {
                pending--;
                throw;
            }
        }
        return $"Requested {count} × {crate.Title}.";
    }

    private object RegisterCrate(Crate crate)
    {
        if (registered.TryGetValue(crate.Barcode, out var existing))
            return existing;
        var item = spawnable!.Invoke(null);
        setCrate!(item, crateReference!.Invoke(new object[] { crate.Barcode }));
        register!.Invoke(null, new[] { item });
        registered.Add(crate.Barcode, item);
        return item;
    }

    private void Complete(Crate crate, object awaiter, int requestEpoch, int requestNpcEpoch)
    {
        Component? item = null;
        try { item = getResult!(awaiter); }
        catch (Exception exception) { MelonLogger.Warning("Avelis: spawn failed: " + exception.GetBaseException().Message); }
        completed.Enqueue((crate, item, requestEpoch, requestNpcEpoch));
    }

    internal bool Update(bool allowGameplay)
    {
        var changed = false;
        while (completed.TryDequeue(out var result))
        {
            changed = true;
            if (result.Epoch == epoch) pending = Math.Max(0, pending - 1);
            if (result.Item == null)
                continue;
            if (result.Epoch != epoch || (result.Crate.Category == Kind.NPCs && result.NpcEpoch != npcEpoch) || !allowGameplay)
                despawn?.Invoke(result.Item);
            else
            {
                tracked.Add(new Spawned(result.Crate, result.Item));
                trackedIndex = tracked.Count - 1;
            }
        }
        var removed = tracked.RemoveAll(item => item.Poolee == null);
        trackedIndex = Math.Clamp(trackedIndex, 0, Math.Max(0, tracked.Count - 1));
        return changed || removed != 0;
    }

    private static void OnDespawn(object __instance)
    {
        var service = active;
        if (service == null || __instance is not Component component)
            return;
        var index = service.tracked.FindIndex(item => item.Poolee == component);
        if (index < 0)
            return;
        var item = service.tracked[index];
        service.Restore(item, position: false);
        service.tracked.RemoveAt(index);
        service.trackedIndex = Math.Clamp(service.trackedIndex, 0, Math.Max(0, service.tracked.Count - 1));
    }

    internal string SelectTracked(int step)
    {
        if (tracked.Count > 0)
            trackedIndex = (trackedIndex + step % tracked.Count + tracked.Count) % tracked.Count;
        return SelectedObject;
    }

    internal string SelectNpc()
    {
        if (tracked.Count == 0) return "No tracked NPCs.";
        for (var offset = 1; offset <= tracked.Count; offset++)
        {
            var index = (trackedIndex + offset) % tracked.Count;
            if (tracked[index].Crate.Category != Kind.NPCs) continue;
            trackedIndex = index;
            return SelectedObject;
        }
        return "No tracked NPCs.";
    }

    internal string RemoveSelected(bool npcOnly = false)
    {
        var item = Current;
        if (item == null || (npcOnly && item.Crate.Category != Kind.NPCs))
            return npcOnly ? "Select a tracked NPC first." : "Select a tracked object first.";
        Remove(item);
        return $"Removed {item.Crate.Title}.";
    }

    internal string Cleanup(bool npcsOnly = false)
    {
        if (npcsOnly) npcEpoch++;
        else
        {
            epoch++;
            pending = 0;
        }
        var affected = tracked.Where(item => !npcsOnly || item.Crate.Category == Kind.NPCs).ToArray();
        foreach (var item in affected)
            Remove(item);
        return $"Removed {affected.Length} tracked {(npcsOnly ? "NPCs" : "objects")}.";
    }

    private void Remove(Spawned item)
    {
        Restore(item, position: false);
        tracked.Remove(item);
        trackedIndex = Math.Clamp(trackedIndex, 0, Math.Max(0, tracked.Count - 1));
        if (item.Poolee != null)
            despawn?.Invoke(item.Poolee);
    }

    internal string FreezeNpc(bool freeze, bool all)
    {
        var affected = all ? tracked.Where(item => item.Crate.Category == Kind.NPCs).ToArray() :
            Current is { Crate.Category: Kind.NPCs } npc ? new[] { npc } : Array.Empty<Spawned>();
        var count = 0;
        foreach (var item in affected)
        {
            if (item.Poolee == null || item.IsFrozen == freeze) continue;
            if (freeze)
            {
                var master = puppet?.Invoke(item.Poolee.gameObject);
                foreach (var behaviour in GameApi.Items(puppetBehaviours?.Invoke(master)).OfType<Behaviour>())
                    if (behaviour != null && behaviour.enabled)
                    {
                        behaviour.enabled = false;
                        item.Paused.Add(behaviour);
                    }
                foreach (var body in item.Poolee.GetComponentsInChildren<Rigidbody>(false))
                    if (body != null && !body.isKinematic)
                    {
                        body.velocity = Vector3.zero;
                        body.angularVelocity = Vector3.zero;
                        body.isKinematic = true;
                        item.Frozen.Add(body);
                    }
                if (item.Frozen.Count == 0 && item.Paused.Count == 0) continue;
                item.IsFrozen = true;
            }
            else
                Unfreeze(item);
            count++;
        }
        return count == 0 ? "No compatible NPC changed." : $"{(freeze ? "Froze" : "Unfroze")} {count} tracked NPC(s).";
    }

    internal string Manipulate(bool move)
    {
        var item = Current;
        var head = player.Head;
        if (item == null || item.Poolee == null || item.Crate.Category is Kind.NPCs or Kind.Vehicles)
            return "Select a tracked prop or weapon first.";
        var target = item.OriginalTransform;
        if (move)
        {
            if (head == null) return "No local aim transform.";
            var distance = settings.SpawnDistance.Value;
            if (player.TryRay(head.position, head.forward, distance, out var wall)) distance = wall.distance - .45f;
            if (distance < .65f) return "Move blocked by nearby geometry.";
            target.position = head.position + head.forward * distance;
        }
        else
        {
            target.localScale = item.Scale * settings.ObjectScale.Value;
            target.rotation = item.Rotation * Quaternion.Euler(0f, settings.ObjectYaw.Value, 0f);
        }
        item.Transformed = true;
        return $"Updated {item.Crate.Title}.";
    }

    internal string DescribeNpc() => Current is { Crate.Category: Kind.NPCs } npc
        ? $"{SelectedObject} · {npc.Crate.Barcode}" : "Select a tracked NPC first.";

    internal string ResetSelected()
    {
        if (Current is not { } item || item.Poolee == null) return "Select a tracked object first.";
        Restore(item, position: true);
        return $"Restored {item.Crate.Title}.";
    }

    internal void ResetObjects()
    {
        foreach (var item in tracked)
            Restore(item, position: true);
    }

    private static void Unfreeze(Spawned item)
    {
        foreach (var behaviour in item.Paused)
            if (behaviour != null) behaviour.enabled = true;
        foreach (var body in item.Frozen)
            if (body != null) body.isKinematic = false;
        item.Paused.Clear();
        item.Frozen.Clear();
        item.IsFrozen = false;
    }

    private void Restore(Spawned item, bool position)
    {
        Unfreeze(item);
        if (!item.Transformed || item.OriginalTransform == null) return;
        if (position) item.OriginalTransform.position = item.Origin;
        item.OriginalTransform.rotation = item.Rotation;
        item.OriginalTransform.localScale = item.Scale;
        item.Transformed = false;
    }

    internal void ChangeScene()
    {
        epoch++;
        pending = 0;
        foreach (var item in tracked)
            Restore(item, position: false);
        tracked.Clear();
        registered.Clear();
        trackedIndex = 0;
    }
}
