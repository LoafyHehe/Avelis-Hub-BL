using MelonLoader;

namespace AvelisHubBL.Core;

internal sealed class HubSettings
{
    private const float Enabled = 1f;
    private readonly MelonPreferences_Category category = MelonPreferences.CreateCategory("AvelisHubBL", "Avelis Hub BL");
    private readonly List<Setting> entries = new();

    internal Setting God = null!, Reserve = null!, Magazine = null!, Recoil = null!, Freeze = null!, Jump = null!, Speed = null!,
        Flight = null!, FlySpeed = null!, Noclip = null!, Teleport = null!, Gravity = null!, TimeScale = null!,
        Damage = null!, FireRate = null!, Reload = null!, SpawnDistance = null!, SpawnCount = null!, SpawnYaw = null!,
        SpawnFloor = null!, ObjectScale = null!, ObjectYaw = null!;

    internal HubSettings()
    {
        God = Toggle("GodMode");
        Reserve = Toggle("InfiniteReserve");
        Magazine = Toggle("InfiniteMagazine");
        Recoil = Toggle("NoRecoil");
        Freeze = Toggle("FreezePlayer");
        Jump = Number("JumpMultiplier", 1f, 1f, 4f, .25f);
        Speed = Number("SpeedMultiplier", 1f, .5f, 3f, .25f);
        Flight = Toggle("Flight");
        FlySpeed = Number("FlightSpeed", 4f, 1f, 12f, .5f);
        Noclip = Toggle("Noclip");
        Teleport = Number("TeleportDistance", 5f, 1f, 25f, 1f);
        Gravity = Number("GravityMultiplier", 1f, .25f, 2f, .25f);
        TimeScale = Number("TimeScale", 1f, .25f, 1.5f, .25f);
        Damage = Number("DamageMultiplier", 1f, .25f, 4f, .25f);
        FireRate = Number("FireRateMultiplier", 1f, 1f, 3f, .25f);
        Reload = Toggle("AutoRefill");
        SpawnDistance = Number("SpawnDistance", 2f, 1f, 10f, .5f);
        SpawnCount = Number("SpawnCount", 1f, 1f, 5f, 1f);
        SpawnYaw = Number("SpawnYaw", 0f, -180f, 180f, 15f);
        SpawnFloor = Toggle("PlaceOnSurface");
        ObjectScale = Number("ObjectScale", 1f, .5f, 2f, .25f);
        ObjectYaw = Number("ObjectYaw", 0f, -180f, 180f, 15f);
    }

    private Setting Toggle(string key) => Number(key, 0f, 0f, Enabled, Enabled, true);

    private Setting Number(string key, float initial, float min, float max, float step, bool toggle = false)
    {
        var setting = new Setting(category.CreateEntry(key, initial), initial, min, max, step, toggle);
        entries.Add(setting);
        return setting;
    }

    internal void Save() => MelonPreferences.Save();
    internal void Load() => MelonPreferences.Load();
    internal void Defaults()
    {
        foreach (var setting in entries)
            setting.Reset();
    }

    internal sealed class Setting(MelonPreferences_Entry<float> entry, float initial, float min, float max, float step, bool toggle)
    {
        internal float Minimum => min;
        internal float Maximum => max;
        internal float Step => step;
        internal bool Toggle => toggle;
        internal bool On => Value >= Enabled;
        internal float Value
        {
            get => Normalize(entry.Value);
            set => entry.Value = Normalize(value);
        }
        private float Normalize(float value) => float.IsFinite(value)
            ? Math.Clamp(min + MathF.Round((Math.Clamp(value, min, max) - min) / step) * step, min, max) : initial;
        internal void Reset() => Value = initial;
    }
}
