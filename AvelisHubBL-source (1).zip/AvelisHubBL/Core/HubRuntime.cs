using System.Reflection;
using AvelisHubBL.Features;
using AvelisHubBL.Menu;
using BoneLib;
using MelonLoader;
using UnityEngine;

namespace AvelisHubBL.Core;

internal sealed class HubRuntime(MelonLogger.Instance log, global::HarmonyLib.Harmony harmony) : IDisposable
{
    private readonly HubSettings settings = new();
    private PlayerTools player = null!;
    private WeaponTools weapons = null!;
    private SpawnTools spawn = null!;
    private WorldTools world = null!;
    private HubMenu menu = null!;
    private VrPanel panel = null!;
    private Func<object?, bool>? fusionServer;
    private bool fusionDetected, ready, allowed, disabled, chordHeld;
    private float sceneReadyAt, nextFusionCheck;
    private string reason = "Waiting for the local player rig.";

    internal void Initialize()
    {
        try
        {
            EnsureMarrow();
            player = new PlayerTools(settings, () => allowed);
            weapons = new WeaponTools(settings, player, () => allowed);
            spawn = new SpawnTools(settings, player);
            world = new WorldTools(settings);
            Bind("player", () => player.Bind(harmony));
            Bind("weapons", () => weapons.Bind(harmony));
            Bind("spawning", () => spawn.Bind(harmony));
            BindFusion();
            menu = new HubMenu(settings, player, weapons, spawn, CanAct, () => reason, TogglePanel, ResetPlayer, ResetWorld);
            panel = new VrPanel(menu, player, log);
            ready = true;
            log.Msg($"Avelis Hub BL {Main.Version}: jump={player.CanJump}, flight={player.CanFly}, weapon hooks={weapons.CanMagazine}, warehouse={spawn.CanBrowse}, pooled spawn={spawn.CanSpawn}, XR input={player.CanInput}.");
        }
        catch (Exception exception)
        {
            log.Error("Avelis Hub BL could not initialize: " + exception.GetBaseException().Message);
            disabled = true;
        }
    }

    private static void EnsureMarrow()
    {
        foreach (var reference in typeof(Player).Assembly.GetReferencedAssemblies())
            if (reference.Name == "Il2CppSLZ.Marrow" && GameApi.Marrow("RigManager") == null)
                Assembly.Load(reference);
    }

    private void Bind(string area, Action bind)
    {
        try { bind(); }
        catch (Exception exception) { log.Warning($"Avelis {area} binding: {exception.GetBaseException().Message}"); }
    }

    private void BindFusion()
    {
        var assembly = AppDomain.CurrentDomain.GetAssemblies().FirstOrDefault(item => item.GetName().Name == "LabFusion");
        if (assembly == null)
            return;
        fusionDetected = true;
        Bind("Fusion compatibility", () => fusionServer = GameApi.Read<bool>(assembly.GetType("LabFusion.Network.NetworkInfo"), "HasServer"));
    }

    private bool IsNetworked()
    {
        if (!fusionDetected)
            return false;
        try { return fusionServer?.Invoke(null) != false; }
        catch { return true; }
    }

    private bool CanAct() => allowed && !IsNetworked();

    internal void Update()
    {
        if (!ready || disabled)
            return;
        try
        {
            if (!fusionDetected && Time.unscaledTime >= nextFusionCheck)
            {
                nextFusionCheck = Time.unscaledTime + 1f;
                BindFusion();
            }
            var networked = IsNetworked();
            var playable = Time.unscaledTime >= sceneReadyAt && player.Head != null && !Loading();
            var enable = !networked && playable;
            if (allowed && !enable)
            {
                Restore();
                if (networked) spawn.ChangeScene();
            }
            allowed = enable;
            var nextReason = networked ? "Tools are paused in Fusion sessions." : playable ? "Single-player tools ready." : "Waiting for the local player rig.";
            if (reason != nextReason)
            {
                reason = nextReason;
                menu.Invalidate();
            }
            menu.TryAttach();
            if (spawn.Update(allowed)) menu.Invalidate();
            if (allowed)
            {
                world.Update();
                weapons.Update();
            }
            var chord = player.Chord;
            if (chord && !chordHeld)
                TogglePanel();
            chordHeld = chord;
            panel.Update();
            menu.SyncBoneMenu();
        }
        catch (Exception exception) { Fault(exception); }
    }

    internal void FixedUpdate()
    {
        if (!allowed || disabled)
            return;
        try { player.FixedUpdate(panel.Visible); }
        catch (Exception exception) { Fault(exception); }
    }

    private static bool Loading()
    {
        try { return HelperMethods.IsLoading(); }
        catch (NullReferenceException) { return true; }
    }

    private string TogglePanel()
    {
        if (Time.unscaledTime < sceneReadyAt || Loading())
            return "Wait for the scene to finish loading before opening the VR panel.";
        return panel.Toggle();
    }

    private string ResetPlayer()
    {
        settings.Noclip.Reset();
        settings.Flight.Reset();
        settings.Freeze.Reset();
        settings.Speed.Reset();
        settings.Jump.Reset();
        settings.FlySpeed.Reset();
        settings.God.Reset();
        settings.Gravity.Reset();
        player.Restore();
        world.Update();
        return "Player movement, collision and gravity restored.";
    }

    private string ResetWorld()
    {
        settings.Gravity.Reset();
        settings.TimeScale.Reset();
        world.Restore();
        spawn.ResetObjects();
        return "World overrides and tracked object edits restored.";
    }

    private void Restore()
    {
        allowed = false;
        Bind("player restore", () => player?.Restore());
        Bind("weapon restore", () => weapons?.Reset());
        Bind("world restore", () => world?.Restore());
    }

    internal void ChangeScene()
    {
        if (!ready || disabled)
            return;
        Restore();
        BindFusion();
        Bind("scene cleanup", spawn.ChangeScene);
        panel.Hide();
        sceneReadyAt = Time.unscaledTime + .35f;
        menu.Invalidate();
    }

    private void Fault(Exception exception)
    {
        disabled = true;
        log.Error("Avelis Hub BL paused after a runtime error: " + exception.GetBaseException().Message);
        Restore();
        Bind("fault cleanup", () => spawn?.Cleanup());
        Bind("fault panel cleanup", () => panel?.Hide());
        Bind("fault menu cleanup", () => menu?.Detach());
    }

    public void Dispose()
    {
        disabled = true;
        Restore();
        Bind("spawn cleanup", () => spawn?.Cleanup());
        Bind("panel cleanup", () => panel?.Dispose());
        Bind("menu cleanup", () => menu?.Detach());
        Bind("hook cleanup", () => harmony.UnpatchSelf());
    }
}
